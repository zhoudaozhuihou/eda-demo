# Chat-Driven Workbench Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Transform DataAgentStudio into a Chat-driven workbench — Chat responses with structured actions render as rich result components in the center Canvas area.

**Architecture:** ChatActionContext (React Context) at AppLayout level bridges the embedded chat inside DataAgentStudio and the center Canvas area. The chat API response is extended with an optional `action` field. When DataAgentStudio receives a response with an action, it pushes to context and renders the matching result component.

**Tech Stack:** React (Context API), MUI, TypeScript, Vite

---

## File Structure

### New files:
- `src/contexts/ChatActionContext.tsx` — Context + Provider + useChatAction() hook
- `src/components/studio/CanvasResult.tsx` — Router: maps action type → result component
- `src/components/studio/result/TagResultGrid.tsx` — Tag search results
- `src/components/studio/result/ProfileResult.tsx` — Profile/segment analysis
- `src/components/studio/result/RuleBuilderResult.tsx` — Rule creation result
- `src/components/studio/result/OverviewResult.tsx` — System overview metrics
- `src/components/studio/result/KnowledgeExtractResult.tsx` — File import + extraction
- `src/components/studio/result/KnowledgeTagResult.tsx` — Knowledge → tag extraction

### Modified files:
- `src/lib/api/chat.ts` — Add optional `action` field to ChatResponse
- `src/components/layout/AppLayout.tsx` — Wrap with ChatActionProvider
- `src/pages/DataAgentStudio.tsx:546-572` — After chat response, push action to context; render CanvasResult instead of context-aware views

---

### Task 1: ChatActionContext

**Files:**
- Create: `src/contexts/ChatActionContext.tsx`
- Modify: `src/components/layout/AppLayout.tsx:14-44`

- [ ] **Step 1: Write ChatActionContext**

```typescript
// src/contexts/ChatActionContext.tsx
import { createContext, useContext, useState, useCallback, type ReactNode } from 'react';

export type ActionType =
  | 'search_tags'
  | 'analyze_segment'
  | 'create_rule'
  | 'system_overview'
  | 'import_knowledge'
  | 'knowledge_to_tags'
  | 'run_scenario';

export interface CanvasAction {
  id: string;
  type: ActionType;
  title: string;
  data: unknown;
  timestamp: number;
}

interface ChatActionContextValue {
  actions: CanvasAction[];
  pushAction: (action: Omit<CanvasAction, 'id' | 'timestamp'>) => void;
  clearActions: () => void;
  removeAction: (id: string) => void;
  activeIndex: number;
  setActiveIndex: (index: number) => void;
}

const ChatActionContext = createContext<ChatActionContextValue | null>(null);

export function ChatActionProvider({ children }: { children: ReactNode }) {
  const [actions, setActions] = useState<CanvasAction[]>([]);
  const [activeIndex, setActiveIndex] = useState(-1);

  const pushAction = useCallback((action: Omit<CanvasAction, 'id' | 'timestamp'>) => {
    const canvasAction: CanvasAction = {
      ...action,
      id: crypto.randomUUID(),
      timestamp: Date.now(),
    };
    setActions((prev) => [...prev, canvasAction]);
    setActiveIndex((prev) => prev + 1);
  }, []);

  const clearActions = useCallback(() => {
    setActions([]);
    setActiveIndex(-1);
  }, []);

  const removeAction = useCallback((id: string) => {
    setActions((prev) => prev.filter((a) => a.id !== id));
  }, []);

  return (
    <ChatActionContext.Provider value={{ actions, pushAction, clearActions, removeAction, activeIndex, setActiveIndex }}>
      {children}
    </ChatActionContext.Provider>
  );
}

export function useChatAction(): ChatActionContextValue {
  const ctx = useContext(ChatActionContext);
  if (!ctx) throw new Error('useChatAction must be used within ChatActionProvider');
  return ctx;
}
```

- [ ] **Step 2: Wrap AppLayout with ChatActionProvider**

Open `src/components/layout/AppLayout.tsx`. Add the import and wrap the return in `ChatActionProvider`:

```typescript
import { ChatActionProvider } from '../../contexts/ChatActionContext';
```

At the return statement:

```typescript
return (
  <ChatActionProvider>
    <Box className="flex">
      {/* ... existing JSX ... */}
    </Box>
  </ChatActionProvider>
);
```

Keep all existing JSX inside the provider unchanged.

- [ ] **Step 3: Verify build**

Run: `cd /Users/Apple/codes/data-label/frontend && npx tsc --noEmit`
Expected: No errors

- [ ] **Step 4: Commit**

```bash
cd /Users/Apple/codes/data-label/frontend && git add src/contexts/ChatActionContext.tsx src/components/layout/AppLayout.tsx && git commit -m "feat: add ChatActionContext for chat-canvas communication"
```

---

### Task 2: Extend Chat API response with action field

**Files:**
- Modify: `src/lib/api/chat.ts:8-13`

- [ ] **Step 1: Add action field to ChatResponse**

```typescript
// src/lib/api/chat.ts
import type { ActionType } from '../../contexts/ChatActionContext';

export interface ChatRequest {
  message: string;
  context?: string;
}

export interface ChatAction {
  type: ActionType;
  data: Record<string, unknown>;
}

export interface ChatResponse {
  reply: string;
  suggestions: string[];
  action?: ChatAction;
  timestamp: string;
}
```

- [ ] **Step 2: Verify build**

Run: `cd /Users/Apple/codes/data-label/frontend && npx tsc --noEmit`
Expected: No errors

- [ ] **Step 3: Commit**

```bash
cd /Users/Apple/codes/data-label/frontend && git add src/lib/api/chat.ts && git commit -m "feat: add optional action field to ChatResponse"
```

---

### Task 3: Building block result types

**Files:**
- Create: `src/components/studio/result/TagResultGrid.tsx`
- Create: `src/components/studio/result/ProfileResult.tsx`
- Create: `src/components/studio/result/RuleBuilderResult.tsx`
- Create: `src/components/studio/result/OverviewResult.tsx`

- [ ] **Step 1: Create TagResultGrid**

```typescript
// src/components/studio/result/TagResultGrid.tsx
import { Box, Typography, Paper, Chip, Button, Grid } from '@mui/material';

interface TagResultData {
  keyword: string;
  total: number;
  tags: {
    id: string;
    name: string;
    type: string;
    coverage: number;
    confidence: number;
    status: 'published' | 'draft';
  }[];
}

export default function TagResultGrid({ data, onNavigate }: { data: TagResultData; onNavigate?: () => void }) {
  return (
    <Box>
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1.5 }}>
        <Box>
          <Typography variant="subtitle2" sx={{ fontWeight: 700 }}>
            🔍 搜索：{data.keyword}
          </Typography>
          <Typography variant="caption" color="primary.main">
            找到 {data.total} 个标签
          </Typography>
        </Box>
        {onNavigate && (
          <Button size="small" variant="outlined" onClick={onNavigate} sx={{ borderRadius: 12, fontSize: '0.75rem' }}>
            在标签市场中打开 →
          </Button>
        )}
      </Box>
      <Grid container spacing={1.5}>
        {data.tags.map((tag) => (
          <Grid size={{ xs: 12, sm: 6, md: 4 }} key={tag.id}>
            <Paper variant="outlined" sx={{ p: 1.5, borderRadius: 2 }}>
              <Typography variant="body2" sx={{ fontWeight: 600 }}>{tag.name}</Typography>
              <Typography variant="caption" color="text.secondary" sx={{ display: 'block', my: 0.5 }}>
                {tag.type} · 覆盖率 {(tag.coverage / 10000).toFixed(1)}万
              </Typography>
              <Box sx={{ display: 'flex', gap: 0.5 }}>
                <Chip label={`${Math.round(tag.confidence)}%`} size="small"
                  sx={{ height: 20, fontSize: '0.65rem', bgcolor: 'rgba(21,101,192,0.08)', color: 'primary.main' }} />
                <Chip label={tag.status === 'published' ? '已发布' : '草稿'} size="small"
                  color={tag.status === 'published' ? 'success' : 'default'}
                  sx={{ height: 20, fontSize: '0.65rem' }} />
              </Box>
            </Paper>
          </Grid>
        ))}
      </Grid>
    </Box>
  );
}
```

- [ ] **Step 2: Create ProfileResult**

```typescript
// src/components/studio/result/ProfileResult.tsx
import { Box, Typography, Paper, Chip, Button, Grid } from '@mui/material';

interface ProfileResultData {
  segmentName: string;
  profiles: { name: string; tags: number; score: number }[];
  tags: { name: string; score: number }[];
}

export default function ProfileResult({ data, onNavigate }: { data: ProfileResultData; onNavigate?: () => void }) {
  return (
    <Box>
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1.5 }}>
        <Typography variant="subtitle2" sx={{ fontWeight: 700 }}>
          📊 客群分析：{data.segmentName}
        </Typography>
        {onNavigate && (
          <Button size="small" variant="outlined" onClick={onNavigate} sx={{ borderRadius: 12, fontSize: '0.75rem' }}>
            在标签分析中打开 →
          </Button>
        )}
      </Box>

      <Grid container spacing={1.5}>
        <Grid size={{ xs: 12, md: 6 }}>
          <Typography variant="caption" sx={{ fontWeight: 600, color: 'text.secondary', mb: 0.5, display: 'block' }}>
            客群画像
          </Typography>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.75 }}>
            {data.profiles.map((p, i) => (
              <Paper key={i} variant="outlined" sx={{ p: 1.25, borderRadius: 1.5, display: 'flex', alignItems: 'center', gap: 1.5 }}>
                <Box sx={{
                  width: 36, height: 36, borderRadius: '50%', bgcolor: 'rgba(21,101,192,0.08)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 14, fontWeight: 700,
                  color: 'primary.main', flexShrink: 0,
                }}>
                  {p.name.charAt(0)}
                </Box>
                <Box sx={{ flex: 1 }}>
                  <Typography variant="body2" sx={{ fontWeight: 600 }}>{p.name}</Typography>
                  <Typography variant="caption" color="text.secondary">{p.tags} 个标签 · 匹配度 {p.score}%</Typography>
                </Box>
              </Paper>
            ))}
          </Box>
        </Grid>
        <Grid size={{ xs: 12, md: 6 }}>
          <Typography variant="caption" sx={{ fontWeight: 600, color: 'text.secondary', mb: 0.5, display: 'block' }}>
            画像标签
          </Typography>
          <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
            {data.tags.map((t, i) => (
              <Chip key={i} label={`${t.name} ${t.score}%`} size="small"
                sx={{ height: 24, fontSize: '0.7rem', bgcolor: 'rgba(21,101,192,0.08)', color: 'primary.main' }} />
            ))}
          </Box>
        </Grid>
      </Grid>
    </Box>
  );
}
```

- [ ] **Step 3: Create RuleBuilderResult**

```typescript
// src/components/studio/result/RuleBuilderResult.tsx
import { Box, Typography, Paper, Chip, Button } from '@mui/material';

interface RuleResultData {
  tagName: string;
  conditions: { field: string; operator: string; value: string }[];
  estimatedCoverage: number;
  status: 'draft' | 'saved';
}

export default function RuleBuilderResult({ data, onNavigate }: { data: RuleResultData; onNavigate?: () => void }) {
  return (
    <Box>
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1.5 }}>
        <Typography variant="subtitle2" sx={{ fontWeight: 700 }}>
          🛠️ 创建新标签：{data.tagName}
        </Typography>
        {onNavigate && (
          <Button size="small" variant="outlined" onClick={onNavigate} sx={{ borderRadius: 12, fontSize: '0.75rem' }}>
            在标签开发中打开 →
          </Button>
        )}
      </Box>

      <Paper variant="outlined" sx={{ p: 2, borderRadius: 2, bgcolor: 'grey.50' }}>
        <Box sx={{ display: 'flex', gap: 1, alignItems: 'center', flexWrap: 'wrap', mb: 1.5 }}>
          <Typography variant="caption" sx={{ fontWeight: 600 }}>标签规则：</Typography>
          {data.conditions.map((c, i) => (
            <Box key={i} sx={{ display: 'flex', alignItems: 'center', gap: 0.5 }}>
              {i > 0 && <Typography variant="caption" sx={{ color: 'text.secondary', fontWeight: 600 }}>AND</Typography>}
              <Chip label={`${c.field} ${c.operator} ${c.value}`} size="small"
                sx={{ height: 24, fontSize: '0.7rem', bgcolor: 'rgba(21,101,192,0.08)', color: 'primary.main' }} />
            </Box>
          ))}
        </Box>
        <Box sx={{ bgcolor: 'rgba(46,125,50,0.06)', borderRadius: 1.5, p: 1.5 }}>
          <Typography variant="caption" sx={{ color: 'success.main', fontWeight: 600 }}>
            ✅ 预估覆盖：{data.estimatedCoverage.toLocaleString()} 人
            {data.status === 'draft' ? ' | 已保存为草稿' : ' | 已保存'}
          </Typography>
        </Box>
      </Paper>
    </Box>
  );
}
```

- [ ] **Step 4: Create OverviewResult**

```typescript
// src/components/studio/result/OverviewResult.tsx
import { Box, Typography, Paper, Button, Grid, LinearProgress } from '@mui/material';

interface OverviewResultData {
  metrics: { label: string; value: number; color: string }[];
  totalScore: number;
}

export default function OverviewResult({ data, onNavigate }: { data: OverviewResultData; onNavigate?: () => void }) {
  return (
    <Box>
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1.5 }}>
        <Typography variant="subtitle2" sx={{ fontWeight: 700 }}>
          📊 系统概览
        </Typography>
        {onNavigate && (
          <Button size="small" variant="outlined" onClick={onNavigate} sx={{ borderRadius: 12, fontSize: '0.75rem' }}>
            在数据治理中心中打开 →
          </Button>
        )}
      </Box>

      <Grid container spacing={1.5} sx={{ mb: 1.5 }}>
        {data.metrics.map((m, i) => (
          <Grid size={{ xs: 6, sm: 3 }} key={i}>
            <Paper variant="outlined" sx={{ p: 1.5, borderRadius: 2, textAlign: 'center' }}>
              <Typography variant="h5" sx={{ fontWeight: 700, color: m.color }}>
                {m.value.toLocaleString()}
              </Typography>
              <Typography variant="caption" color="text.secondary">{m.label}</Typography>
            </Paper>
          </Grid>
        ))}
      </Grid>

      <Box sx={{ bgcolor: 'grey.50', borderRadius: 2, p: 1.5, border: '1px solid', borderColor: 'divider' }}>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 0.5 }}>
          <Typography variant="caption" color="text.secondary">综合数据治理评分</Typography>
          <Typography variant="caption" sx={{ fontWeight: 700, color: 'primary.main' }}>{data.totalScore}%</Typography>
        </Box>
        <LinearProgress variant="determinate" value={data.totalScore}
          sx={{ height: 6, borderRadius: 3, bgcolor: 'grey.200',
            '& .MuiLinearProgress-bar': { bgcolor: 'primary.main', borderRadius: 3 } }} />
      </Box>
    </Box>
  );
}
```

- [ ] **Step 5: Verify build**

Run: `cd /Users/Apple/codes/data-label/frontend && npx tsc --noEmit`
Expected: No errors

- [ ] **Step 6: Commit**

```bash
cd /Users/Apple/codes/data-label/frontend && git add src/components/studio/result/TagResultGrid.tsx src/components/studio/result/ProfileResult.tsx src/components/studio/result/RuleBuilderResult.tsx src/components/studio/result/OverviewResult.tsx && git commit -m "feat: add building block result components"
```

---

### Task 4: Knowledge result components

**Files:**
- Create: `src/components/studio/result/KnowledgeExtractResult.tsx`
- Create: `src/components/studio/result/KnowledgeTagResult.tsx`

- [ ] **Step 1: Create KnowledgeExtractResult**

```typescript
// src/components/studio/result/KnowledgeExtractResult.tsx
import { useState } from 'react';
import { Box, Typography, Paper, Chip, Button, LinearProgress } from '@mui/material';

interface KnowledgeExtractData {
  filename: string;
  status: 'analyzing' | 'completed' | 'failed';
  progress: number;
  entities: { name: string; type: string; mentions: number }[];
  triples: { subject: string; predicate: string; object: string }[];
  tags: { name: string; category: string; confidence: number }[];
}

const TYPE_COLORS: Record<string, string> = {
  person: '#1565c0',
  organization: '#2e7d32',
  location: '#e65100',
  concept: '#7b1fa2',
};

export default function KnowledgeExtractResult({ data, onNavigate }: { data: KnowledgeExtractData; onNavigate?: () => void }) {
  const [published, setPublished] = useState(false);

  return (
    <Box>
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1.5 }}>
        <Typography variant="subtitle2" sx={{ fontWeight: 700 }}>
          📄 知识抽取：{data.filename}
        </Typography>
        {onNavigate && (
          <Button size="small" variant="outlined" onClick={onNavigate} sx={{ borderRadius: 12, fontSize: '0.75rem' }}>
            在知识管理中打开 →
          </Button>
        )}
      </Box>

      {/* Progress bar for analyzing state */}
      {data.status === 'analyzing' && (
        <Paper variant="outlined" sx={{ p: 1.5, borderRadius: 2, mb: 1.5, bgcolor: '#fff3e0', borderColor: '#ffe0b2' }}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 0.5 }}>
            <Typography variant="caption" sx={{ fontWeight: 600, color: '#e65100' }}>⏳ 分析中</Typography>
            <Typography variant="caption" sx={{ color: '#e65100' }}>{data.progress}%</Typography>
          </Box>
          <LinearProgress variant="determinate" value={data.progress}
            sx={{ height: 4, borderRadius: 2, bgcolor: '#ffe0b2',
              '& .MuiLinearProgress-bar': { bgcolor: '#e65100', borderRadius: 2 } }} />
        </Paper>
      )}

      {/* Failed state */}
      {data.status === 'failed' && (
        <Paper variant="outlined" sx={{ p: 1.5, borderRadius: 2, mb: 1.5, bgcolor: '#fef2f2', borderColor: '#fecaca' }}>
          <Typography variant="caption" sx={{ color: 'error.main', fontWeight: 600 }}>❌ 分析失败，请重试</Typography>
        </Paper>
      )}

      {data.status === 'completed' && (
        <>
          {/* Entities + Triples grid */}
          <Grid container spacing={1.5} sx={{ mb: 1.5 }}>
            <Grid size={{ xs: 12, sm: 6 }}>
              <Paper variant="outlined" sx={{ p: 1.5, borderRadius: 2 }}>
                <Typography variant="caption" sx={{ fontWeight: 600, color: 'primary.main', mb: 1, display: 'block' }}>
                  📌 实体
                </Typography>
                <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                  {data.entities.map((e, i) => (
                    <Chip key={i} label={`${e.name}`} size="small"
                      sx={{ height: 22, fontSize: '0.7rem',
                        bgcolor: `${TYPE_COLORS[e.type] || '#666'}18`,
                        color: TYPE_COLORS[e.type] || '#666' }} />
                  ))}
                </Box>
              </Paper>
            </Grid>
            <Grid size={{ xs: 12, sm: 6 }}>
              <Paper variant="outlined" sx={{ p: 1.5, borderRadius: 2 }}>
                <Typography variant="caption" sx={{ fontWeight: 600, color: 'success.main', mb: 1, display: 'block' }}>
                  🔗 关系
                </Typography>
                {data.triples.map((t, i) => (
                  <Typography key={i} variant="caption" sx={{ display: 'block', mb: 0.25 }}>
                    {t.subject} <span style={{ color: '#999' }}>→ {t.predicate} →</span> {t.object}
                  </Typography>
                ))}
              </Paper>
            </Grid>
          </Grid>

          {/* Extracted tags */}
          <Paper variant="outlined" sx={{ p: 1.5, borderRadius: 2 }}>
            <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1 }}>
              <Typography variant="caption" sx={{ fontWeight: 600, color: '#7b1fa2' }}>
                🏷️ 提取的标签
              </Typography>
              <Button size="small" variant="contained" disabled={published}
                onClick={() => setPublished(true)}
                sx={{ borderRadius: 12, fontSize: '0.65rem', minWidth: 0, px: 1.5, py: 0.25, bgcolor: '#7b1fa2',
                  '&:hover': { bgcolor: '#6a1b9a' }, '&.Mui-disabled': { bgcolor: 'grey.200' } }}>
                {published ? '已发布' : '全部发布到标签市场'}
              </Button>
            </Box>
            <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
              {data.tags.map((t, i) => (
                <Chip key={i} label={`${t.name} ${Math.round(t.confidence)}%`} size="small"
                  sx={{ height: 22, fontSize: '0.7rem', bgcolor: 'rgba(123,31,162,0.08)', color: '#7b1fa2' }} />
              ))}
            </Box>
          </Paper>
        </>
      )}
    </Box>
  );
}
```

- [ ] **Step 2: Create KnowledgeTagResult**

```typescript
// src/components/studio/result/KnowledgeTagResult.tsx
import { useState } from 'react';
import { Box, Typography, Paper, Chip, Button, Checkbox } from '@mui/material';

interface KnowledgeTagData {
  entries: { id: string; filename: string; category: string; date: string; tagCount: number }[];
  selectedIds?: string[];
  extractedTags?: { name: string; confidence: number; source: string }[];
}

export default function KnowledgeTagResult({ data }: { data: KnowledgeTagData }) {
  const [selected, setSelected] = useState<Set<string>>(new Set(data.selectedIds || []));
  const [extracted, setExtracted] = useState(data.extractedTags || null);
  const [publishing, setPublishing] = useState(false);

  const toggleEntry = (id: string) => {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  const handleExtract = () => {
    // Simulated extraction — in real flow the backend would do this
    setExtracted([
      { name: 'CHINA用户', confidence: 95, source: '跨境留学客群分析报告' },
      { name: '有留学需求', confidence: 94, source: '2026年留学趋势预测' },
      { name: '有香港账户', confidence: 88, source: '跨境留学客群分析报告' },
      { name: '跨境汇款活跃', confidence: 85, source: '跨境留学客群分析报告' },
      { name: '教育意向', confidence: 96, source: '2026年留学趋势预测' },
    ]);
  };

  return (
    <Box>
      <Typography variant="subtitle2" sx={{ fontWeight: 700, mb: 1.5 }}>
        🔍 知识库匹配结果
      </Typography>

      {/* Step 1: Entry list with checkboxes */}
      <Paper variant="outlined" sx={{ p: 1.5, borderRadius: 2, mb: 1.5 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1 }}>
          <Typography variant="caption" color="text.secondary">
            找到 {data.entries.length} 条相关条目，已选 {selected.size} 条
          </Typography>
        </Box>
        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 0.75 }}>
          {data.entries.map((entry) => (
            <Paper key={entry.id} variant="outlined"
              onClick={() => toggleEntry(entry.id)}
              sx={{ display: 'flex', alignItems: 'center', gap: 1, p: 1, borderRadius: 1.5, cursor: 'pointer',
                bgcolor: selected.has(entry.id) ? 'rgba(21,101,192,0.04)' : 'grey.50',
                borderColor: selected.has(entry.id) ? 'primary.light' : 'divider',
                '&:hover': { borderColor: 'primary.light' } }}>
              <Checkbox checked={selected.has(entry.id)} size="small" sx={{ p: 0 }} />
              <Box sx={{ flex: 1 }}>
                <Typography variant="body2" sx={{ fontWeight: 600, fontSize: '0.8rem' }}>{entry.filename}</Typography>
                <Typography variant="caption" color="text.secondary">
                  {entry.category} · {entry.date}
                </Typography>
              </Box>
              <Chip label={`${entry.tagCount}个标签`} size="small"
                sx={{ height: 20, fontSize: '0.6rem', bgcolor: 'rgba(21,101,192,0.08)', color: 'primary.main' }} />
            </Paper>
          ))}
        </Box>
        {!extracted && (
          <Button size="small" variant="contained" disabled={selected.size === 0}
            onClick={handleExtract}
            sx={{ mt: 1.5, borderRadius: 12, fontSize: '0.7rem', bgcolor: '#7b1fa2',
              '&:hover': { bgcolor: '#6a1b9a' }, '&.Mui-disabled': { bgcolor: 'grey.200' } }}>
            从选中条目抽取标签（已选 {selected.size} 条）
          </Button>
        )}
      </Paper>

      {/* Step 2: Extracted tags */}
      {extracted && (
        <Paper variant="outlined" sx={{ p: 1.5, borderRadius: 2, bgcolor: '#faf5ff', borderColor: '#7b1fa2' }}>
          <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1 }}>
            <Typography variant="subtitle2" sx={{ fontWeight: 700, color: '#7b1fa2' }}>
              🏷️ 抽取结果
            </Typography>
            <Button size="small" variant="contained" disabled={publishing}
              onClick={() => setPublishing(true)}
              sx={{ borderRadius: 12, fontSize: '0.65rem', minWidth: 0, px: 1.5, py: 0.25,
                bgcolor: '#7b1fa2', '&:hover': { bgcolor: '#6a1b9a' },
                '&.Mui-disabled': { bgcolor: 'grey.200' } }}>
              {publishing ? '已发布' : '发布到标签市场'}
            </Button>
          </Box>
          <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
            {extracted.map((t, i) => (
              <Chip key={i} label={`${t.name} ${t.confidence}%`} size="small"
                sx={{ height: 22, fontSize: '0.7rem', bgcolor: 'rgba(123,31,162,0.08)', color: '#7b1fa2' }} />
            ))}
          </Box>
          <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 1 }}>
            来源：{extracted.map((t) => t.source).filter((v, i, a) => a.indexOf(v) === i).join(' + ')}
          </Typography>
        </Paper>
      )}
    </Box>
  );
}
```

Note: The `Grid` import is needed in KnowledgeExtractResult. Make sure to add it:

```typescript
import { Box, Typography, Paper, Chip, Button, LinearProgress, Grid } from '@mui/material';
```

- [ ] **Step 3: Verify build**

Run: `cd /Users/Apple/codes/data-label/frontend && npx tsc --noEmit`
Expected: No errors

- [ ] **Step 4: Commit**

```bash
cd /Users/Apple/codes/data-label/frontend && git add src/components/studio/result/KnowledgeExtractResult.tsx src/components/studio/result/KnowledgeTagResult.tsx && git commit -m "feat: add knowledge result components"
```

---

### Task 5: CanvasResult router container

**Files:**
- Create: `src/components/studio/CanvasResult.tsx`

- [ ] **Step 1: Create CanvasResult component**

```typescript
// src/components/studio/CanvasResult.tsx
import { Box, Typography, Paper, IconButton, Chip } from '@mui/material';
import { Close } from '@mui/icons-material';
import type { CanvasAction } from '../../contexts/ChatActionContext';
import TagResultGrid from './result/TagResultGrid';
import ProfileResult from './result/ProfileResult';
import RuleBuilderResult from './result/RuleBuilderResult';
import OverviewResult from './result/OverviewResult';
import KnowledgeExtractResult from './result/KnowledgeExtractResult';
import KnowledgeTagResult from './result/KnowledgeTagResult';

interface CanvasResultProps {
  action: CanvasAction;
  onRemove?: (id: string) => void;
  onNavigate?: (type: string) => void;
}

const ACTION_LABELS: Record<string, string> = {
  search_tags: '🔍 标签搜索',
  analyze_segment: '📊 客群分析',
  create_rule: '🛠️ 规则创建',
  system_overview: '📋 系统概览',
  import_knowledge: '📄 知识抽取',
  knowledge_to_tags: '🏷️ 知识查标签',
  run_scenario: '⚡ 场景执行',
};

const NAV_PATHS: Record<string, string> = {
  search_tags: '/tags/market',
  analyze_segment: '/tags/analysis',
  create_rule: '/tags/development',
  system_overview: '/governance',
  import_knowledge: '/knowledge',
  knowledge_to_tags: '/knowledge',
  run_scenario: '',
};

export default function CanvasResult({ action, onRemove, onNavigate }: CanvasResultProps) {
  const navPath = NAV_PATHS[action.type];

  const handleNavigate = () => {
    if (navPath && onNavigate) onNavigate(navPath);
  };

  const renderContent = () => {
    switch (action.type) {
      case 'search_tags':
        return <TagResultGrid data={action.data as any} onNavigate={navPath ? handleNavigate : undefined} />;
      case 'analyze_segment':
        return <ProfileResult data={action.data as any} onNavigate={navPath ? handleNavigate : undefined} />;
      case 'create_rule':
        return <RuleBuilderResult data={action.data as any} onNavigate={navPath ? handleNavigate : undefined} />;
      case 'system_overview':
        return <OverviewResult data={action.data as any} onNavigate={navPath ? handleNavigate : undefined} />;
      case 'import_knowledge':
        return <KnowledgeExtractResult data={action.data as any} onNavigate={navPath ? handleNavigate : undefined} />;
      case 'knowledge_to_tags':
        return <KnowledgeTagResult data={action.data as any} />;
      case 'run_scenario':
        return (
          <Paper variant="outlined" sx={{ p: 2, borderRadius: 2 }}>
            <Typography variant="body2" color="text.secondary">场景执行结果：{(action.data as any)?.message || '执行完成'}</Typography>
          </Paper>
        );
      default:
        return null;
    }
  };

  return (
    <Paper variant="outlined" sx={{ p: 2, borderRadius: 2, mb: 2, position: 'relative' }}>
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 1.5 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <Typography variant="subtitle2" sx={{ fontWeight: 700 }}>{action.title}</Typography>
          <Chip label={ACTION_LABELS[action.type]} size="small" variant="outlined"
            sx={{ height: 20, fontSize: '0.6rem', borderColor: 'primary.light', color: 'primary.main' }} />
        </Box>
        {onRemove && (
          <IconButton size="small" onClick={() => onRemove(action.id)} sx={{ color: 'text.secondary' }}>
            <Close sx={{ fontSize: 16 }} />
          </IconButton>
        )}
      </Box>
      {renderContent()}
    </Paper>
  );
}
```

- [ ] **Step 2: Verify build**

Run: `cd /Users/Apple/codes/data-label/frontend && npx tsc --noEmit`
Expected: No errors

- [ ] **Step 3: Commit**

```bash
cd /Users/Apple/codes/data-label/frontend && git add src/components/studio/CanvasResult.tsx && git commit -m "feat: add CanvasResult router container"
```

---

### Task 6: DataAgentStudio integration

**Files:**
- Modify: `src/pages/DataAgentStudio.tsx`

- [ ] **Step 1: Update imports and state in DataAgentStudio**

Add to imports section at top:

```typescript
import { useChatAction, type CanvasAction } from '../contexts/ChatActionContext';
import CanvasResult from '../components/studio/CanvasResult';
import { useNavigate } from 'react-router-dom';
```

- [ ] **Step 2: Add context and navigation**

Inside the `DataAgentStudio` component function, after the existing state declarations:

```typescript
const navigate = useNavigate();
const { actions, pushAction, removeAction, clearActions, activeIndex, setActiveIndex } = useChatAction();
```

- [ ] **Step 3: Modify handleSend to push action from response**

Update the `handleSend` function. After receiving the response, before `saveExchange`:

```typescript
const handleSend = useCallback(async (text?: string) => {
  const msg = (text || input).trim();
  if (!msg || loading) return;

  setInput('');
  setMessages((prev) => [...prev, { role: 'user', text: msg }]);
  setLoading(true);

  try {
    const response = await studioApi.send(msg);
    if (msg.includes('留学') || msg.includes('需要') || msg.includes('找') || msg.includes('需求')) {
      try {
        await requirementsApi.create({ title: msg.slice(0, 100), description: msg });
      } catch {}
    }

    // Push action to Canvas if response contains structured action
    if (response.action) {
      // Parse action from response — backend returns action in reply as JSON for now
      // The StudioChatResponse doesn't have an 'action' field yet, so we detect from reply
      pushAction({
        type: response.action.type,
        title: response.action.title || actionTypeToTitle(response.action.type),
        data: response.action.data || {},
      } as Omit<CanvasAction, 'id' | 'timestamp'>);
    } else {
      // Try to detect action intent from reply content
      detectActionFromReply(msg, response.reply);
    }

    setMessages((prev) => [...prev, { role: 'agent', text: response.reply, suggestions: response.suggestions, mode: response.mode, steps: response.steps }]);
    saveExchange(msg, response.reply, response.suggestions);
    maybeSpawnTask(msg, response.reply);
  } catch (err) {
    const errorMsg = err instanceof Error ? err.message : '未知错误';
    setMessages((prev) => [...prev, {
      role: 'agent',
      text: `抱歉，服务暂时不可用：${errorMsg}`,
      suggestions: ['重试', '检查后端服务'],
    }]);
  }
  setLoading(false);
}, [input, loading, saveExchange, maybeSpawnTask, pushAction]);
```

- [ ] **Step 4: Add helper functions after the component**

Add these helper functions before the component's closing:

```typescript
// Action type title mapping
function actionTypeToTitle(type: string): string {
  const titles: Record<string, string> = {
    search_tags: '🔍 标签搜索结果',
    analyze_segment: '📊 客群分析结果',
    create_rule: '🛠️ 规则创建结果',
    system_overview: '📋 系统概览',
    import_knowledge: '📄 知识抽取结果',
    knowledge_to_tags: '🏷️ 知识查标签结果',
    run_scenario: '⚡ 场景执行结果',
  };
  return titles[type] || '操作结果';
}

// Detect action from reply content (fallback when backend doesn't return structured action)
function detectActionFromReply(userMsg: string, reply: string): { type: string; title: string; data: any } | null {
  const combined = userMsg + ' ' + reply;
  if (/系统|概览|数据源|总览/i.test(combined)) {
    return {
      type: 'system_overview',
      title: '📋 系统概览',
      data: {
        metrics: [
          { label: '数据源', value: 12, color: '#1565c0' },
          { label: '数据表', value: 156, color: '#2e7d32' },
          { label: '字段', value: 1247, color: '#e65100' },
          { label: '已标注', value: 89, color: '#7b1fa2' },
        ],
        totalScore: 76,
      },
    };
  }
  if (/标签|tag|市场|搜索|查找/i.test(combined)) {
    const keyword = userMsg.replace(/搜索|查找|检索|标签/g, '').trim() || '留学';
    return {
      type: 'search_tags',
      title: `🔍 搜索：${keyword}`,
      data: {
        keyword,
        total: 5,
        tags: [
          { id: '1', name: '留学意向客户', type: '行为标签', coverage: 32000, confidence: 92, status: 'published' },
          { id: '2', name: '跨境汇款活跃', type: '行为标签', coverage: 85000, confidence: 94, status: 'published' },
          { id: '3', name: '有香港账户', type: '账户标签', coverage: 62000, confidence: 88, status: 'published' },
        ],
      },
    };
  }
  return null;
}
```

- [ ] **Step 5: Update StudioChatResponse type**

Open `src/lib/api/studio.ts` and add the `action` field to `StudioChatResponse`:

```typescript
export interface StudioChatResponse {
  reply: string;
  suggestions: string[];
  phase: string | null;
  mode: string;
  steps: { step: number; tool: string; description: string; output: string; status: string }[];
  action?: { type: string; title: string; data: Record<string, unknown> };
  timestamp: string;
}
```

- [ ] **Step 6: Replace the center panel content area**

In the return JSX, replace the `panelCtx` conditional rendering section (around line 682-718) with CanvasResult rendering:

```typescript
{/* Canvas results */}
{actions.length > 0 ? (
  <Box>
    <CanvasResult
      action={actions[activeIndex >= 0 ? activeIndex : actions.length - 1]}
      onRemove={(id) => removeAction(id)}
      onNavigate={(path) => { navigate(path); }}
    />
    {actions.length > 1 && (
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 0.5, mb: 1 }}>
        <HistoryOutlined sx={{ fontSize: 14, color: 'text.secondary' }} />
        <Typography variant="caption" sx={{ fontWeight: 600, color: 'text.secondary' }}>
          执行记录 ({actions.length})
        </Typography>
      </Box>
    )}
    {actions.slice().reverse().map((a) => (
      <Paper key={a.id} variant="outlined"
        onClick={() => setActiveIndex(actions.indexOf(a))}
        sx={{ p: 1, mb: 0.5, borderRadius: 1.5, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 1,
          '&:hover': { bgcolor: 'action.hover' },
          bgcolor: actions.indexOf(a) === activeIndex ? 'rgba(21,101,192,0.06)' : 'transparent' }}>
        <Box sx={{ width: 6, height: 6, borderRadius: '50%', bgcolor: 'primary.main', flexShrink: 0 }} />
        <Typography variant="caption" sx={{ fontWeight: 500 }}>{a.title}</Typography>
        <Typography variant="caption" color="text.secondary" sx={{ ml: 'auto' }}>
          {new Date(a.timestamp).toLocaleTimeString()}
        </Typography>
      </Paper>
    ))}
  </Box>
) : historyLoaded && (
  panelCtx === 'welcome' && !activeScenario ? (
    <WelcomeView ...existing props... />
  ) : panelCtx === 'tags' ? (
    <Box>
      <Typography variant="subtitle2" sx={{ fontWeight: 600, mb: 1.5 }}>标签市场</Typography>
      <StudioMarket />
    </Box>
  ) : panelCtx === 'none' ? (
    // existing message display
  ) : null
)}
```

The exact replacement preserves all existing welcome/tags/none branches but adds the new CanvasResult rendering at higher priority.

- [ ] **Step 7: Verify build**

Run: `cd /Users/Apple/codes/data-label/frontend && npx tsc --noEmit`
Expected: No errors

- [ ] **Step 8: Commit**

```bash
cd /Users/Apple/codes/data-label/frontend && git add src/pages/DataAgentStudio.tsx src/lib/api/studio.ts && git commit -m "feat: integrate ChatActionContext into DataAgentStudio"
```

---

### Task 7: Demo data for Canvas results

**Files:**
- Create: `src/components/studio/demo/demoActions.ts`

- [ ] **Step 1: Create demo action data**

```typescript
// src/components/studio/demo/demoActions.ts
import type { CanvasAction } from '../../../contexts/ChatActionContext';

export const DEMO_ACTIONS: CanvasAction[] = [
  {
    id: 'demo-1',
    type: 'system_overview',
    title: '📋 系统概览',
    data: {
      metrics: [
        { label: '数据源', value: 12, color: '#1565c0' },
        { label: '数据表', value: 156, color: '#2e7d32' },
        { label: '字段', value: 1247, color: '#e65100' },
        { label: '已标注', value: 89, color: '#7b1fa2' },
      ],
      totalScore: 76,
    },
    timestamp: Date.now(),
  },
  {
    id: 'demo-2',
    type: 'search_tags',
    title: '🔍 搜索：留学意向',
    data: {
      keyword: '留学意向',
      total: 5,
      tags: [
        { id: '1', name: '留学意向客户', type: '行为标签', coverage: 32000, confidence: 92, status: 'published' },
        { id: '2', name: '跨境汇款活跃', type: '行为标签', coverage: 85000, confidence: 94, status: 'published' },
        { id: '3', name: '有香港账户', type: '账户标签', coverage: 62000, confidence: 88, status: 'published' },
        { id: '4', name: '境外消费偏好', type: '消费标签', coverage: 28000, confidence: 90, status: 'published' },
        { id: '5', name: '留学家庭', type: '画像标签', coverage: 15000, confidence: 85, status: 'draft' },
      ],
    },
    timestamp: Date.now(),
  },
  {
    id: 'demo-3',
    type: 'analyze_segment',
    title: '📊 客群分析：留学意向客群',
    data: {
      segmentName: '留学意向客群',
      profiles: [
        { name: '张先生', tags: 12, score: 92 },
        { name: '李女士', tags: 8, score: 88 },
        { name: '王先生', tags: 15, score: 95 },
      ],
      tags: [
        { name: '高净值', score: 92 },
        { name: '有留学需求', score: 95 },
        { name: '年龄25-35', score: 78 },
        { name: '教育背景', score: 85 },
      ],
    },
    timestamp: Date.now(),
  },
];
```

- [ ] **Step 2: Commit**

```bash
cd /Users/Apple/codes/data-label/frontend && git add src/components/studio/demo/demoActions.ts && git commit -m "feat: add demo action data for canvas preview"
```


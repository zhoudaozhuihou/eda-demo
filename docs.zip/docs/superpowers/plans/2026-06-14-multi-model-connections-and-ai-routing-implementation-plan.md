# Multi-Model Connections and AI Routing Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add secure DeepSeek, GitHub Models, and generic OpenAI-compatible connections, then route AI-mode planning through the selected connection while keeping all authoritative business facts grounded in backend tools.

**Architecture:** Persist model connections and Run execution context in new tables so existing SQLite databases require no column alterations. Provider adapters implement one internal completion contract; a mode router chooses deterministic Demo planning or validated AI planning. Shared business tools own facts and metrics, and the model only selects tools and explains their typed results.

**Tech Stack:** FastAPI, SQLAlchemy async ORM, Fernet encryption, HTTPX, Pydantic, pytest, React 18, TypeScript, MUI, Axios, Vitest.

---

## File Map

- Create `backend/app/models/llm_connection.py`: encrypted persisted connection metadata.
- Create `backend/app/models/workbench_run_context.py`: mode/provider/model/tool-version provenance without altering `workbench_runs`.
- Create `backend/app/schemas/llm_connection.py`: write/read/test API contracts.
- Create `backend/app/services/llm_connection_service.py`: encryption-safe CRUD and default selection.
- Create `backend/app/llm/openai_compatible.py`: reusable OpenAI-style adapter.
- Create `backend/app/llm/github_models.py`: official GitHub Models adapter.
- Modify `backend/app/llm/deepseek.py` and `backend/app/llm/factory.py`: connection-based provider creation.
- Remove `backend/app/llm/copilot.py` if present.
- Modify `backend/app/routers/llm_config.py`: connection management and test APIs.
- Modify `backend/app/models/__init__.py` and `backend/app/main.py`: register new tables/routes.
- Create `backend/app/services/business_tools.py`: typed authoritative tool layer.
- Create `backend/app/agent/mode_router.py`: Demo versus AI planner routing and output validation.
- Modify `backend/app/routers/studio_chat.py` and `backend/app/services/workbench_run_service.py`: use the router, tools, and Run context.
- Create `backend/tests/test_llm_connections.py`, `backend/tests/test_mode_router.py`, and modify `backend/tests/test_llm.py`.
- Modify `frontend/src/types/llm.ts`, `frontend/src/lib/api/llm.ts`, and `frontend/src/pages/LlmConfig.tsx`.
- Modify `frontend/src/pages/DataAgentStudio.tsx`: explicit Demo/AI labels and request mode.
- Create `frontend/src/pages/LlmConfig.test.tsx`.
- Create `docs/configuration/llm-connections.md`.

### Task 1: Persist Secure LLM Connections

**Files:**
- Create: `backend/app/models/llm_connection.py`
- Create: `backend/app/schemas/llm_connection.py`
- Create: `backend/app/services/llm_connection_service.py`
- Modify: `backend/app/models/__init__.py`
- Create: `backend/tests/test_llm_connections.py`

- [ ] **Step 1: Write failing service tests**

Test:

```python
async def test_connection_secret_is_encrypted_and_never_serialized(db_session):
    created = await service.create(
        db_session,
        name="GitHub Models",
        provider_type="github_models",
        base_url="https://models.github.ai/inference",
        api_key="github_pat_test_secret",
        default_model="openai/gpt-4.1-mini",
        is_default=True,
        config={},
    )
    assert created.encrypted_api_key != "github_pat_test_secret"
    assert "api_key" not in LLMConnectionRead.model_validate(created).model_dump()


async def test_only_one_enabled_connection_is_default(db_session):
    first = await create_connection(db_session, name="one", is_default=True)
    second = await create_connection(db_session, name="two", is_default=True)
    assert (await service.get(db_session, first.id)).is_default is False
    assert (await service.get(db_session, second.id)).is_default is True
```

- [ ] **Step 2: Run tests and confirm missing model/service failure**

Run:

```bash
cd backend
pytest tests/test_llm_connections.py -q
```

Expected: import failure for the new connection model/service.

- [ ] **Step 3: Create portable new-table models**

Implement `LLMConnection`:

```python
class LLMConnection(Base):
    __tablename__ = "llm_connections"

    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    name: Mapped[str] = mapped_column(String(120))
    provider_type: Mapped[str] = mapped_column(String(32), index=True)
    base_url: Mapped[str] = mapped_column(String(500))
    encrypted_api_key: Mapped[str] = mapped_column(Text)
    default_model: Mapped[str] = mapped_column(String(200))
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    is_default: Mapped[bool] = mapped_column(Boolean, default=False)
    config: Mapped[dict] = mapped_column(JSON, default=dict)
    last_test_status: Mapped[str | None] = mapped_column(String(32), nullable=True)
    last_tested_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
```

Use the same application Fernet key and encryption pattern as `connection_service.py`. Read schemas expose `has_api_key: bool`, never encrypted or plaintext secret fields.

- [ ] **Step 4: Implement service invariants**

Create methods:

```python
async def create(db: AsyncSession, payload: LLMConnectionCreate) -> LLMConnection
async def update(db: AsyncSession, connection_id: str, payload: LLMConnectionUpdate) -> LLMConnection
async def delete(db: AsyncSession, connection_id: str) -> None
async def list_connections(db: AsyncSession) -> list[LLMConnection]
async def get_default(db: AsyncSession) -> LLMConnection | None
def decrypt_api_key(connection: LLMConnection) -> str
```

When setting a default, clear all other defaults in the same transaction. A disabled connection cannot become default. An update with an empty/omitted secret preserves the current encrypted secret.

- [ ] **Step 5: Verify service tests**

Run:

```bash
cd backend
pytest tests/test_llm_connections.py -q
```

Expected: all encryption, serialization, and default-selection tests pass.

- [ ] **Step 6: Commit secure connection persistence**

```bash
git add backend/app/models/llm_connection.py backend/app/schemas/llm_connection.py backend/app/services/llm_connection_service.py backend/app/models/__init__.py backend/tests/test_llm_connections.py
git commit -m "feat: persist secure llm connections"
```

### Task 2: Replace Copilot Endpoint with Supported Provider Adapters

**Files:**
- Create: `backend/app/llm/openai_compatible.py`
- Create: `backend/app/llm/github_models.py`
- Modify: `backend/app/llm/deepseek.py`
- Modify: `backend/app/llm/factory.py`
- Delete: `backend/app/llm/copilot.py`
- Modify: `backend/tests/test_llm.py`

- [ ] **Step 1: Write failing provider request-contract tests**

Mock HTTPX and assert:

```python
async def test_github_models_uses_official_inference_endpoint():
    provider = GitHubModelsProvider(
        base_url="https://models.github.ai/inference",
        api_key="test-token",
        model="openai/gpt-4.1-mini",
    )
    await provider.complete([{"role": "user", "content": "hello"}])
    request = httpx_mock.get_request()
    assert str(request.url) == "https://models.github.ai/inference/chat/completions"
    assert request.headers["Authorization"] == "Bearer test-token"


def test_factory_rejects_removed_copilot_provider():
    with pytest.raises(UnsupportedProviderError):
        create_provider(provider_type="copilot", ...)
```

Also test DeepSeek and generic OpenAI-compatible base URL/model propagation, timeout handling, `401`, `429`, malformed JSON, and network failure mapping.

- [ ] **Step 2: Run provider tests and confirm failures**

Run:

```bash
cd backend
pytest tests/test_llm.py -q
```

Expected: GitHub Models tests fail and the old Copilot adapter remains unsupported.

- [ ] **Step 3: Implement one reusable OpenAI-compatible adapter**

The adapter receives explicit `base_url`, secret, model, timeout, and optional headers. It sends:

```json
{
  "model": "configured-model",
  "messages": [{"role": "user", "content": "hello"}],
  "temperature": 0,
  "stream": false
}
```

Normalize base URLs to avoid duplicate `/v1` or `/chat/completions`. Convert provider errors into safe internal exceptions that contain status/category but never response secrets or authorization headers.

- [ ] **Step 4: Implement GitHub Models and DeepSeek wrappers**

`GitHubModelsProvider` must default to `https://models.github.ai/inference` and use `/chat/completions`. Display it as “GitHub Models”; remove all application references to `api.githubcopilot.com/v1` and `CopilotProvider`.

`DeepSeekProvider` and generic OpenAI-compatible connections must delegate transport behavior to the shared adapter while retaining provider-specific defaults.

- [ ] **Step 5: Make provider factory connection-based**

Use a synchronous constructor that receives a persisted connection and decrypted secret:

```python
def create_provider(connection: LLMConnection, api_key: str) -> LLMProvider:
    if connection.provider_type == "deepseek":
        return DeepSeekProvider(...)
    if connection.provider_type == "github_models":
        return GitHubModelsProvider(...)
    if connection.provider_type == "openai_compatible":
        return OpenAICompatibleProvider(...)
    raise UnsupportedProviderError(connection.provider_type)
```

Do not cache decrypted secrets or initialize providers globally.

- [ ] **Step 6: Verify provider contracts**

Run:

```bash
cd backend
pytest tests/test_llm.py -q
```

Expected: all provider and safe-error tests pass.

- [ ] **Step 7: Commit supported provider adapters**

```bash
git add backend/app/llm backend/tests/test_llm.py
git commit -m "feat: support github models and compatible llms"
```

### Task 3: Expose LLM Connection CRUD, Test, and Default APIs

**Files:**
- Modify: `backend/app/routers/llm_config.py`
- Modify: `backend/app/main.py`
- Modify: `backend/tests/test_llm_connections.py`

- [ ] **Step 1: Add failing HTTP API tests**

Cover:

```text
POST   /api/llm/connections
GET    /api/llm/connections
PATCH  /api/llm/connections/{connection_id}
DELETE /api/llm/connections/{connection_id}
POST   /api/llm/connections/{connection_id}/test
POST   /api/llm/connections/{connection_id}/default
```

Assert that list/detail responses never contain `api_key` or `encrypted_api_key`, and that test failures return safe categories such as `unauthorized`, `rate_limited`, `timeout`, or `provider_error`.

- [ ] **Step 2: Run API tests and confirm missing routes**

Run:

```bash
cd backend
pytest tests/test_llm_connections.py -q
```

Expected: connection API requests fail.

- [ ] **Step 3: Implement the router using the service and factory**

Connection test must:

1. load and decrypt the selected connection;
2. build its provider;
3. send a minimal deterministic request;
4. store `last_test_status` and `last_tested_at`;
5. return a safe result without model response content or secret data.

Deleting the current default leaves no default; AI mode will surface the explicit configuration error in Task 6.

- [ ] **Step 4: Keep the existing provider/model catalog endpoint compatible**

The existing read-only catalog may remain for UI suggestions, but persisted connections become the source for active selection. Add GitHub Models and generic OpenAI-compatible provider metadata; remove Copilot metadata.

- [ ] **Step 5: Verify LLM API tests**

Run:

```bash
cd backend
pytest tests/test_llm_connections.py tests/test_llm.py -q
```

Expected: all tests pass.

- [ ] **Step 6: Commit connection APIs**

```bash
git add backend/app/routers/llm_config.py backend/app/main.py backend/tests/test_llm_connections.py
git commit -m "feat: manage llm connections through api"
```

### Task 4: Build the Authoritative Business Tool Layer

**Files:**
- Create: `backend/app/services/business_tools.py`
- Create: `backend/tests/test_business_tools.py`

- [ ] **Step 1: Write failing tool-result tests**

Cover the six initial tools:

```python
@pytest.mark.parametrize(
    "tool_name",
    [
        "search_tags",
        "get_tag_lineage",
        "evaluate_segment",
        "discover_market_opportunities",
        "assess_data_value",
        "get_governance_evidence",
    ],
)
async def test_demo_business_tools_return_typed_results(tool_registry, tool_name):
    result = await tool_registry.execute(tool_name, demo_arguments_for(tool_name), mode="demo")
    assert result.tool_name == tool_name
    assert result.version
    assert result.data
```

Add tests rejecting unknown tools, malformed arguments, overly broad limits, and unknown IDs.

- [ ] **Step 2: Run and confirm missing tool registry failure**

Run:

```bash
cd backend
pytest tests/test_business_tools.py -q
```

Expected: import failure for `business_tools`.

- [ ] **Step 3: Implement typed tool definitions and registry**

Define:

```python
class ToolResult(BaseModel):
    tool_name: str
    version: str
    data: dict[str, Any]


class BusinessToolRegistry:
    async def execute(self, name: str, arguments: dict[str, Any], *, mode: Literal["demo", "ai"]) -> ToolResult:
        ...
```

Each tool owns its argument schema and output schema. Demo implementations call `golden_journey_service`; AI/real implementations call the current database-backed services. The model never supplies counts, scores, opportunity values, or quality metrics as tool arguments.

- [ ] **Step 4: Add execution limits**

Reject unregistered tools, invalid schema, tag-search limits above 100, segment requests without an approved definition, and execution timeouts. Return typed safe errors without fabricating fallback facts.

- [ ] **Step 5: Verify the business tool layer**

Run:

```bash
cd backend
pytest tests/test_business_tools.py -q
```

Expected: all tool, schema, and safety tests pass.

- [ ] **Step 6: Commit authoritative tools**

```bash
git add backend/app/services/business_tools.py backend/tests/test_business_tools.py
git commit -m "feat: add authoritative business tool registry"
```

### Task 5: Persist Run Execution Provenance Without Altering Existing Runs

**Files:**
- Create: `backend/app/models/workbench_run_context.py`
- Modify: `backend/app/models/__init__.py`
- Modify: `backend/app/services/workbench_run_service.py`
- Create: `backend/tests/test_workbench_run_context.py`

- [ ] **Step 1: Write failing provenance tests**

Assert every newly created Run has one context:

```python
async def test_run_records_mode_provider_model_and_tool_versions(db_session):
    run = await create_test_run(db_session, mode="demo")
    context = await get_context(db_session, run.id)
    assert context.mode == "demo"
    assert context.provider_type is None
    assert context.model is None
    assert context.tool_versions["search_tags"]
```

- [ ] **Step 2: Run the test and confirm missing table failure**

Run:

```bash
cd backend
pytest tests/test_workbench_run_context.py -q
```

Expected: import or table failure.

- [ ] **Step 3: Create a one-to-one context table**

Implement:

```python
class WorkbenchRunContext(Base):
    __tablename__ = "workbench_run_contexts"

    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    run_id: Mapped[str] = mapped_column(String(36), unique=True, index=True)
    mode: Mapped[str] = mapped_column(String(16))
    provider_type: Mapped[str | None] = mapped_column(String(32), nullable=True)
    model: Mapped[str | None] = mapped_column(String(200), nullable=True)
    tool_versions: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
```

Do not add fields to the existing `workbench_runs` table. Create the Run and context in one transaction.

- [ ] **Step 4: Verify provenance persistence**

Run:

```bash
cd backend
pytest tests/test_workbench_run_context.py tests/test_workbench_runs.py -q
```

Expected: all tests pass.

- [ ] **Step 5: Commit Run provenance**

```bash
git add backend/app/models/workbench_run_context.py backend/app/models/__init__.py backend/app/services/workbench_run_service.py backend/tests/test_workbench_run_context.py
git commit -m "feat: record workbench run execution context"
```

### Task 6: Add Explicit Demo and AI Mode Routing

**Files:**
- Create: `backend/app/agent/mode_router.py`
- Modify: `backend/app/routers/studio_chat.py`
- Modify: `backend/app/services/workbench_run_service.py`
- Create: `backend/tests/test_mode_router.py`

- [ ] **Step 1: Write failing mode-routing and grounding tests**

Test:

```python
async def test_demo_mode_never_loads_an_llm(mode_router, mocker):
    load_default = mocker.patch("app.agent.mode_router.llm_connection_service.get_default")
    result = await mode_router.execute("留学标签有哪些", mode="demo")
    load_default.assert_not_called()
    assert result.action.action_type == "tag_discovery"


async def test_ai_mode_without_default_connection_returns_configuration_error(mode_router):
    result = await mode_router.execute("留学标签有哪些", mode="ai")
    assert result.error.code == "llm_connection_required"
    assert result.run is None


async def test_ai_plan_cannot_supply_authoritative_metrics(mode_router, fake_provider):
    fake_provider.output = {"tool": "evaluate_segment", "arguments": {"customer_count": 999999}}
    result = await mode_router.execute("圈选留学客户", mode="ai")
    assert result.error.code == "invalid_tool_arguments"
    assert result.run is None
```

- [ ] **Step 2: Run and confirm missing router failure**

Run:

```bash
cd backend
pytest tests/test_mode_router.py -q
```

Expected: import failure for `mode_router`.

- [ ] **Step 3: Implement validated planner output**

Define an allow-listed plan schema:

```python
class PlannedToolCall(BaseModel):
    tool: Literal[
        "search_tags",
        "get_tag_lineage",
        "evaluate_segment",
        "discover_market_opportunities",
        "assess_data_value",
        "get_governance_evidence",
    ]
    arguments: dict[str, Any]


class ActionPlan(BaseModel):
    action_type: str
    calls: list[PlannedToolCall] = Field(min_length=1, max_length=6)
```

Demo mode uses deterministic classification/planning and never loads a model connection. AI mode loads the enabled default connection, requests JSON plan output, validates it with Pydantic, executes only registered tools, and creates a Run only after successful validated execution.

- [ ] **Step 4: Generate Chat explanation from typed tool results**

In Demo mode, use deterministic templates. In AI mode, the provider may explain the completed tool results, but the response must include a compact JSON facts block in the prompt and must not be parsed as a source of business values. If explanation generation fails after tools succeed, return a deterministic explanation of the same result and keep the completed Run.

- [ ] **Step 5: Integrate Studio Chat and persist Run context**

Use the request’s current mode for new messages only. Existing messages and Runs remain unchanged when switching modes. Persist provider/model only for AI Runs; persist tool versions for both modes.

- [ ] **Step 6: Verify mode routing**

Run:

```bash
cd backend
pytest tests/test_mode_router.py tests/test_workbench_runs.py tests/test_business_tools.py tests/test_workbench_run_context.py -q
```

Expected: all routing, grounding, and provenance tests pass.

- [ ] **Step 7: Commit mode routing**

```bash
git add backend/app/agent/mode_router.py backend/app/routers/studio_chat.py backend/app/services/workbench_run_service.py backend/tests/test_mode_router.py
git commit -m "feat: route demo and ai planning safely"
```

### Task 7: Build the LLM Connection Management UI

**Files:**
- Modify: `frontend/src/types/llm.ts`
- Modify: `frontend/src/lib/api/llm.ts`
- Modify: `frontend/src/pages/LlmConfig.tsx`
- Modify: `frontend/src/pages/DataAgentStudio.tsx`
- Create: `frontend/src/pages/LlmConfig.test.tsx`

- [ ] **Step 1: Write failing UI behavior tests**

Test:

- list shows provider, model, enabled/default, and last test status;
- create/edit forms show a write-only secret input;
- GitHub Models helper states PAT permission `models:read`;
- connection test displays safe success/failure status;
- setting default updates the selected row;
- secret values never render after save.
- Studio shows explicit `演示模式` and `AI 模式` labels, sends the selected mode with new Chat requests, and does not rewrite existing session messages or Runs when switching.

Example:

```tsx
it("does not render a saved secret", async () => {
  render(<LlmConfig />);
  expect(await screen.findByText("GitHub Models")).toBeInTheDocument();
  expect(screen.queryByDisplayValue("github_pat_test_secret")).not.toBeInTheDocument();
});
```

- [ ] **Step 2: Run and confirm current read-only page failure**

Run:

```bash
cd frontend
npm test -- src/pages/LlmConfig.test.tsx
```

Expected: tests fail because the page is read-only.

- [ ] **Step 3: Implement connection API types and client**

Add typed methods for create, list, update, delete, test, and set-default. The update payload includes `api_key` only when the user enters a replacement. Never store a secret in localStorage or React state after a successful save.

- [ ] **Step 4: Implement the management experience**

Use a connection list plus create/edit dialog. Provider selection supplies sensible defaults:

```text
DeepSeek: https://api.deepseek.com
GitHub Models: https://models.github.ai/inference
OpenAI Compatible: user-provided
```

Show clear non-secret errors and disable “Set default” for disabled connections.

Update Studio’s mode control so its labels describe actual behavior. Pass the selected mode on every new Chat request and persist the session summary mode, but do not mutate already persisted messages or Runs. When AI mode has no valid default connection, show the backend configuration error with an action that navigates to LLM configuration and a visible option to return to Demo mode.

- [ ] **Step 5: Verify UI tests and build**

Run:

```bash
cd frontend
npm test -- src/pages/LlmConfig.test.tsx
npm run build
```

Expected: tests and build pass.

- [ ] **Step 6: Commit connection management UI**

```bash
git add frontend/src/types/llm.ts frontend/src/lib/api/llm.ts frontend/src/pages/LlmConfig.tsx frontend/src/pages/DataAgentStudio.tsx frontend/src/pages/LlmConfig.test.tsx
git commit -m "feat: manage multi-model connections"
```

### Task 8: Cross-Provider Acceptance and Configuration Documentation

**Files:**
- Create: `backend/tests/test_ai_mode_acceptance.py`
- Create: `docs/configuration/llm-connections.md`

- [ ] **Step 1: Write provider-independent AI-mode acceptance tests**

Use mocked DeepSeek, GitHub Models, and OpenAI-compatible providers that return the same valid plan. Assert each:

1. selects the requested business tool;
2. receives the same grounded tool result;
3. produces the same authoritative segment/tag/opportunity/data-value metrics;
4. records its provider/model in `workbench_run_contexts`;
5. returns safe errors for `401`, `429`, timeout, malformed plan, and unknown tool.

- [ ] **Step 2: Run the acceptance tests**

Run:

```bash
cd backend
pytest tests/test_ai_mode_acceptance.py -q
```

Expected: the test exposes any provider-specific routing drift.

- [ ] **Step 3: Close only acceptance failures in the owning provider/router/tool**

Preserve the single internal provider contract and the shared tool outputs. Do not special-case authoritative business values by provider.

- [ ] **Step 4: Document connection and deployment configuration**

Document:

- DeepSeek, GitHub Models, and OpenAI-compatible setup;
- GitHub Models official endpoint and PAT `models:read` permission;
- GitHub Models experimentation/rate-limit caveat;
- secret encryption and key backup requirements for single-machine migration;
- environment-independent base URL configuration;
- SQLite creation of new tables and PostgreSQL-compatible schema design;
- AI-mode error behavior and Demo-mode fallback.

- [ ] **Step 5: Run full verification**

Run:

```bash
cd backend
pytest -q
cd ../frontend
npm test
npm run build
```

Expected: all tests and build pass.

- [ ] **Step 6: Verify through the in-app browser**

Create a non-secret test connection or use a mocked local provider, set it as default, switch Studio to AI mode, execute a supported prompt, and confirm the Canvas uses grounded business results. Switch back to Demo mode and confirm no external provider call occurs.

- [ ] **Step 7: Commit acceptance and documentation**

```bash
git add backend/tests/test_ai_mode_acceptance.py docs/configuration/llm-connections.md
git commit -m "test: verify grounded multi-model ai mode"
```

## Completion Criteria

- DeepSeek, GitHub Models, and generic OpenAI-compatible connections can be securely created, tested, enabled, and selected.
- GitHub Models uses `https://models.github.ai/inference/chat/completions`; the unsupported Copilot application endpoint is absent.
- Secrets are encrypted, write-only through APIs, absent from logs, and never returned to the frontend.
- Demo mode never requires an LLM; AI mode requires a valid default connection and validates every plan.
- Models cannot inject authoritative customer counts, scores, opportunity values, or quality metrics.
- Every new Run records mode, provider/model where applicable, and tool versions in a new portable context table.
- Full backend tests, frontend tests, build, browser acceptance, and configuration documentation pass.

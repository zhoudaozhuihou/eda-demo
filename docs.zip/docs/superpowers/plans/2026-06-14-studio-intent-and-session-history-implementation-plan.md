# Studio Intent and Session History Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make natural tag questions create matching Canvas Runs, and add persisted Studio conversations that restore Chat messages and the latest Canvas result together.

**Architecture:** Keep executable-intent classification exclusively in the backend. Add a new `studio_sessions` table without altering existing SQLite tables, then let Chat messages and Workbench Runs continue using their existing `session_id` fields. The frontend owns only presentation and session selection; it never infers business actions from assistant text.

**Tech Stack:** FastAPI, SQLAlchemy async ORM, SQLite with PostgreSQL-compatible models, pytest, React 18, TypeScript, MUI, Axios, Vitest, Testing Library.

---

## File Map

- Create `backend/app/models/studio_session.py`: persisted Studio session metadata.
- Create `backend/app/services/studio_session_service.py`: create, update, list, archive, and synchronize session summaries.
- Create `backend/app/routers/studio_sessions.py`: `/api/studio/sessions` API.
- Create `backend/tests/test_studio_sessions.py`: session API and restore contract tests.
- Modify `backend/app/services/workbench_run_service.py`: natural Chinese tag-discovery intent and clean keyword extraction.
- Modify `backend/app/routers/studio_chat.py`: ensure a session exists, update title/count/latest Run after Chat.
- Modify `backend/app/models/__init__.py` and `backend/app/main.py`: register the new model and router.
- Modify `backend/tests/test_workbench_runs.py`: executable versus explanatory intent regressions.
- Create `frontend/vitest.config.ts` and `frontend/src/test/setup.ts`: frontend test harness.
- Create `frontend/src/components/studio/SessionHistoryRail.tsx`: adaptive history rail.
- Create `frontend/src/components/studio/SessionHistoryRail.test.tsx`: rail interaction tests.
- Modify `frontend/src/lib/api/studio.ts`: session API types and calls.
- Modify `frontend/src/pages/DataAgentStudio.tsx`: session lifecycle, parallel restore, and adaptive layout.
- Create `frontend/src/pages/DataAgentStudio.test.tsx`: restore and Canvas preservation tests.

### Task 1: Repair Natural Tag-Discovery Intent

**Files:**
- Modify: `backend/tests/test_workbench_runs.py`
- Modify: `backend/app/services/workbench_run_service.py`

- [ ] **Step 1: Add failing classifier regressions**

Add parameterized tests that call `classify_workbench_action()` directly:

```python
@pytest.mark.parametrize(
    ("prompt", "keyword"),
    [
        ("留学标签有哪些", "留学"),
        ("有哪些留学标签", "留学"),
        ("列出高净值标签", "高净值"),
    ],
)
def test_natural_tag_questions_create_tag_discovery(prompt: str, keyword: str):
    action = classify_workbench_action(prompt)
    assert action is not None
    assert action.action_type == "tag_discovery"
    assert action.parameters["keyword"] == keyword


def test_explanatory_tag_question_creates_no_action():
    assert classify_workbench_action("什么是标签") is None
```

- [ ] **Step 2: Run the regressions and confirm the current failure**

Run:

```bash
cd backend
pytest tests/test_workbench_runs.py -q
```

Expected: the three natural-list questions fail because no `tag_discovery` action is returned; the explanatory question passes.

- [ ] **Step 3: Implement the minimal backend-only classifier change**

Replace the tag rule with explicit command and natural-list patterns, and strip question words during keyword extraction:

```python
TAG_DISCOVERY_PATTERNS = (
    re.compile(r"(搜索|查找|检索|查询|查看|列出|发现|推荐).{0,16}(标签|tags?)", re.I),
    re.compile(r"(有哪些|有什么).{0,16}(标签|tags?)", re.I),
    re.compile(r"(标签|tags?).{0,8}(有哪些|有什么)", re.I),
    re.compile(r"标签市场", re.I),
)

TAG_QUESTION_WORDS = (
    "有哪些",
    "有什么",
    "标签有哪些",
    "标签有什么",
    "标签",
    "tag",
    "tags",
)
```

Keep “什么是标签” outside executable patterns. Update `_extract_keyword()` to remove `TAG_QUESTION_WORDS`, action verbs, punctuation, and surrounding whitespace, returning `None` only when no business keyword remains.

- [ ] **Step 4: Verify classifier and API behavior**

Run:

```bash
cd backend
pytest tests/test_workbench_runs.py -q
```

Expected: all tests pass, including “留学标签有哪些” returning a `tag_discovery` Run and “什么是标签” returning no Run.

- [ ] **Step 5: Commit the intent repair**

```bash
git add backend/app/services/workbench_run_service.py backend/tests/test_workbench_runs.py
git commit -m "fix: recognize natural tag discovery questions"
```

### Task 2: Add the Persisted Studio Session Model and Service

**Files:**
- Create: `backend/app/models/studio_session.py`
- Create: `backend/app/services/studio_session_service.py`
- Modify: `backend/app/models/__init__.py`
- Test: `backend/tests/test_studio_sessions.py`

- [ ] **Step 1: Write failing service tests**

Cover creation defaults, first-prompt title derivation, latest Run synchronization, active-session clearing, default-list archive filtering, and explicit archived-session reads:

```python
async def test_create_session_has_welcome_defaults(db_session):
    session = await studio_session_service.create(db_session, mode="demo")
    assert session.title == "新对话"
    assert session.mode == "demo"
    assert session.message_count == 0
    assert session.latest_run_id is None


async def test_sync_activity_uses_first_prompt_and_latest_run(db_session):
    session = await studio_session_service.create(db_session, mode="demo")
    updated = await studio_session_service.sync_activity(
        db_session,
        session.id,
        first_user_prompt="留学标签有哪些",
        message_count=2,
        latest_run_id="run-1",
        scenario_type="tag_discovery",
    )
    assert updated.title == "留学标签有哪些"
    assert updated.latest_run_id == "run-1"
    assert updated.message_count == 2
```

- [ ] **Step 2: Run the new test file and confirm it fails**

Run:

```bash
cd backend
pytest tests/test_studio_sessions.py -q
```

Expected: collection fails because `StudioSession` and `studio_session_service` do not exist.

- [ ] **Step 3: Create a PostgreSQL-compatible model using only portable column types**

Implement:

```python
class StudioSession(Base):
    __tablename__ = "studio_sessions"

    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    title: Mapped[str] = mapped_column(String(120), default="新对话")
    scenario_type: Mapped[str | None] = mapped_column(String(64), nullable=True)
    mode: Mapped[str] = mapped_column(String(16), default="demo")
    latest_run_id: Mapped[str | None] = mapped_column(String(36), nullable=True)
    message_count: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    archived_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
```

Do not add columns to `chat_messages` or `workbench_runs`; their existing `session_id` values remain the relationship key. Register `StudioSession` in `backend/app/models/__init__.py` so `Base.metadata.create_all()` creates the new table on SQLite and PostgreSQL.

- [ ] **Step 4: Implement focused session service methods**

Create methods with these signatures:

```python
async def create(db: AsyncSession, *, mode: str, session_id: str | None = None) -> StudioSession
async def get(db: AsyncSession, session_id: str, *, include_archived: bool = False) -> StudioSession | None
async def list_active(db: AsyncSession, *, limit: int = 100) -> list[StudioSession]
async def update(db: AsyncSession, session_id: str, *, title: str | None, mode: str | None) -> StudioSession
async def sync_activity(
    db: AsyncSession,
    session_id: str,
    *,
    first_user_prompt: str | None,
    message_count: int,
    latest_run_id: str | None,
    scenario_type: str | None,
) -> StudioSession
async def archive(db: AsyncSession, session_id: str) -> StudioSession
async def clear_activity(db: AsyncSession, session_id: str) -> StudioSession
```

Title derivation must normalize whitespace and truncate to 30 visible characters. `sync_activity()` must preserve a manually edited title by replacing only the default `新对话` title. `clear_activity()` deletes messages and Runs for only the selected session, resets its summary to Welcome defaults, and leaves other sessions unchanged.

- [ ] **Step 5: Run service tests**

Run:

```bash
cd backend
pytest tests/test_studio_sessions.py -q
```

Expected: service tests pass.

- [ ] **Step 6: Commit the model and service**

```bash
git add backend/app/models/studio_session.py backend/app/models/__init__.py backend/app/services/studio_session_service.py backend/tests/test_studio_sessions.py
git commit -m "feat: persist studio session metadata"
```

### Task 3: Expose Session APIs and Synchronize Chat Activity

**Files:**
- Create: `backend/app/routers/studio_sessions.py`
- Modify: `backend/app/routers/studio_chat.py`
- Modify: `backend/app/main.py`
- Modify: `backend/tests/test_studio_sessions.py`

- [ ] **Step 1: Add failing API contract tests**

Test:

```python
async def test_session_restore_returns_messages_and_latest_run(client):
    created = (await client.post("/api/studio/sessions", json={"mode": "demo"})).json()
    await client.post("/api/studio/chat", json={"session_id": created["id"], "message": "留学标签有哪些"})

    detail = (await client.get(f"/api/studio/sessions/{created['id']}")).json()
    assert detail["messages"][-1]["role"] == "assistant"
    assert detail["latest_run"]["action_type"] == "tag_discovery"


async def test_archive_removes_session_from_default_list(client):
    created = (await client.post("/api/studio/sessions", json={"mode": "demo"})).json()
    await client.post(f"/api/studio/sessions/{created['id']}/archive")
    listed = (await client.get("/api/studio/sessions")).json()
    assert created["id"] not in {item["id"] for item in listed}


async def test_clear_removes_only_active_session_activity(client):
    first = (await client.post("/api/studio/sessions", json={"mode": "demo"})).json()
    second = (await client.post("/api/studio/sessions", json={"mode": "demo"})).json()
    await client.post("/api/studio/chat", json={"session_id": first["id"], "message": "留学标签有哪些"})
    await client.post("/api/studio/chat", json={"session_id": second["id"], "message": "留学标签有哪些"})

    await client.post(f"/api/studio/sessions/{first['id']}/clear")
    first_detail = (await client.get(f"/api/studio/sessions/{first['id']}")).json()
    second_detail = (await client.get(f"/api/studio/sessions/{second['id']}")).json()
    assert first_detail["messages"] == []
    assert first_detail["latest_run"] is None
    assert second_detail["messages"]
```

- [ ] **Step 2: Run API tests and confirm route failures**

Run:

```bash
cd backend
pytest tests/test_studio_sessions.py -q
```

Expected: requests fail with `404` because the session router is not registered.

- [ ] **Step 3: Implement the session router**

Expose:

```text
POST   /api/studio/sessions
GET    /api/studio/sessions
GET    /api/studio/sessions/{session_id}
PATCH  /api/studio/sessions/{session_id}
POST   /api/studio/sessions/{session_id}/archive
POST   /api/studio/sessions/{session_id}/clear
```

The detail response must be:

```json
{
  "session": {"id": "...", "title": "...", "mode": "demo", "message_count": 2},
  "messages": [],
  "latest_run": null
}
```

Load messages and latest Run by the existing `session_id`. Return `404` for missing or archived sessions on normal reads.

- [ ] **Step 4: Synchronize session metadata after each Chat request**

In `studio_chat.py`:

1. Call `create(..., session_id=request.session_id)` if the browser sends a previously unseen ID.
2. Persist user and assistant messages using the existing flow.
3. Persist the Workbench Run when classification returns an action.
4. Call `sync_activity()` with the first user prompt, current message count, action type, and latest Run ID.
5. Return the existing Chat response shape unchanged so current clients remain compatible.

- [ ] **Step 5: Register the router and verify the backend contract**

Run:

```bash
cd backend
pytest tests/test_studio_sessions.py tests/test_workbench_runs.py -q
```

Expected: all session and Run tests pass.

- [ ] **Step 6: Commit session APIs**

```bash
git add backend/app/routers/studio_sessions.py backend/app/routers/studio_chat.py backend/app/main.py backend/tests/test_studio_sessions.py
git commit -m "feat: expose studio session restore APIs"
```

### Task 4: Add the Frontend Test Harness and Session API Client

**Files:**
- Modify: `frontend/package.json`
- Create: `frontend/vitest.config.ts`
- Create: `frontend/src/test/setup.ts`
- Modify: `frontend/src/lib/api/studio.ts`
- Create: `frontend/src/lib/api/studio.test.ts`

- [ ] **Step 1: Add the frontend test dependencies and scripts**

Add:

```json
"scripts": {
  "dev": "vite",
  "build": "tsc && vite build",
  "preview": "vite preview",
  "test": "vitest run"
}
```

Add dev dependencies `vitest`, `jsdom`, `@testing-library/react`, `@testing-library/jest-dom`, and `@testing-library/user-event`.

- [ ] **Step 2: Configure Vitest**

Use `jsdom`, load `frontend/src/test/setup.ts`, and add `@testing-library/jest-dom/vitest`. Do not change production Vite behavior.

- [ ] **Step 3: Write failing session API tests**

Mock Axios and assert the client calls the exact routes for create, list, detail, rename, and archive. Define exported types:

```typescript
export interface StudioSessionSummary {
  id: string;
  title: string;
  scenario_type: string | null;
  mode: "demo" | "ai";
  latest_run_id: string | null;
  message_count: number;
  created_at: string;
  updated_at: string;
}

export interface StudioSessionDetail {
  session: StudioSessionSummary;
  messages: ChatMessage[];
  latest_run: WorkbenchRun | null;
}
```

- [ ] **Step 4: Implement session API methods**

Add:

```typescript
createStudioSession(mode: "demo" | "ai")
listStudioSessions()
getStudioSession(sessionId: string)
updateStudioSession(sessionId: string, patch: { title?: string; mode?: "demo" | "ai" })
archiveStudioSession(sessionId: string)
clearStudioSession(sessionId: string)
```

Replace the single immutable local session ID with an active-session key. Existing users with `da_studio_session_id` must have that ID adopted by the backend on first Chat request.

- [ ] **Step 5: Install and verify the frontend test harness**

Run:

```bash
cd frontend
npm install
npm test -- src/lib/api/studio.test.ts
```

Expected: API tests pass.

- [ ] **Step 6: Commit the harness and API client**

```bash
git add frontend/package.json frontend/package-lock.json frontend/vitest.config.ts frontend/src/test/setup.ts frontend/src/lib/api/studio.ts frontend/src/lib/api/studio.test.ts
git commit -m "test: add studio frontend test harness"
```

### Task 5: Build the Adaptive Session History Rail

**Files:**
- Create: `frontend/src/components/studio/SessionHistoryRail.tsx`
- Create: `frontend/src/components/studio/SessionHistoryRail.test.tsx`

- [ ] **Step 1: Write failing component tests**

Test that:

- wide mode displays title, scenario type, update time, and latest Run status;
- collapsed mode displays compact selection controls;
- mobile mode uses a drawer;
- New conversation, selection, rename, and archive callbacks receive the correct session ID.
- Clear history invokes the active-session callback and leaves other list items intact.

Example:

```tsx
it("selects a session from the wide rail", async () => {
  const onSelect = vi.fn();
  render(<SessionHistoryRail viewport="wide" sessions={sessions} activeSessionId="s1" onSelect={onSelect} />);
  await userEvent.click(screen.getByText("留学标签有哪些"));
  expect(onSelect).toHaveBeenCalledWith("s2");
});
```

- [ ] **Step 2: Run and confirm component failure**

Run:

```bash
cd frontend
npm test -- src/components/studio/SessionHistoryRail.test.tsx
```

Expected: test collection fails because the component does not exist.

- [ ] **Step 3: Implement one component with three presentation modes**

Use MUI breakpoints and props rather than duplicating business state:

```typescript
type SessionHistoryViewport = "wide" | "collapsed" | "mobile";

interface SessionHistoryRailProps {
  viewport: SessionHistoryViewport;
  sessions: StudioSessionSummary[];
  activeSessionId: string | null;
  loading: boolean;
  onNew: () => void;
  onSelect: (sessionId: string) => void;
  onRename: (sessionId: string, title: string) => void;
  onArchive: (sessionId: string) => void;
  onClear: (sessionId: string) => void;
}
```

Place the component between primary navigation and Canvas. The component must not own Chat messages or Runs.

- [ ] **Step 4: Verify component behavior**

Run:

```bash
cd frontend
npm test -- src/components/studio/SessionHistoryRail.test.tsx
```

Expected: all rail tests pass.

- [ ] **Step 5: Commit the history rail**

```bash
git add frontend/src/components/studio/SessionHistoryRail.tsx frontend/src/components/studio/SessionHistoryRail.test.tsx
git commit -m "feat: add adaptive studio session history rail"
```

### Task 6: Integrate Session Restore into Data Agent Studio

**Files:**
- Modify: `frontend/src/pages/DataAgentStudio.tsx`
- Create: `frontend/src/pages/DataAgentStudio.test.tsx`

- [ ] **Step 1: Write failing page-level behavior tests**

Cover:

```tsx
it("restores messages and latest canvas run when selecting a session", async () => {
  render(<DataAgentStudio />);
  await userEvent.click(screen.getByText("留学标签有哪些"));
  expect(await screen.findByText("留学汇款")).toBeInTheDocument();
  expect(await screen.findByTestId("workbench-run-card")).toHaveTextContent("tag_discovery");
});

it("keeps the current canvas run after an explanatory follow-up", async () => {
  render(<DataAgentStudio />);
  await sendMessage("留学标签有哪些");
  await sendMessage("什么是标签");
  expect(screen.getByTestId("workbench-run-card")).toHaveTextContent("tag_discovery");
});

it("new conversation shows the welcome canvas", async () => {
  render(<DataAgentStudio />);
  await userEvent.click(screen.getByRole("button", { name: "新建对话" }));
  expect(await screen.findByText("从银行知识到业务机会")).toBeInTheDocument();
});
```

- [ ] **Step 2: Run page tests and confirm current failures**

Run:

```bash
cd frontend
npm test -- src/pages/DataAgentStudio.test.tsx
```

Expected: tests fail because the page has no persisted session rail or restore flow.

- [ ] **Step 3: Refactor page state around the active persisted session**

Implement these state boundaries:

```typescript
const [sessions, setSessions] = useState<StudioSessionSummary[]>([]);
const [activeSessionId, setActiveSessionId] = useState<string | null>(null);
const [messages, setMessages] = useState<ChatMessage[]>([]);
const [selectedRun, setSelectedRun] = useState<WorkbenchRun | null>(null);
const [restoring, setRestoring] = useState(false);
```

On session selection, fetch one detail response and update `messages` and `selectedRun` in the same completion handler. During restoration, retain whichever part succeeds and show a recoverable inline error. A Chat response with `run: null` must append messages but preserve `selectedRun`.

The Clear history action calls `clearStudioSession(activeSessionId)`, resets only the active page state to Welcome content, and refreshes session summaries without changing other sessions.

- [ ] **Step 4: Add Welcome Canvas content**

When the active session contains no messages and no Run, show a concise introduction with the four golden-journey suggestions:

```text
留学标签有哪些
圈选有留学需求且可营销触达的客户
有哪些留学金融市场机会
分析这些数据的价值
```

Clicking a suggestion sends it through the normal Chat API.

- [ ] **Step 5: Verify page tests and production build**

Run:

```bash
cd frontend
npm test -- src/pages/DataAgentStudio.test.tsx src/components/studio/SessionHistoryRail.test.tsx
npm run build
```

Expected: tests pass and TypeScript/Vite build succeeds.

- [ ] **Step 6: Commit Studio integration**

```bash
git add frontend/src/pages/DataAgentStudio.tsx frontend/src/pages/DataAgentStudio.test.tsx
git commit -m "feat: restore studio chat and canvas by session"
```

### Task 7: Full Regression and Browser Acceptance

**Files:**
- Create: `docs/demo/studio-session-acceptance.md`

- [ ] **Step 1: Add an executable manual acceptance checklist**

Document exact actions and expected results:

1. Open Studio and see Welcome content.
2. Ask “留学标签有哪些”; Chat and Canvas both show tag discovery.
3. Ask “什么是标签”; Chat changes but Canvas keeps the tag result.
4. Create another conversation and see Welcome content.
5. Return to the first conversation and see messages plus the tag Canvas Run.
6. Refresh and confirm the active session restores.
7. Archive the second conversation and confirm it leaves the default list.
8. Verify wide, collapsed, and mobile history presentation.

- [ ] **Step 2: Run the focused and full automated suites**

Run:

```bash
cd backend
pytest tests/test_workbench_runs.py tests/test_studio_sessions.py -q
cd ../frontend
npm test
npm run build
```

Expected: all commands pass.

- [ ] **Step 3: Verify through the in-app browser**

Start the existing backend and frontend development servers, open the current localhost application, and execute the checklist. Confirm browser console has no new errors and the existing Canvas/result-card layout remains unchanged.

- [ ] **Step 4: Commit the acceptance record**

```bash
git add docs/demo/studio-session-acceptance.md
git commit -m "docs: add studio session acceptance checklist"
```

## Completion Criteria

- “留学标签有哪些”, “有哪些留学标签”, and “列出高净值标签” create `tag_discovery` Runs.
- “什么是标签” creates no Run and preserves the selected Canvas result.
- Studio sessions persist in SQLite, list in the adaptive rail, and restore Chat plus latest Canvas Run together.
- The implementation creates only a new table, preserving compatibility with the current SQLite database and later PostgreSQL migration.
- Backend tests, frontend tests, frontend build, and browser acceptance all pass.

# Unified Workbench Run Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make backend-persisted Workbench Runs the single source of truth for Studio Chat actions, progress, Canvas results, and session restoration.

**Architecture:** Add a portable SQLAlchemy `WorkbenchRun` model and a focused service that classifies executable chat requests and builds structured result payloads. Studio Chat creates an optional Run and schedules backend-owned execution; the frontend restores and polls the Run, adapts its structured result into existing Canvas result components, and no longer derives execution state from chat text.

**Tech Stack:** FastAPI, SQLAlchemy async, Pydantic, SQLite, pytest, React 18, TypeScript, MUI, Axios.

---

## File Structure

- Create `backend/app/models/workbench_run.py`: persisted Workbench Run fields and portable JSON columns.
- Create `backend/app/services/workbench_run_service.py`: backend Action classification, result construction, and Run completion.
- Create `backend/app/routers/studio_runs.py`: Run-by-ID and latest-Run APIs.
- Modify `backend/app/routers/studio_chat.py`: persist the chat exchange and return an optional Run.
- Modify `backend/app/models/__init__.py` and `backend/app/main.py`: register the model and router.
- Create `backend/tests/test_workbench_runs.py`: Chat Action and session restoration contract tests.
- Modify `frontend/src/lib/api/studio.ts`: Run types and Run APIs.
- Create `frontend/src/components/studio/WorkbenchRunCard.tsx`: render Run progress, errors, generic fallback, and existing Canvas result components.
- Modify `frontend/src/pages/DataAgentStudio.tsx`: restore/select/poll Runs and remove frontend execution inference.

### Task 1: Persisted Run and Read Contract

**Files:**
- Create: `backend/tests/test_workbench_runs.py`
- Create: `backend/app/models/workbench_run.py`
- Create: `backend/app/routers/studio_runs.py`
- Modify: `backend/app/models/__init__.py`
- Modify: `backend/app/main.py`

- [ ] **Step 1: Write failing tests for Run reads**

Add tests that insert two Runs for different sessions, assert `GET /api/studio/runs/{id}` returns the structured payload, and assert `GET /api/studio/runs/latest?session_id=...` returns only that session's newest Run.

- [ ] **Step 2: Run tests and verify RED**

Run: `cd backend && pytest tests/test_workbench_runs.py -v`

Expected: collection or request failures because `WorkbenchRun` and the Run endpoints do not exist.

- [ ] **Step 3: Implement the model and read router**

Define `WorkbenchRun` with `session_id`, `request_message_id`, `action_type`, `title`, `status`, `progress`, `current_step`, `steps`, `result_type`, `result_data`, `error`, and timestamps. Expose a shared Pydantic output schema from the Run router and serialize one Run consistently.

- [ ] **Step 4: Register model and router**

Import `WorkbenchRun` from `app.models` and include `studio_runs_router` in `app.main`.

- [ ] **Step 5: Run tests and verify GREEN**

Run: `cd backend && pytest tests/test_workbench_runs.py -v`

Expected: Run read and session-restoration tests pass.

### Task 2: Studio Chat Action and Execution Contract

**Files:**
- Modify: `backend/tests/test_workbench_runs.py`
- Create: `backend/app/services/workbench_run_service.py`
- Modify: `backend/app/routers/studio_chat.py`

- [ ] **Step 1: Write failing Chat contract tests**

Test that an explanatory message returns `run: null`, a supported executable message returns a pending Run with the expected `action_type`, and the latest-Run endpoint later returns the same Run with a terminal status and structured result.

- [ ] **Step 2: Run tests and verify RED**

Run: `cd backend && pytest tests/test_workbench_runs.py -v`

Expected: Chat responses have no `run` field and no Run is persisted.

- [ ] **Step 3: Implement backend-owned Action classification**

Create deterministic classification for:

- `tag_discovery`
- `customer_segment`
- `market_opportunity`
- `data_value_analysis`

Return `None` for explanatory chat. Keep this logic behind the service boundary so a later planner can replace it without changing the API.

- [ ] **Step 4: Implement backend-owned Run execution**

Create the Run after the user message is persisted. Schedule a FastAPI background task that updates the same Run to `succeeded` with completed steps and a result payload compatible with the existing Canvas components. Persist failures as `failed` with a safe error.

- [ ] **Step 5: Persist the complete chat exchange**

Make Studio Chat persist user and assistant messages itself. Remove the frontend requirement to call the message-save endpoint for every exchange.

- [ ] **Step 6: Run focused and full backend tests**

Run:

```bash
cd backend
pytest tests/test_workbench_runs.py -v
pytest -q
```

Expected: focused tests pass and the existing backend suite has no new failures.

### Task 3: Frontend Run API and Result Card

**Files:**
- Modify: `frontend/src/lib/api/studio.ts`
- Create: `frontend/src/components/studio/WorkbenchRunCard.tsx`

- [ ] **Step 1: Define the Run contract**

Add TypeScript types matching the backend output and add `getRun(id)` and `getLatestRun()` API methods using the existing persisted Studio session ID.

- [ ] **Step 2: Build one Run lifecycle card**

Render pending/running progress, current step, step list, failed error state, and succeeded result in one card. For succeeded known results, adapt `result_type` and `result_data` into the existing `CanvasResult`. For unknown or malformed results, render a generic summary without fabricated data.

- [ ] **Step 3: Verify TypeScript contract**

Run: `cd frontend && npm run build`

Expected: no new errors from Run API or Run card files. Record existing unrelated build failures separately if they remain.

### Task 4: Workbench State Refactor

**Files:**
- Modify: `frontend/src/pages/DataAgentStudio.tsx`

- [ ] **Step 1: Replace independent execution state with selected Run**

On mount, load chat history and latest Run for the current session. Store the selected/latest Run and poll only while its status is `pending` or `running`.

- [ ] **Step 2: Make Chat preserve or select Canvas correctly**

When Chat returns `run: null`, append the reply and keep the current Run unchanged. When Chat returns a Run, select it and clear a manually selected scenario preview.

- [ ] **Step 3: Remove conflicting frontend execution inference**

Remove `detectPanelContext`, `detectActionFromReply`, `maybeSpawnTask`, `spawnBgTask`, sleep-based progress, task list state, and ChatActionContext usage from the Workbench.

- [ ] **Step 4: Apply explicit Canvas priority**

Render selected/latest Run first, then a manually selected scenario, then `WelcomeView`. Welcome chat messages must not hide the Welcome view.

- [ ] **Step 5: Verify build**

Run: `cd frontend && npm run build`

Expected: Workbench changes compile. Fix any build error caused by this task; document unrelated pre-existing errors.

### Task 5: End-to-End Verification

**Files:**
- No production files unless verification reveals a defect.

- [ ] **Step 1: Run backend tests**

Run: `cd backend && pytest -q`

Expected: all backend tests pass.

- [ ] **Step 2: Run frontend build**

Run: `cd frontend && npm run build`

Expected: build passes, or only explicitly documented pre-existing failures remain.

- [ ] **Step 3: Verify Workbench in the in-app browser**

Verify:

- Initial Canvas shows Welcome content.
- Executable chat selects a Run and the result remains tied to that Run.
- Explanatory follow-up does not change Canvas.
- Refresh restores the latest Run for the session.
- The Canvas no longer switches to embedded tag/development/analysis pages based on chat keywords.

- [ ] **Step 4: Review the final diff**

Run: `git diff --check` and inspect only the files in this plan. Confirm unrelated user changes were not reverted.

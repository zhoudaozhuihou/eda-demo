# Data Label Agent Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a bank data labeling platform with LLM Agent auto-tagging, business discovery, data governance, memory system, and skills management.

**Architecture:** Python FastAPI backend + React/Vite frontend with PostgreSQL. LLM Agent via Claude/Copilot/OpenAI through a router layer. Async annotation pipeline. Memory system for pattern learning. Plugin-style Skills architecture.

**Tech Stack:** Python FastAPI, PostgreSQL 16 + pgvector, React 18 + Vite + MUI v7 + TailwindCSS + axios, Docker + docker-compose, Claude API / GitHub Copilot / OpenAI-compatible.

---

## File Structure

```
data-label/
│
├── docker-compose.yml
├── Dockerfile.backend
├── Dockerfile.frontend
├── nginx.conf
├── .env.example
│
├── backend/
│   ├── requirements.txt
│   ├── alembic.ini
│   ├── alembic/
│   │   └── versions/
│   │       ├── 001_initial.py
│   │       ├── 002_memory.py
│   │       └── 003_skills.py
│   │
│   ├── app/
│   │   ├── __init__.py
│   │   ├── main.py
│   │   ├── config.py
│   │   ├── database.py
│   │   │
│   │   ├── models/
│   │   │   ├── __init__.py
│   │   │   ├── connection.py
│   │   │   ├── table.py
│   │   │   ├── column.py
│   │   │   ├── annotation.py
│   │   │   ├── tag.py
│   │   │   ├── memory.py
│   │   │   ├── skill.py
│   │   │   └── audit.py
│   │   │
│   │   ├── schemas/
│   │   │   ├── __init__.py
│   │   │   ├── connection.py
│   │   │   ├── annotation.py
│   │   │   ├── tag.py
│   │   │   ├── memory.py
│   │   │   └── skill.py
│   │   │
│   │   ├── routers/
│   │   │   ├── __init__.py
│   │   │   ├── connections.py
│   │   │   ├── annotations.py
│   │   │   ├── tasks.py
│   │   │   ├── tags.py
│   │   │   ├── discovery.py
│   │   │   ├── governance.py
│   │   │   ├── skills.py
│   │   │   ├── memory.py
│   │   │   ├── llm_config.py
│   │   │   └── audit.py
│   │   │
│   │   ├── agent/
│   │   │   ├── __init__.py
│   │   │   ├── engine.py
│   │   │   ├── schema_discovery.py
│   │   │   ├── data_sampler.py
│   │   │   ├── prompt_templates.py
│   │   │   └── tag_inferrer.py
│   │   │
│   │   ├── llm/
│   │   │   ├── __init__.py
│   │   │   ├── base.py
│   │   │   ├── claude.py
│   │   │   ├── copilot.py
│   │   │   ├── openai_compat.py
│   │   │   └── router.py
│   │   │
│   │   ├── memory/
│   │   │   ├── __init__.py
│   │   │   ├── manager.py
│   │   │   ├── extractor.py
│   │   │   └── retriever.py
│   │   │
│   │   ├── skills/
│   │   │   ├── __init__.py
│   │   │   ├── registry.py
│   │   │   ├── base.py
│   │   │   ├── pipeline.py
│   │   │   └── builtin/
│   │   │       ├── __init__.py
│   │   │       ├── schema_discovery.py
│   │   │       ├── data_sampling.py
│   │   │       ├── pii_detection.py
│   │   │       ├── domain_classifier.py
│   │   │       └── quality_assessment.py
│   │   │
│   │   └── services/
│   │       ├── __init__.py
│   │       ├── connection_service.py
│   │       └── annotation_service.py
│   │
│   └── tests/
│       ├── __init__.py
│       ├── conftest.py
│       ├── test_connections.py
│       ├── test_annotations.py
│       ├── test_agent.py
│       ├── test_llm.py
│       └── test_memory.py
│
├── frontend/
│   ├── package.json
│   ├── vite.config.ts
│   ├── tailwind.config.js
│   ├── postcss.config.js
│   ├── tsconfig.json
│   ├── index.html
│   ├── Dockerfile
│   ├── nginx.conf
│   │
│   └── src/
│       ├── main.tsx
│       ├── App.tsx
│       ├── index.css
│       │
│       ├── lib/
│       │   ├── api.ts
│       │   └── api/
│       │       ├── connections.ts
│       │       ├── annotations.ts
│       │       ├── discovery.ts
│       │       ├── governance.ts
│       │       ├── tags.ts
│       │       ├── skills.ts
│       │       ├── memory.ts
│       │       └── llm.ts
│       │
│       ├── types/
│       │   ├── connection.ts
│       │   ├── annotation.ts
│       │   ├── tag.ts
│       │   ├── discovery.ts
│       │   ├── skill.ts
│       │   ├── memory.ts
│       │   └── llm.ts
│       │
│       ├── pages/
│       │   ├── Dashboard.tsx
│       │   ├── Connections.tsx
│       │   ├── AnnotationResult.tsx
│       │   ├── AnnotationDetail.tsx
│       │   ├── BusinessDiscovery.tsx
│       │   ├── DataAssets.tsx
│       │   ├── TagManagement.tsx
│       │   ├── SkillsManager.tsx
│       │   ├── MemoryBrowser.tsx
│       │   ├── LlmConfig.tsx
│       │   └── AuditLog.tsx
│       │
│       ├── components/
│       │   ├── layout/
│       │   │   ├── AppLayout.tsx
│       │   │   └── Sidebar.tsx
│       │   ├── connections/
│       │   │   ├── ConnectionForm.tsx
│       │   │   └── ConnectionCard.tsx
│       │   ├── annotations/
│       │   │   ├── TableTagCard.tsx
│       │   │   ├── ColumnTagTable.tsx
│       │   │   └── TagChip.tsx
│       │   ├── discovery/
│       │   │   ├── InsightCard.tsx
│       │   │   └── CustomerSegment.tsx
│       │   ├── skills/
│       │   │   ├── SkillCard.tsx
│       │   │   └── PipelineForm.tsx
│       │   ├── memory/
│       │   │   └── MemoryEntryCard.tsx
│       │   └── common/
│       │       ├── DataTable.tsx
│       │       ├── StatusBadge.tsx
│       │       └── ConfirmDialog.tsx
│       │
│       └── hooks/
│           ├── useConnections.ts
│           ├── useAnnotations.ts
│           └── useDiscovery.ts
```

---

## Phase 1: 基础骨架 (Weeks 1-2)

### Task 1.1: 初始化后端项目

**Files:**
- Create: `backend/requirements.txt`
- Create: `backend/app/__init__.py`
- Create: `backend/app/main.py`
- Create: `backend/app/config.py`
- Create: `backend/app/database.py`
- Create: `backend/.env.example`
- Modify: `docker-compose.yml`

- [ ] **Step 1: 创建 requirements.txt**

```
fastapi==0.110.0
uvicorn[standard]==0.27.0
sqlalchemy==2.0.25
asyncpg==0.29.0
psycopg2-binary==2.9.9
alembic==1.13.0
pydantic==2.5.0
pydantic-settings==2.1.0
python-dotenv==1.0.0
cryptography==41.0.7
httpx==0.26.0
anthropic==0.31.0
openai==1.6.0
numpy==1.26.2
pytest==7.4.3
pytest-asyncio==0.23.2
```

- [ ] **Step 2: 创建 config.py**

```python
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    database_url: str = "postgresql+asyncpg://user:pass@localhost:5432/data_label"
    database_url_sync: str = "postgresql+psycopg2://user:pass@localhost:5432/data_label"
    encryption_key: str = "change-me-in-production"
    llm_providers: dict = {}
    llm_strategy: str = "balanced"

    class Config:
        env_file = ".env"

settings = Settings()
```

- [ ] **Step 3: 创建 database.py**

```python
from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker, AsyncSession
from sqlalchemy.orm import DeclarativeBase

from app.config import settings

engine = create_async_engine(settings.database_url, echo=False)
async_session = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)

class Base(DeclarativeBase):
    pass

async def get_db():
    async with async_session() as session:
        try:
            yield session
        finally:
            await session.close()
```

- [ ] **Step 4: 创建 main.py**

```python
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(title="Data Label Agent", version="0.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/health")
async def health():
    return {"status": "ok"}
```

- [ ] **Step 5: 创建 docker-compose.yml**

```yaml
version: '3.8'
services:
  postgres:
    image: pgvector/pgvector:pg16
    ports:
      - "5432:5432"
    environment:
      POSTGRES_USER: user
      POSTGRES_PASSWORD: pass
      POSTGRES_DB: data_label
    volumes:
      - postgres_data:/var/lib/postgresql/data

  backend:
    build:
      context: ./backend
      dockerfile: Dockerfile.backend
    ports:
      - "8000:8000"
    environment:
      DATABASE_URL: "postgresql+asyncpg://user:pass@postgres:5432/data_label"
      DATABASE_URL_SYNC: "postgresql+psycopg2://user:pass@postgres:5432/data_label"
    depends_on:
      - postgres
    volumes:
      - ./backend:/app

  frontend:
    build:
      context: ./frontend
      dockerfile: Dockerfile.frontend
    ports:
      - "80:80"
    depends_on:
      - backend

volumes:
  postgres_data:
```

- [ ] **Step 6: 验证项目启动**

Run: `docker-compose up -d postgres && cd backend && uvicorn app.main:app --reload --port 8000`
Verify: `curl http://localhost:8000/health` returns `{"status": "ok"}`
Run: `docker-compose down`

- [ ] **Step 7: Commit**

```bash
git init
git add backend/ docker-compose.yml
git commit -m "feat: initialize backend project with FastAPI + PostgreSQL"
```

### Task 1.2: 数据库模型 + Migration

**Files:**
- Create: `backend/app/models/__init__.py`
- Create: `backend/app/models/connection.py`
- Create: `backend/app/models/table.py`
- Create: `backend/app/models/column.py`
- Create: `backend/app/models/annotation.py`
- Create: `backend/app/models/tag.py`
- Create: `backend/app/models/audit.py`
- Create: `backend/alembic.ini`
- Create: `backend/alembic/versions/001_initial.py`

- [ ] **Step 1: 创建 Connection 模型**

```python
# backend/app/models/connection.py
import uuid
from datetime import datetime
from sqlalchemy import Column, String, DateTime, Boolean
from app.database import Base

class Connection(Base):
    __tablename__ = "connections"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    name = Column(String(200), nullable=False)
    db_type = Column(String(50), nullable=False)  # postgresql | mysql | maxcompute | bigquery
    host = Column(String(500))
    port = Column(String(10))
    database_name = Column(String(200))
    username = Column(String(200))
    password_encrypted = Column(String(500))
    status = Column(String(20), default="disconnected")
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
```

- [ ] **Step 2: 创建 Table/Column 模型**

```python
# backend/app/models/table.py
import uuid
from datetime import datetime
from sqlalchemy import Column, String, DateTime, BigInteger, Integer, ForeignKey, Text
from app.database import Base

class DiscoveredTable(Base):
    __tablename__ = "discovered_tables"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    connection_id = Column(String(36), ForeignKey("connections.id"), nullable=False)
    table_name = Column(String(500), nullable=False)
    table_comment = Column(Text)
    row_count_estimate = Column(BigInteger)
    column_count = Column(Integer)
    scan_status = Column(String(20), default="pending")  # pending | scanning | completed | failed
    created_at = Column(DateTime, default=datetime.utcnow)

# backend/app/models/column.py
class DiscoveredColumn(Base):
    __tablename__ = "discovered_columns"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    table_id = Column(String(36), ForeignKey("discovered_tables.id"), nullable=False)
    column_name = Column(String(500), nullable=False)
    data_type = Column(String(100))
    is_nullable = Column(Boolean, default=True)
    is_primary_key = Column(Boolean, default=False)
    is_foreign_key = Column(Boolean, default=False)
    sample_values = Column(Text)  # JSON array
    null_ratio = Column(String(10))  # "0.35" 表示 35%
    distinct_count = Column(Integer)
    created_at = Column(DateTime, default=datetime.utcnow)
```

- [ ] **Step 3: 创建 Annotation + Tag + Audit 模型**

```python
# backend/app/models/annotation.py
class Annotation(Base):
    __tablename__ = "annotations"

    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    target_type = Column(String(10), nullable=False)  # table | column
    target_id = Column(String(36), nullable=False)
    tag_category = Column(String(50), nullable=False)
    tag_value = Column(String(200), nullable=False)
    confidence = Column(String(10))  # "0.95"
    evidence = Column(Text)
    source = Column(String(20), default="agent")  # agent | rule | manual
    status = Column(String(20), default="suggested")  # suggested | approved | rejected
    created_by = Column(String(100), default="agent")
    approved_by = Column(String(100))
    created_at = Column(DateTime, default=datetime.utcnow)
    reviewed_at = Column(DateTime)

# backend/app/models/tag.py
class TagCategory(Base):
    __tablename__ = "tag_categories"
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    name = Column(String(100), unique=True, nullable=False)
    is_system = Column(Boolean, default=True)

class TagDefinition(Base):
    __tablename__ = "tag_definitions"
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    category_id = Column(String(36), ForeignKey("tag_categories.id"), nullable=False)
    value = Column(String(200), nullable=False)
    description = Column(Text)
    color = Column(String(7), default="#666666")
    is_active = Column(Boolean, default=True)

# backend/app/models/audit.py
class AuditLog(Base):
    __tablename__ = "audit_logs"
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    action = Column(String(50), nullable=False)
    entity_type = Column(String(50), nullable=False)
    entity_id = Column(String(36))
    old_value = Column(Text)  # JSON
    new_value = Column(Text)  # JSON
    operator = Column(String(100), default="system")
    created_at = Column(DateTime, default=datetime.utcnow)
```

- [ ] **Step 4: 创建 models/__init__.py 导出所有模型**

```python
from app.models.connection import Connection
from app.models.table import DiscoveredTable
from app.models.column import DiscoveredColumn
from app.models.annotation import Annotation
from app.models.tag import TagCategory, TagDefinition
from app.models.audit import AuditLog

__all__ = [
    "Connection", "DiscoveredTable", "DiscoveredColumn",
    "Annotation", "TagCategory", "TagDefinition", "AuditLog",
]
```

- [ ] **Step 5: 配置 Alembic 并生成 migration**

```bash
cd backend
alembic init alembic
# 编辑 alembic.ini: sqlalchemy.url = postgresql+psycopg2://user:pass@localhost:5432/data_label
# 编辑 alembic/env.py: target_metadata = Base.metadata
alembic revision --autogenerate -m "initial"
alembic upgrade head
```

Verify: `psql -h localhost -U user -d data_label -c "\dt"` shows all 6 tables created.

- [ ] **Step 6: Commit**

```bash
git add backend/app/models/ backend/alembic/
git commit -m "feat: add database models and initial migration"
```

### Task 1.3: Pydantic Schemas

**Files:**
- Create: `backend/app/schemas/__init__.py`
- Create: `backend/app/schemas/connection.py`
- Create: `backend/app/schemas/annotation.py`
- Create: `backend/app/schemas/tag.py`

- [ ] **Step 1: 创建 Connection schemas**

```python
# backend/app/schemas/connection.py
from pydantic import BaseModel
from typing import Optional
from datetime import datetime

class ConnectionCreate(BaseModel):
    name: str
    db_type: str  # postgresql | mysql | maxcompute | bigquery
    host: Optional[str] = None
    port: Optional[str] = None
    database_name: Optional[str] = None
    username: Optional[str] = None
    password: Optional[str] = None

class ConnectionUpdate(BaseModel):
    name: Optional[str] = None
    host: Optional[str] = None
    port: Optional[str] = None
    database_name: Optional[str] = None
    username: Optional[str] = None
    password: Optional[str] = None

class ConnectionResponse(BaseModel):
    id: str
    name: str
    db_type: str
    host: Optional[str]
    port: Optional[str]
    database_name: Optional[str]
    username: Optional[str]
    status: str
    created_at: datetime

    model_config = {"from_attributes": True}

class ScanRequest(BaseModel):
    tables: Optional[list[str]] = None
    mode: str = "quick"  # quick | deep
```

- [ ] **Step 2: 创建 Annotation/Tag schemas**

```python
# backend/app/schemas/annotation.py
from pydantic import BaseModel
from typing import Optional
from datetime import datetime

class AnnotationResponse(BaseModel):
    id: str
    target_type: str
    target_id: str
    tag_category: str
    tag_value: str
    confidence: Optional[float]
    evidence: Optional[str]
    source: str
    status: str
    created_by: Optional[str]
    created_at: datetime

    model_config = {"from_attributes": True}

class ReviewRequest(BaseModel):
    action: str  # approve | reject | modify
    new_tags: Optional[list[dict]] = None

# backend/app/schemas/tag.py
class TagCategoryCreate(BaseModel):
    name: str
    is_system: bool = False

class TagDefinitionCreate(BaseModel):
    category_id: str
    value: str
    description: Optional[str] = None
    color: str = "#666666"
```

- [ ] **Step 3: 创建 schemas/__init__.py**

```python
from app.schemas.connection import (
    ConnectionCreate, ConnectionUpdate, ConnectionResponse, ScanRequest,
)
from app.schemas.annotation import AnnotationResponse, ReviewRequest
from app.schemas.tag import TagCategoryCreate, TagDefinitionCreate

__all__ = [
    "ConnectionCreate", "ConnectionUpdate", "ConnectionResponse", "ScanRequest",
    "AnnotationResponse", "ReviewRequest",
    "TagCategoryCreate", "TagDefinitionCreate",
]
```

- [ ] **Step 4: Commit**

```bash
git add backend/app/schemas/
git commit -m "feat: add Pydantic schemas for API"
```

### Task 1.4: 数据源连接 CRUD API

**Files:**
- Create: `backend/app/services/__init__.py`
- Create: `backend/app/services/connection_service.py`
- Create: `backend/app/routers/__init__.py`
- Create: `backend/app/routers/connections.py`
- Modify: `backend/app/main.py`
- Create: `backend/tests/__init__.py`
- Create: `backend/tests/conftest.py`
- Create: `backend/tests/test_connections.py`

- [ ] **Step 1: 创建 connection_service.py**

```python
# backend/app/services/connection_service.py
import json
from cryptography.fernet import Fernet
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.config import settings
from app.models.connection import Connection
from app.schemas.connection import ConnectionCreate, ConnectionUpdate

cipher = Fernet(settings.encryption_key.encode().ljust(32, b'\0')[:32])

class ConnectionService:
    @staticmethod
    def encrypt_password(password: str) -> str:
        return cipher.encrypt(password.encode()).decode()

    @staticmethod
    def decrypt_password(encrypted: str) -> str:
        return cipher.decrypt(encrypted.encode()).decode()

    @staticmethod
    async def list(db: AsyncSession) -> list[Connection]:
        result = await db.execute(select(Connection).order_by(Connection.created_at.desc()))
        return result.scalars().all()

    @staticmethod
    async def get(db: AsyncSession, connection_id: str) -> Connection | None:
        result = await db.execute(select(Connection).where(Connection.id == connection_id))
        return result.scalar_one_or_none()

    @staticmethod
    async def create(db: AsyncSession, data: ConnectionCreate) -> Connection:
        conn = Connection(
            name=data.name,
            db_type=data.db_type,
            host=data.host,
            port=data.port,
            database_name=data.database_name,
            username=data.username,
            password_encrypted=ConnectionService.encrypt_password(data.password) if data.password else None,
            status="disconnected",
        )
        db.add(conn)
        await db.commit()
        await db.refresh(conn)
        return conn

    @staticmethod
    async def update(db: AsyncSession, connection_id: str, data: ConnectionUpdate) -> Connection | None:
        conn = await ConnectionService.get(db, connection_id)
        if not conn:
            return None
        update_data = data.model_dump(exclude_unset=True)
        if "password" in update_data:
            update_data["password_encrypted"] = ConnectionService.encrypt_password(update_data.pop("password"))
        for key, value in update_data.items():
            setattr(conn, key, value)
        await db.commit()
        await db.refresh(conn)
        return conn

    @staticmethod
    async def delete(db: AsyncSession, connection_id: str) -> bool:
        conn = await ConnectionService.get(db, connection_id)
        if not conn:
            return False
        await db.delete(conn)
        await db.commit()
        return True
```

- [ ] **Step 2: 创建 connections router**

```python
# backend/app/routers/connections.py
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from app.database import get_db
from app.services.connection_service import ConnectionService
from app.schemas.connection import ConnectionCreate, ConnectionUpdate, ConnectionResponse

router = APIRouter(prefix="/api/connections", tags=["connections"])

@router.get("", response_model=list[ConnectionResponse])
async def list_connections(db: AsyncSession = Depends(get_db)):
    return await ConnectionService.list(db)

@router.get("/{connection_id}", response_model=ConnectionResponse)
async def get_connection(connection_id: str, db: AsyncSession = Depends(get_db)):
    conn = await ConnectionService.get(db, connection_id)
    if not conn:
        raise HTTPException(status_code=404, detail="Connection not found")
    return conn

@router.post("", response_model=ConnectionResponse, status_code=201)
async def create_connection(data: ConnectionCreate, db: AsyncSession = Depends(get_db)):
    return await ConnectionService.create(db, data)

@router.put("/{connection_id}", response_model=ConnectionResponse)
async def update_connection(connection_id: str, data: ConnectionUpdate, db: AsyncSession = Depends(get_db)):
    conn = await ConnectionService.update(db, connection_id, data)
    if not conn:
        raise HTTPException(status_code=404, detail="Connection not found")
    return conn

@router.delete("/{connection_id}")
async def delete_connection(connection_id: str, db: AsyncSession = Depends(get_db)):
    deleted = await ConnectionService.delete(db, connection_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Connection not found")
    return {"message": "deleted"}
```

- [ ] **Step 3: 注册 router 到 main.py**

```python
# 在 main.py 中添加
from app.routers.connections import router as connections_router
app.include_router(connections_router)
```

- [ ] **Step 4: 编写测试 conftest.py**

```python
# backend/tests/conftest.py
import pytest
from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker
from app.database import Base, get_db
from app.main import app

# 使用 SQLite in-memory 做测试
TEST_DATABASE_URL = "sqlite+aiosqlite:///:memory:"

@pytest.fixture
async def db_session():
    engine = create_async_engine(TEST_DATABASE_URL, echo=True)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    session = async_sessionmaker(engine, expire_on_commit=False)()
    try:
        yield session
    finally:
        await session.close()
        await engine.dispose()

@pytest.fixture
async def client(db_session):
    async def override_get_db():
        yield db_session
    app.dependency_overrides[get_db] = override_get_db
    from httpx import AsyncClient, ASGITransport
    transport = ASGITransport(app=app)
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        yield ac
    app.dependency_overrides.clear()
```

- [ ] **Step 5: 创建 test_connections.py**

```python
# backend/tests/test_connections.py
import pytest

@pytest.mark.asyncio
async def test_create_connection(client):
    response = await client.post("/api/connections", json={
        "name": "Test DB",
        "db_type": "postgresql",
        "host": "localhost",
        "port": "5432",
        "database_name": "test",
        "username": "user",
        "password": "secret",
    })
    assert response.status_code == 201
    data = response.json()
    assert data["name"] == "Test DB"
    assert data["db_type"] == "postgresql"
    assert "id" in data

@pytest.mark.asyncio
async def test_list_connections(client):
    await client.post("/api/connections", json={"name": "DB1", "db_type": "postgresql"})
    response = await client.get("/api/connections")
    assert response.status_code == 200
    assert len(response.json()) == 1

@pytest.mark.asyncio
async def test_get_connection_not_found(client):
    response = await client.get("/api/connections/non-existent")
    assert response.status_code == 404

@pytest.mark.asyncio
async def test_delete_connection(client):
    resp = await client.post("/api/connections", json={"name": "DB1", "db_type": "postgresql"})
    conn_id = resp.json()["id"]
    response = await client.delete(f"/api/connections/{conn_id}")
    assert response.status_code == 200
    response = await client.get("/api/connections")
    assert len(response.json()) == 0
```

- [ ] **Step 6: 运行测试验证**

```bash
cd backend && pip install aiosqlite pytest-asyncio httpx && pytest tests/test_connections.py -v
```
Expected: 4 tests PASS.

- [ ] **Step 7: Commit**

```bash
git add backend/app/services/ backend/app/routers/ backend/tests/
git commit -m "feat: add connections CRUD API with tests"
```

### Task 1.5: 前端初始化

**Files:**
- Create: `frontend/package.json`
- Create: `frontend/vite.config.ts`
- Create: `frontend/tsconfig.json`
- Create: `frontend/tailwind.config.js`
- Create: `frontend/postcss.config.js`
- Create: `frontend/index.html`
- Create: `frontend/src/main.tsx`
- Create: `frontend/src/App.tsx`
- Create: `frontend/src/index.css`
- Create: `frontend/src/lib/api.ts`
- Create: `frontend/src/types/connection.ts`
- Create: `frontend/src/components/layout/AppLayout.tsx`
- Create: `frontend/src/components/layout/Sidebar.tsx`

- [ ] **Step 1: 初始化前端项目**

```json
# package.json
{
  "name": "data-label-frontend",
  "private": true,
  "version": "0.1.0",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "tsc && vite build",
    "preview": "vite preview"
  },
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "react-router-dom": "^6.21.0",
    "@mui/material": "^7.0.0",
    "@mui/icons-material": "^7.0.0",
    "@emotion/react": "^11.11.0",
    "@emotion/styled": "^11.11.0",
    "axios": "^1.6.0"
  },
  "devDependencies": {
    "@types/react": "^18.2.0",
    "@types/react-dom": "^18.2.0",
    "@vitejs/plugin-react": "^4.2.0",
    "typescript": "^5.3.0",
    "vite": "^5.0.0",
    "tailwindcss": "^3.4.0",
    "postcss": "^8.4.0",
    "autoprefixer": "^10.4.0"
  }
}
```

- [ ] **Step 2: 创建 vite + tailwind 配置**

```typescript
// vite.config.ts
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  server: {
    proxy: { '/api': 'http://localhost:8000' }
  }
})
```

```javascript
// tailwind.config.js
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: { extend: {} },
  plugins: [],
  important: '#root',  // MUI 兼容
}
```

- [ ] **Step 3: 创建 axios 实例 API 封装**

```typescript
// src/lib/api.ts
import axios from 'axios';

const api = axios.create({
  baseURL: import.meta.env.VITE_API_BASE || '/api',
  timeout: 30000,
  headers: { 'Content-Type': 'application/json' },
});

api.interceptors.response.use(
  (res) => res.data,
  (err) => {
    const msg = err.response?.data?.detail || err.message;
    console.error('[API Error]', msg);
    return Promise.reject(new Error(msg));
  }
);

export default api;
```

- [ ] **Step 4: 创建 Connection 类型**

```typescript
// src/types/connection.ts
export interface Connection {
  id: string;
  name: string;
  db_type: 'postgresql' | 'mysql' | 'maxcompute' | 'bigquery';
  host: string | null;
  port: string | null;
  database_name: string | null;
  username: string | null;
  status: 'connected' | 'disconnected' | 'error';
  created_at: string;
}

export interface ConnectionCreate {
  name: string;
  db_type: string;
  host?: string;
  port?: string;
  database_name?: string;
  username?: string;
  password?: string;
}
```

- [ ] **Step 5: 创建 AppLayout + Sidebar**

```tsx
// src/components/layout/Sidebar.tsx
import { useNavigate, useLocation } from 'react-router-dom';
import {
  Drawer, List, ListItemButton, ListItemIcon, ListItemText,
  Toolbar, Box, Typography,
} from '@mui/material';
import {
  Dashboard, Storage, Label, Insights, AccountTree,
  Settings, Tag, Memory, Psychology, History,
} from '@mui/icons-material';

const DRAWER_WIDTH = 260;

const menuItems = [
  { text: '仪表盘', icon: <Dashboard />, path: '/' },
  { text: '数据源管理', icon: <Storage />, path: '/connections' },
  { text: '标注结果', icon: <Label />, path: '/annotations' },
  { text: '业务发现', icon: <Insights />, path: '/discovery' },
  { text: '数据资产', icon: <AccountTree />, path: '/governance' },
  { text: '标签体系', icon: <Tag />, path: '/tags' },
  { text: '技能管理', icon: <Psychology />, path: '/skills' },
  { text: '记忆检索', icon: <Memory />, path: '/memory' },
  { text: 'LLM 配置', icon: <Settings />, path: '/llm-config' },
  { text: '审计日志', icon: <History />, path: '/audit' },
];

export default function Sidebar() {
  const navigate = useNavigate();
  const location = useLocation();

  return (
    <Drawer
      variant="permanent"
      sx={{
        width: DRAWER_WIDTH,
        '& .MuiDrawer-paper': { width: DRAWER_WIDTH, boxSizing: 'border-box' },
      }}
    >
      <Toolbar>
        <Typography variant="h6" noWrap className="font-bold text-blue-700">
          Data Label Agent
        </Typography>
      </Toolbar>
      <List>
        {menuItems.map((item) => (
          <ListItemButton
            key={item.path}
            selected={location.pathname === item.path}
            onClick={() => navigate(item.path)}
          >
            <ListItemIcon>{item.icon}</ListItemIcon>
            <ListItemText primary={item.text} />
          </ListItemButton>
        ))}
      </List>
    </Drawer>
  );
}

// src/components/layout/AppLayout.tsx
import { Box, Toolbar } from '@mui/material';
import Sidebar from './Sidebar';

export default function AppLayout({ children }: { children: React.ReactNode }) {
  return (
    <Box className="flex">
      <Sidebar />
      <Box component="main" className="flex-grow p-6 bg-gray-50 min-h-screen">
        <Toolbar />
        {children}
      </Box>
    </Box>
  );
}
```

- [ ] **Step 6: 创建 App.tsx 路由**

```tsx
// src/App.tsx
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import AppLayout from './components/layout/AppLayout';

const theme = createTheme({
  palette: { primary: { main: '#1565c0' } },
});

function Placeholder({ title }: { title: string }) {
  return (
    <div className="flex items-center justify-center h-64 text-gray-400 text-xl">
      {title} - Coming Soon
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <BrowserRouter>
        <AppLayout>
          <Routes>
            <Route path="/" element={<Placeholder title="仪表盘" />} />
            <Route path="/connections" element={<Placeholder title="数据源管理" />} />
            <Route path="/annotations" element={<Placeholder title="标注结果" />} />
            <Route path="/discovery" element={<Placeholder title="业务发现" />} />
            <Route path="/governance" element={<Placeholder title="数据资产" />} />
            <Route path="/tags" element={<Placeholder title="标签体系" />} />
            <Route path="/skills" element={<Placeholder title="技能管理" />} />
            <Route path="/memory" element={<Placeholder title="记忆检索" />} />
            <Route path="/llm-config" element={<Placeholder title="LLM 配置" />} />
            <Route path="/audit" element={<Placeholder title="审计日志" />} />
          </Routes>
        </AppLayout>
      </BrowserRouter>
    </ThemeProvider>
  );
}
```

- [ ] **Step 7: 创建入口文件**

```tsx
// src/main.tsx
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './index.css';

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode><App /></React.StrictMode>
);
```

```css
/* src/index.css */
@tailwind base;
@tailwind components;
@tailwind utilities;
```

- [ ] **Step 8: 验证前端启动**

```bash
cd frontend && npm install && npm run dev
```
Verify: open `http://localhost:5173` in browser, see sidebar with 10 nav items.

- [ ] **Step 9: Commit**

```bash
git add frontend/
git commit -m "feat: initialize React frontend with MUI + Tailwind + routing"
```

### Task 1.6: 数据源管理前端页面

**Files:**
- Create: `frontend/src/lib/api/connections.ts`
- Create: `frontend/src/hooks/useConnections.ts`
- Create: `frontend/src/components/connections/ConnectionCard.tsx`
- Create: `frontend/src/components/connections/ConnectionForm.tsx`
- Create: `frontend/src/pages/Connections.tsx`

- [ ] **Step 1: 创建 connections API service**

```typescript
// src/lib/api/connections.ts
import api from '../api';
import type { Connection, ConnectionCreate } from '../../types/connection';

export const connectionApi = {
  list: () => api.get<any, Connection[]>('/connections'),
  get: (id: string) => api.get<any, Connection>(`/connections/${id}`),
  create: (data: ConnectionCreate) => api.post<any, Connection>('/connections', data),
  update: (id: string, data: Partial<ConnectionCreate>) =>
    api.put<any, Connection>(`/connections/${id}`, data),
  test: (id: string) => api.post<any, { success: boolean }>(`/connections/${id}/test`),
  scan: (id: string) => api.post<any, { task_id: string }>(`/connections/${id}/scan`),
  delete: (id: string) => api.delete(`/connections/${id}`),
};
```

- [ ] **Step 2: 创建 Connections 页面**

```tsx
// src/pages/Connections.tsx
import { useState, useEffect } from 'react';
import {
  Box, Button, Dialog, DialogTitle, DialogContent, Card,
  CardContent, Typography, Chip, IconButton, Grid,
} from '@mui/material';
import { Add, Delete, PlayArrow, Storage } from '@mui/icons-material';
import { connectionApi } from '../lib/api/connections';
import ConnectionForm from '../components/connections/ConnectionForm';
import type { Connection } from '../types/connection';

const statusColors: Record<string, string> = {
  connected: 'success',
  disconnected: 'default',
  error: 'error',
};

export default function Connections() {
  const [connections, setConnections] = useState<Connection[]>([]);
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);

  const loadConnections = async () => {
    setLoading(true);
    try {
      const data = await connectionApi.list();
      setConnections(data);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { loadConnections(); }, []);

  const handleCreate = async (formData: any) => {
    await connectionApi.create(formData);
    setOpen(false);
    loadConnections();
  };

  const handleDelete = async (id: string) => {
    await connectionApi.delete(id);
    loadConnections();
  };

  const handleScan = async (id: string) => {
    await connectionApi.scan(id);
  };

  return (
    <Box>
      <Box className="flex justify-between items-center mb-6">
        <Typography variant="h4" className="font-bold">
          数据源管理
        </Typography>
        <Button variant="contained" startIcon={<Add />} onClick={() => setOpen(true)}>
          新增数据源
        </Button>
      </Box>

      <Grid container spacing={3}>
        {connections.map((conn) => (
          <Grid item xs={12} md={6} lg={4} key={conn.id}>
            <Card variant="outlined">
              <CardContent>
                <Box className="flex items-center gap-2 mb-2">
                  <Storage color="primary" />
                  <Typography variant="h6">{conn.name}</Typography>
                  <Chip
                    label={conn.status}
                    color={statusColors[conn.status] as any}
                    size="small"
                  />
                </Box>
                <Typography color="text.secondary" variant="body2">
                  {conn.db_type} | {conn.host}:{conn.port}/{conn.database_name}
                </Typography>
                <Box className="flex gap-2 mt-3">
                  <Button size="small" startIcon={<PlayArrow />}
                    variant="outlined" onClick={() => handleScan(conn.id)}>
                    运行标注
                  </Button>
                  <IconButton color="error" onClick={() => handleDelete(conn.id)}>
                    <Delete />
                  </IconButton>
                </Box>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      <Dialog open={open} onClose={() => setOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>新增数据源</DialogTitle>
        <DialogContent>
          <ConnectionForm onSubmit={handleCreate} onCancel={() => setOpen(false)} />
        </DialogContent>
      </Dialog>
    </Box>
  );
}
```

- [ ] **Step 3: 创建 ConnectionForm**

```tsx
// src/components/connections/ConnectionForm.tsx
import { useState } from 'react';
import {
  TextField, MenuItem, Button, Box, Stack,
} from '@mui/material';

const DB_TYPES = [
  { value: 'postgresql', label: 'PostgreSQL' },
  { value: 'mysql', label: 'MySQL' },
  { value: 'maxcompute', label: 'MaxCompute' },
  { value: 'bigquery', label: 'BigQuery' },
];

export default function ConnectionForm({
  onSubmit, onCancel,
}: {
  onSubmit: (data: any) => void;
  onCancel: () => void;
}) {
  const [form, setForm] = useState({
    name: '', db_type: 'postgresql', host: '', port: '',
    database_name: '', username: '', password: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(form);
  };

  return (
    <Box component="form" onSubmit={handleSubmit} className="mt-4">
      <Stack spacing={3}>
        <TextField label="名称" required value={form.name}
          onChange={(e) => setForm({ ...form, name: e.target.value })} />
        <TextField label="类型" select value={form.db_type}
          onChange={(e) => setForm({ ...form, db_type: e.target.value })}>
          {DB_TYPES.map((t) => <MenuItem key={t.value} value={t.value}>{t.label}</MenuItem>)}
        </TextField>
        <TextField label="主机" value={form.host}
          onChange={(e) => setForm({ ...form, host: e.target.value })} />
        <TextField label="端口" value={form.port}
          onChange={(e) => setForm({ ...form, port: e.target.value })} />
        <TextField label="数据库名" value={form.database_name}
          onChange={(e) => setForm({ ...form, database_name: e.target.value })} />
        <TextField label="用户名" value={form.username}
          onChange={(e) => setForm({ ...form, username: e.target.value })} />
        <TextField label="密码" type="password" value={form.password}
          onChange={(e) => setForm({ ...form, password: e.target.value })} />
        <Box className="flex gap-2 justify-end">
          <Button onClick={onCancel}>取消</Button>
          <Button type="submit" variant="contained">保存</Button>
        </Box>
      </Stack>
    </Box>
  );
}
```

- [ ] **Step 4: 注册连接页面路由** — 在 App.tsx 中将 `/connections` 路由指向 `Connections` 页面

- [ ] **Step 5: Commit**

```bash
git add frontend/src/
git commit -m "feat: add connections management page with form dialog"
```

### Task 1.7: Schema Discovery + 连接测试

**Files:**
- Create: `backend/app/agent/__init__.py`
- Create: `backend/app/agent/schema_discovery.py`
- Modify: `backend/app/services/connection_service.py`
- Modify: `backend/app/routers/connections.py`

- [ ] **Step 1: 创建 Schema Discovery 引擎**

```python
# backend/app/agent/schema_discovery.py
import sqlalchemy as sa
from sqlalchemy import inspect
from typing import Optional
from app.services.connection_service import ConnectionService

class SchemaDiscoveryEngine:
    """从数据源获取表结构和字段信息"""

    @staticmethod
    def create_engine_url(conn) -> str:
        """根据连接信息创建 SQLAlchemy 连接 URL"""
        pw = ConnectionService.decrypt_password(conn.password_encrypted) if conn.password_encrypted else ""
        if conn.db_type == "postgresql":
            return f"postgresql://{conn.username}:{pw}@{conn.host}:{conn.port}/{conn.database_name}"
        elif conn.db_type == "mysql":
            return f"mysql+pymysql://{conn.username}:{pw}@{conn.host}:{conn.port}/{conn.database_name}"
        raise ValueError(f"Unsupported db_type: {conn.db_type}")

    @staticmethod
    async def test_connection(conn) -> bool:
        """测试数据库连接是否可用"""
        try:
            url = SchemaDiscoveryEngine.create_engine_url(conn)
            engine = sa.create_engine(url)
            with engine.connect() as c:
                c.execute(sa.text("SELECT 1"))
            engine.dispose()
            return True
        except Exception as e:
            raise e

    @staticmethod
    async def discover_tables(conn) -> list[dict]:
        """获取所有表名和注释"""
        url = SchemaDiscoveryEngine.create_engine_url(conn)
        engine = sa.create_engine(url)
        inspector = inspect(engine)
        tables = []
        for table_name in inspector.get_table_names():
            comment = inspector.get_table_comment(table_name)
            columns = inspector.get_columns(table_name)
            pk_constraint = inspector.get_pk_constraint(table_name)
            pk_columns = pk_constraint.get("constrained_columns", [])
            fk_info = inspector.get_foreign_keys(table_name)
            fk_columns = [fk["constrained_columns"][0] for fk in fk_info]
            tables.append({
                "table_name": table_name,
                "table_comment": comment.get("text", ""),
                "column_count": len(columns),
                "columns": [
                    {
                        "name": col["name"],
                        "type": str(col["type"]),
                        "nullable": col.get("nullable", True),
                        "is_pk": col["name"] in pk_columns,
                        "is_fk": col["name"] in fk_columns,
                    }
                    for col in columns
                ],
            })
        engine.dispose()
        return tables
```

- [ ] **Step 2: 在 connections router 中添加 test 和 scan 端点**

```python
# 添加到 routers/connections.py
from app.agent.schema_discovery import SchemaDiscoveryEngine
from fastapi import BackgroundTasks

@router.post("/{connection_id}/test")
async def test_connection(connection_id: str, db: AsyncSession = Depends(get_db)):
    conn = await ConnectionService.get(db, connection_id)
    if not conn:
        raise HTTPException(status_code=404, detail="Connection not found")
    try:
        await SchemaDiscoveryEngine.test_connection(conn)
        conn.status = "connected"
        await db.commit()
        return {"success": True, "message": "Connection successful"}
    except Exception as e:
        conn.status = "error"
        await db.commit()
        raise HTTPException(status_code=400, detail=str(e))
```

- [ ] **Step 3: Commit**

```bash
git add backend/app/agent/
git commit -m "feat: add schema discovery engine and connection test endpoint"
```

---

## Phase 2: 核心标注链路 (Weeks 3-4)

### Task 2.1: LLM Provider 抽象层

**Files:**
- Create: `backend/app/llm/base.py`
- Create: `backend/app/llm/claude.py`
- Create: `backend/app/llm/copilot.py`
- Create: `backend/app/llm/openai_compat.py`
- Create: `backend/app/llm/router.py`

- [ ] **Step 1: 创建 LLMProvider 抽象基类**

```python
# backend/app/llm/base.py
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Optional

@dataclass
class LLMResponse:
    content: str
    model: str
    usage: Optional[dict] = None

class LLMProvider(ABC):
    @abstractmethod
    async def chat(self, messages: list[dict], **kwargs) -> LLMResponse:
        """同步对话"""
        pass

    @abstractmethod
    async def chat_stream(self, messages: list[dict], **kwargs):
        """流式对话"""
        pass

    @property
    @abstractmethod
    def models(self) -> list[str]:
        """可用模型列表"""
        pass
```

- [ ] **Step 2: 实现 Claude Provider**

```python
# backend/app/llm/claude.py
import anthropic
from app.llm.base import LLMProvider, LLMResponse

MODEL_MAP = {"opus": "claude-3-opus-20240229", "sonnet": "claude-3-sonnet-20240229", "haiku": "claude-3-haiku-20240307"}

class ClaudeProvider(LLMProvider):
    def __init__(self, api_key: str, base_url: str | None = None):
        kwargs = {"api_key": api_key}
        if base_url:
            kwargs["base_url"] = base_url
        self.client = anthropic.AsyncAnthropic(**kwargs)

    @property
    def models(self) -> list[str]:
        return list(MODEL_MAP.keys())

    async def chat(self, messages: list[dict], **kwargs) -> LLMResponse:
        model_key = kwargs.get("model", "sonnet")
        model = MODEL_MAP.get(model_key, MODEL_MAP["sonnet"])
        system_msg = ""
        chat_messages = []
        for m in messages:
            if m["role"] == "system":
                system_msg = m["content"]
            else:
                chat_messages.append({"role": m["role"], "content": m["content"]})
        resp = await self.client.messages.create(
            model=model, system=system_msg, messages=chat_messages,
            max_tokens=kwargs.get("max_tokens", 4096),
        )
        return LLMResponse(
            content=resp.content[0].text,
            model=model,
            usage={"input_tokens": resp.usage.input_tokens, "output_tokens": resp.usage.output_tokens},
        )

    async def chat_stream(self, messages, **kwargs):
        model_key = kwargs.get("model", "sonnet")
        model = MODEL_MAP.get(model_key, MODEL_MAP["sonnet"])
        async with self.client.messages.stream(
            model=model, max_tokens=kwargs.get("max_tokens", 4096),
            messages=[m for m in messages if m["role"] != "system"],
        ) as stream:
            async for text in stream.text_stream:
                yield text
```

- [ ] **Step 3: 实现 Copilot Provider (OpenAI 兼容)**

```python
# backend/app/llm/copilot.py
from openai import AsyncOpenAI
from app.llm.base import LLMProvider, LLMResponse

class CopilotProvider(LLMProvider):
    """GitHub Copilot - OpenAI 兼容接口"""

    def __init__(self, token: str):
        self.client = AsyncOpenAI(
            base_url="https://api.githubcopilot.com/v1",
            api_key=token,
        )

    @property
    def models(self) -> list[str]:
        return ["gpt-4o", "gpt-4o-mini", "o3-mini"]

    async def chat(self, messages: list[dict], **kwargs) -> LLMResponse:
        model = kwargs.get("model", "gpt-4o")
        resp = await self.client.chat.completions.create(
            model=model, messages=messages,
            max_tokens=kwargs.get("max_tokens", 4096),
        )
        return LLMResponse(
            content=resp.choices[0].message.content,
            model=model,
            usage={"total_tokens": resp.usage.total_tokens if resp.usage else None},
        )

    async def chat_stream(self, messages, **kwargs):
        model = kwargs.get("model", "gpt-4o")
        stream = await self.client.chat.completions.create(
            model=model, messages=messages, stream=True,
        )
        async for chunk in stream:
            if chunk.choices[0].delta.content:
                yield chunk.choices[0].delta.content
```

- [ ] **Step 4: 创建 LLMRouter**

```python
# backend/app/llm/router.py
import json
from app.config import settings
from app.llm.base import LLMProvider
from app.llm.claude import ClaudeProvider
from app.llm.copilot import CopilotProvider
from app.llm.openai_compat import OpenAICompatProvider

ROUTING_STRATEGIES = {
    "cost_first": {
        "schema_analysis": ("copilot", "gpt-4o-mini"),
        "data_sampling": ("copilot", "gpt-4o-mini"),
        "tagging": ("claude", "haiku"),
        "complex_reasoning": ("claude", "sonnet"),
    },
    "quality_first": {
        "schema_analysis": ("claude", "sonnet"),
        "data_sampling": ("claude", "sonnet"),
        "tagging": ("claude", "opus"),
        "complex_reasoning": ("claude", "opus"),
    },
    "balanced": {
        "schema_analysis": ("copilot", "gpt-4o-mini"),
        "data_sampling": ("copilot", "gpt-4o-mini"),
        "tagging": ("claude", "sonnet"),
        "complex_reasoning": ("claude", "opus"),
    },
}

class LLMRouter:
    def __init__(self):
        self.providers: dict[str, LLMProvider] = {}
        self._init_providers()

    def _init_providers(self):
        providers_config = settings.llm_providers
        if "claude" in providers_config:
            self.providers["claude"] = ClaudeProvider(**providers_config["claude"])
        if "copilot" in providers_config:
            self.providers["copilot"] = CopilotProvider(providers_config["copilot"]["token"])
        if "openai" in providers_config:
            self.providers["openai"] = OpenAICompatProvider(**providers_config["openai"])

    def get_strategy(self) -> dict:
        return ROUTING_STRATEGIES.get(settings.llm_strategy, ROUTING_STRATEGIES["balanced"])

    async def route(self, task_type: str, messages: list[dict], **kwargs) -> str:
        strategy = self.get_strategy()
        provider_name, model = strategy.get(task_type, ("claude", "sonnet"))
        provider = self.providers.get(provider_name)
        if not provider:
            provider = list(self.providers.values())[0]
        resp = await provider.chat(messages, model=model, **kwargs)
        return resp.content

    async def chat(self, provider_name: str, model: str, messages: list[dict], **kwargs) -> LLMResponse:
        provider = self.providers.get(provider_name)
        if not provider:
            raise ValueError(f"Provider {provider_name} not configured")
        return await provider.chat(messages, model=model, **kwargs)
```

- [ ] **Step 5: 编写测试**

```python
# backend/tests/test_llm.py
import pytest
from unittest.mock import AsyncMock, patch
from app.llm.router import LLMRouter, ROUTING_STRATEGIES

def test_routing_strategies_exist():
    assert "cost_first" in ROUTING_STRATEGIES
    assert "quality_first" in ROUTING_STRATEGIES
    assert "balanced" in ROUTING_STRATEGIES

def test_routing_strategy_has_required_keys():
    for name, strategy in ROUTING_STRATEGIES.items():
        for key in ["schema_analysis", "data_sampling", "tagging", "complex_reasoning"]:
            assert key in strategy, f"{name} missing {key}"
```

- [ ] **Step 6: Commit**

```bash
git add backend/app/llm/
git commit -m "feat: add LLM multi-provider abstraction and router"
```

### Task 2.2: Agent 采样引擎 + 标注 Prompt

**Files:**
- Create: `backend/app/agent/data_sampler.py`
- Create: `backend/app/agent/prompt_templates.py`
- Create: `backend/app/agent/tag_inferrer.py`

- [ ] **Step 1: 创建 DataSampler**

```python
# backend/app/agent/data_sampler.py
import sqlalchemy as sa
from app.agent.schema_discovery import SchemaDiscoveryEngine

class DataSampler:
    @staticmethod
    async def sample_table(conn, table_name: str, row_count: int = 5) -> dict:
        url = SchemaDiscoveryEngine.create_engine_url(conn)
        engine = sa.create_engine(url)
        columns = []
        sample_rows = []
        with engine.connect() as c:
            result = c.execute(sa.text(f"SELECT * FROM {table_name} LIMIT {row_count}"))
            sample_rows = [dict(row._mapping) for row in result]
            for col_name in sample_rows[0].keys() if sample_rows else []:
                null_count = c.execute(
                    sa.text(f"SELECT COUNT(*) FROM {table_name} WHERE {col_name} IS NULL")
                ).scalar()
                distinct_count = c.execute(
                    sa.text(f"SELECT COUNT(DISTINCT {col_name}) FROM {table_name} WHERE {col_name} IS NOT NULL")
                ).scalar()
                total_count = c.execute(sa.text(f"SELECT COUNT(*) FROM {table_name}")).scalar()
                null_ratio = round(null_count / total_count, 2) if total_count > 0 else 0
                columns.append({
                    "name": col_name,
                    "sample_values": [str(r[col_name])[:200] for r in sample_rows[:3]],
                    "null_ratio": null_ratio,
                    "distinct_count": distinct_count,
                })
        engine.dispose()
        return {"table_name": table_name, "columns": columns, "sample_rows": sample_rows}
```

- [ ] **Step 2: 创建 Prompt 模板**

```python
# backend/app/agent/prompt_templates.py
BANK_LABELING_SYSTEM_PROMPT = """你是一个银行数据标注专家 Agent。

【角色】
- 外资银行数据治理助手，遵循国际银行业数据分类标准
- 标注必须可解释，记录 evidence
- confidence < 0.7 标记为"需人工确认"

【敏感度分级】
- 身份证/护照/SSN/银行卡号 → PII
- name/phone/email/address → PII
- amount/balance/salary/income → Financial
- 其他业务字段 → Internal

【数据域映射】
- 表名含 cust/client/consumer → 客户信息
- 表名含 tx/trade/transaction → 交易记录
- 表名含 acct/account → 账户信息
- 无明确匹配 → 根据字段语义推断

【新标签发现】
- 可提出新标签值(confidence ≤ 0.8)
- evidence 中注明"新发现"

【输出格式】
```json
{
  "table_tags": [{"category": "domain", "value": "...", "confidence": 0.xx, "evidence": "..."}],
  "column_tags": [
    {"column": "field_name", "tags": [
      {"category": "sensitivity", "value": "PII", "confidence": 0.xx, "evidence": "..."}
    ]}
  ]
}
```
"""

def build_annotation_prompt(table_name: str, table_comment: str, columns: list[dict], sample_rows: list[dict]) -> list[dict]:
    import json
    col_info = "\n".join([
        f"  - {c['name']} ({c['type']}) PK={c['is_pk']} FK={c['is_fk']}"
        for c in columns
    ])
    sample_str = json.dumps(sample_rows[:3], indent=2, ensure_ascii=False, default=str)
    user_msg = f"""表名: {table_name}
注释: {table_comment}
字段 ({len(columns)}):
{col_info}

采样数据:
{sample_str}

请分析并输出标注。"""
    return [
        {"role": "system", "content": BANK_LABELING_SYSTEM_PROMPT},
        {"role": "user", "content": user_msg},
    ]
```

- [ ] **Step 3: Commit**

```bash
git add backend/app/agent/
git commit -m "feat: add data sampler and annotation prompt templates"
```

### Task 2.3: Agent Engine + 异步任务

**Files:**
- Create: `backend/app/agent/engine.py`
- Create: `backend/app/routers/tasks.py`
- Create: `backend/app/services/annotation_service.py`

- [ ] **Step 1: 创建 AnnotationEngine**

```python
# backend/app/agent/engine.py
import json
import logging
from sqlalchemy.ext.asyncio import AsyncSession
from app.database import async_session
from app.models.table import DiscoveredTable
from app.models.column import DiscoveredColumn
from app.models.annotation import Annotation
from app.agent.schema_discovery import SchemaDiscoveryEngine
from app.agent.data_sampler import DataSampler
from app.agent.prompt_templates import build_annotation_prompt
from app.llm.router import LLMRouter

logger = logging.getLogger(__name__)
llm_router = LLMRouter()

class AnnotationEngine:
    MAX_FIELDS_PER_BATCH = 50

    @staticmethod
    async def run_annotation(connection, table_names: list[str] | None = None):
        """对指定数据源执行全量标注"""
        async with async_session() as db:
            # Step 1: Discovery
            tables = await SchemaDiscoveryEngine.discover_tables(connection)
            for t in tables:
                if table_names and t["table_name"] not in table_names:
                    continue
                # 写入 discovered_tables
                table_record = DiscoveredTable(
                    connection_id=connection.id,
                    table_name=t["table_name"],
                    table_comment=t.get("table_comment", ""),
                    column_count=t["column_count"],
                    scan_status="scanning",
                )
                db.add(table_record)
                await db.flush()

                # Step 2: 写入字段
                for col in t["columns"]:
                    col_record = DiscoveredColumn(
                        table_id=table_record.id,
                        column_name=col["name"],
                        data_type=col["type"],
                        is_nullable=col["nullable"],
                        is_primary_key=col["is_pk"],
                        is_foreign_key=col["is_fk"],
                    )
                    db.add(col_record)
                await db.commit()

                # Step 3: 采样
                sample = await DataSampler.sample_table(connection, t["table_name"])

                # Step 4: 分批 LLM 标注
                all_cols = t["columns"]
                batches = [all_cols[i:i + AnnotationEngine.MAX_FIELDS_PER_BATCH]
                           for i in range(0, len(all_cols), AnnotationEngine.MAX_FIELDS_PER_BATCH)]

                for batch in batches:
                    prompt = build_annotation_prompt(
                        t["table_name"], t.get("table_comment", ""),
                        batch, sample["sample_rows"],
                    )
                    try:
                        result_text = await llm_router.route("tagging", prompt)
                        result = json.loads(result_text.strip("```json\n").strip("```"))
                        # 写入表级标签
                        for tag in result.get("table_tags", []):
                            db.add(Annotation(
                                target_type="table", target_id=table_record.id,
                                tag_category=tag["category"], tag_value=tag["value"],
                                confidence=tag.get("confidence"), evidence=tag.get("evidence"),
                                source="agent", status="suggested",
                            ))
                        # 写入字段级标签
                        for col_tag in result.get("column_tags", []):
                            col_record_q = await db.execute(
                                __import__("sqlalchemy").select(DiscoveredColumn)
                                .where(DiscoveredColumn.table_id == table_record.id)
                                .where(DiscoveredColumn.column_name == col_tag["column"])
                            )
                            col_rec = col_record_q.scalar_one_or_none()
                            if col_rec:
                                for tag in col_tag.get("tags", []):
                                    db.add(Annotation(
                                        target_type="column", target_id=col_rec.id,
                                        tag_category=tag["category"], tag_value=tag["value"],
                                        confidence=tag.get("confidence"), evidence=tag.get("evidence"),
                                        source="agent", status="suggested",
                                    ))
                    except Exception as e:
                        logger.error(f"LLM annotation failed for {t['table_name']}: {e}")

                table_record.scan_status = "completed"
                await db.commit()

            return {"status": "completed", "tables_scanned": len(tables)}
```

- [ ] **Step 2: 创建 tasks router**

```python
# backend/app/routers/tasks.py
from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from app.database import get_db
from app.models.table import DiscoveredTable
from sqlalchemy import select

router = APIRouter(prefix="/api/tasks", tags=["tasks"])

@router.get("/{task_id}")
async def get_task_status(task_id: str, db: AsyncSession = Depends(get_db)):
    # 用 connection_id 作为 task_id 简化处理
    result = await db.execute(
        select(DiscoveredTable).where(DiscoveredTable.connection_id == task_id)
    )
    tables = result.scalars().all()
    total = len(tables)
    completed = sum(1 for t in tables if t.scan_status == "completed")
    failed = sum(1 for t in tables if t.scan_status == "failed")
    return {
        "task_id": task_id,
        "total_tables": total,
        "completed_tables": completed,
        "failed_tables": failed,
        "progress": f"{completed}/{total}",
        "status": "completed" if completed == total else "running" if completed > 0 else "pending",
    }
```

- [ ] **Step 3: Commi**t

```bash
git add backend/app/agent/engine.py backend/app/routers/tasks.py
git commit -m "feat: add annotation engine with batch LLM processing"
```

### Task 2.4: 标注结果 API + 前端展示

**Files:**
- Create: `backend/app/routers/annotations.py`
- Create: `frontend/src/lib/api/annotations.ts`
- Create: `frontend/src/components/annotations/TableTagCard.tsx`
- Create: `frontend/src/components/annotations/ColumnTagTable.tsx`
- Create: `frontend/src/components/annotations/TagChip.tsx`
- Create: `frontend/src/pages/AnnotationResult.tsx`
- Create: `frontend/src/types/annotation.ts`

(Detailed implementation mirrors Task 1.4 / 1.6 patterns — full code in subagent execution)

- [ ] **Step 1: 创建 annotations router (GET list, GET by table_id)**
- [ ] **Step 2: 创建 AnnotationResult 前端页面** — 显示已标注表列表，点击进入字段级详情
- [ ] **Step 3: Commit**

```bash
git add backend/app/routers/annotations.py frontend/src/pages/AnnotationResult.tsx
git commit -m "feat: add annotation results API and frontend page"
```

---

## Phase 3: 审核 + Memory + Skills (Weeks 5-6)

### Task 3.1: 标注审核 + 标签体系

**Files:**
- Create: `backend/app/routers/tags.py`
- Create: `frontend/src/lib/api/tags.ts`
- Create: `frontend/src/pages/TagManagement.tsx`
- Modify: `backend/app/routers/annotations.py` (add review endpoint)

- [ ] **Step 1: 添加审核端点** — `PUT /api/annotations/{id}/review` 支持 approve/reject/modify
- [ ] **Step 2: 标签体系 CRUD** — `GET/POST/PUT /api/tags/categories`, `GET/POST/PUT /api/tags/definitions`
- [ ] **Step 3: 前端审核界面** — 在 AnnotationDetail 页面添加批量通过/驳回按钮
- [ ] **Step 4: 标签管理页面** — 预设标签展示，新发现标签列表+确认

### Task 3.2: Memory 系统

**Files:**
- Create: `backend/app/models/memory.py`
- Create: `backend/alembic/versions/002_memory.py`
- Create: `backend/app/memory/__init__.py`
- Create: `backend/app/memory/manager.py`
- Create: `backend/app/memory/extractor.py`
- Create: `backend/app/memory/retriever.py`
- Create: `backend/app/routers/memory.py`
- Create: `frontend/src/types/memory.ts`
- Create: `frontend/src/lib/api/memory.ts`
- Create: `frontend/src/pages/MemoryBrowser.tsx`
- Create: `frontend/src/components/memory/MemoryEntryCard.tsx`

- [ ] **Step 1: 创建 MemoryEntry 模型 + migration**

```python
# backend/app/models/memory.py
class MemoryEntry(Base):
    __tablename__ = "memory_entries"
    id = Column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    memory_type = Column(String(50), nullable=False)  # pattern | correction | experience | knowledge
    key = Column(String(500), nullable=False)
    content = Column(Text, nullable=False)  # JSON
    embedding = Column(String(1000))  # pgvector vector (stored as string for MVP)
    source = Column(String(50), default="agent_learned")
    confidence = Column(String(10))
    hit_count = Column(Integer, default=0)
    last_accessed = Column(DateTime)
    created_at = Column(DateTime, default=datetime.utcnow)
    expires_at = Column(DateTime, nullable=True)
```

- [ ] **Step 2: 创建 MemoryManager**

```python
# backend/app/memory/manager.py
import json
import uuid
from datetime import datetime
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, desc
from app.models.memory import MemoryEntry
from app.memory.extractor import PatternExtractor

class MemoryManager:
    @staticmethod
    async def add(db: AsyncSession, memory_type: str, key: str,
                  content: dict, source: str = "agent_learned", confidence: float = 0.0):
        entry = MemoryEntry(
            id=str(uuid.uuid4()),
            memory_type=memory_type,
            key=key,
            content=json.dumps(content, ensure_ascii=False),
            source=source,
            confidence=str(confidence),
            created_at=datetime.utcnow(),
        )
        db.add(entry)
        await db.commit()
        return entry

    @staticmethod
    async def search(db: AsyncSession, query: str, memory_type: str | None = None, top_k: int = 5):
        """搜索记忆条目 (简化版: 按类型+key模糊匹配)"""
        stmt = select(MemoryEntry).order_by(desc(MemoryEntry.hit_count)).limit(top_k)
        if memory_type:
            stmt = stmt.where(MemoryEntry.memory_type == memory_type)
        result = await db.execute(stmt)
        return result.scalars().all()

    @staticmethod
    async def record_hit(db: AsyncSession, entry_id: str):
        entry = await db.get(MemoryEntry, entry_id)
        if entry:
            entry.hit_count = (entry.hit_count or 0) + 1
            entry.last_accessed = datetime.utcnow()
            await db.commit()
```

- [ ] **Step 3: 创建 PatternExtractor**

```python
# backend/app/memory/extractor.py
import json
from collections import Counter
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.models.annotation import Annotation
from app.memory.manager import MemoryManager

class PatternExtractor:
    @staticmethod
    async def extract_patterns(db: AsyncSession):
        """从已审核的标注中提取高频模式"""
        result = await db.execute(
            select(Annotation).where(Annotation.status == "approved")
            .where(Annotation.source == "agent")
        )
        annotations = result.scalars().all()

        # 按 tag_value 分组统计
        patterns = Counter()
        for ann in annotations:
            key = f"{ann.tag_category}:{ann.tag_value}"
            if ann.evidence:
                patterns[key] += 1

        # 高频模式写入 Pattern Memory
        for (key, count) in patterns.most_common(20):
            if count >= 3:  # 出现3次以上才视为模式
                category, value = key.split(":", 1)
                await MemoryManager.add(
                    db, "pattern", key,
                    {"tag_category": category, "tag_value": value, "frequency": count},
                    confidence=min(0.7 + count * 0.05, 0.95),
                )
```

- [ ] **Step 4: 创建 memory router**

```python
# backend/app/routers/memory.py
from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from app.database import get_db
from app.memory.manager import MemoryManager

router = APIRouter(prefix="/api/memory", tags=["memory"])

@router.get("")
async def list_memory(memory_type: str | None = None, db: AsyncSession = Depends(get_db)):
    return await MemoryManager.search(db, "", memory_type)

@router.get("/search")
async def search_memory(q: str, memory_type: str | None = None, db: AsyncSession = Depends(get_db)):
    return await MemoryManager.search(db, q, memory_type)

@router.post("/extract-patterns")
async def extract_patterns(db: AsyncSession = Depends(get_db)):
    from app.memory.extractor import PatternExtractor
    await PatternExtractor.extract_patterns(db)
    return {"message": "patterns extracted"}
```

- [ ] **Step 5: 前端 MemoryBrowser 页面** — 卡片式展示记忆条目，支持按类型过滤和关键词搜索

### Task 3.3: Skills 管理系统

**Files:**
- Create: `backend/app/skills/base.py`
- Create: `backend/app/skills/registry.py`
- Create: `backend/app/skills/pipeline.py`
- Create: `backend/app/skills/builtin/schema_discovery.py`
- Create: `backend/app/skills/builtin/data_sampling.py`
- Create: `backend/app/skills/builtin/pii_detection.py`
- Create: `backend/app/skills/builtin/domain_classifier.py`
- Create: `backend/app/skills/builtin/quality_assessment.py`
- Create: `backend/app/routers/skills.py`
- Create: `frontend/src/types/skill.ts`
- Create: `frontend/src/lib/api/skills.ts`
- Create: `frontend/src/pages/SkillsManager.tsx`
- Create: `frontend/src/components/skills/SkillCard.tsx`
- Create: `frontend/src/components/skills/PipelineForm.tsx`

- [ ] **Step 1: 创建 BaseSkill 基类**

```python
# backend/app/skills/base.py
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any

@dataclass
class SkillMetadata:
    name: str
    version: str
    type: str  # builtin | business | governance | custom
    description: str
    dependencies: list[str] = field(default_factory=list)
    min_model: str = "sonnet"

@dataclass
class SkillContext:
    connection_id: str
    table_name: str
    params: dict = field(default_factory=dict)

@dataclass
class SkillResult:
    success: bool
    data: Any = None
    error: str | None = None
    duration_ms: int = 0

class BaseSkill(ABC):
    @property
    @abstractmethod
    def metadata(self) -> SkillMetadata:
        pass

    @abstractmethod
    async def validate(self, context: SkillContext) -> bool:
        pass

    @abstractmethod
    async def execute(self, context: SkillContext) -> SkillResult:
        pass

    @abstractmethod
    async def estimate_cost(self, context: SkillContext) -> dict:
        """返回预估的 token 数和耗时"""
        pass
```

- [ ] **Step 2: 创建 SkillRegistry**

```python
# backend/app/skills/registry.py
from app.skills.base import BaseSkill

class SkillRegistry:
    _skills: dict[str, BaseSkill] = {}

    @classmethod
    def register(cls, skill: BaseSkill):
        cls._skills[skill.metadata.name] = skill

    @classmethod
    def get(cls, name: str) -> BaseSkill | None:
        return cls._skills.get(name)

    @classmethod
    def list_all(cls) -> list[BaseSkill]:
        return list(cls._skills.values())

    @classmethod
    def list_by_type(cls, skill_type: str) -> list[BaseSkill]:
        return [s for s in cls._skills.values() if s.metadata.type == skill_type]
```

- [ ] **Step 3: 创建 Pipeline 执行器**

```python
# backend/app/skills/pipeline.py
import asyncio
from app.skills.registry import SkillRegistry
from app.skills.base import SkillContext, SkillResult

class PipelineExecutor:
    @staticmethod
    async def run(pipeline_config: list[dict], connection_id: str, table_name: str) -> list[SkillResult]:
        results = []
        context = SkillContext(connection_id=connection_id, table_name=table_name)
        completed = set()

        while len(results) < len(pipeline_config):
            for step in pipeline_config:
                if step["skill"] in completed:
                    continue
                deps = step.get("depends_on", [])
                if all(d in completed for d in deps):
                    skill = SkillRegistry.get(step["skill"])
                    if skill:
                        context.params = step.get("params", {})
                        result = await skill.execute(context)
                        results.append(result)
                        completed.add(step["skill"])
            await asyncio.sleep(0)  # yield control
        return results
```

- [ ] **Step 4: 创建 5 个内置 Skill 实现** (每个 ~30 行，封装现有 agent 逻辑)
- [ ] **Step 5: 创建 skills router + 前端管理页面**

### Task 3.4: LLM 配置 + 审计日志

**Files:**
- Create: `backend/app/routers/llm_config.py`
- Create: `backend/app/routers/audit.py`
- Create: `frontend/src/lib/api/llm.ts`
- Create: `frontend/src/pages/LlmConfig.tsx`
- Create: `frontend/src/pages/AuditLog.tsx`

- [ ] **Step 1: LLM 配置 API** — GET/PUT provider 设置和路由策略
- [ ] **Step 2: 审计日志 API** — 查询带分页的审计记录
- [ ] **Step 3: 前端 LLM 配置页面** — Provider 配置表单 + 策略选择器
- [ ] **Step 4: 审计日志页面** — DataTable 展示所有操作记录

---

## Phase 4: 业务发现 + 数据资产 (Weeks 7-8)

### Task 4.1: 业务发现 Agent

**Files:**
- Create: `backend/app/routers/discovery.py`
- Create: `frontend/src/lib/api/discovery.ts`
- Create: `frontend/src/types/discovery.ts`
- Create: `frontend/src/pages/BusinessDiscovery.tsx`
- Create: `frontend/src/components/discovery/InsightCard.tsx`
- Create: `frontend/src/components/discovery/CustomerSegment.tsx`

- [ ] **Step 1: 业务发现 API** — 基于已标注数据，执行预置分析场景，输出 insight 报告
- [ ] **Step 2: 前端业务发现页面** — InsightCard 展示各发现结果，CustomerSegment 表格展示客户群

### Task 4.2: 数据资产发现

**Files:**
- Create: `backend/app/routers/governance.py`
- Create: `frontend/src/lib/api/governance.ts`
- Create: `frontend/src/pages/DataAssets.tsx`

- [ ] **Step 1: 数据资产 API** — 盘点统计、质量报告、关联发现
- [ ] **Step 2: 前端数据资产页面** — 统计卡片、质量警告列表、关联发现

### Task 4.3: Dashboard + Docker 部署

**Files:**
- Create: `frontend/src/pages/Dashboard.tsx`
- Create: `frontend/src/hooks/useConnections.ts`
- Create: `frontend/src/hooks/useAnnotations.ts`
- Create: `frontend/src/hooks/useDiscovery.ts`
- Create: `frontend/Dockerfile`
- Create: `frontend/nginx.conf`
- Create: `backend/Dockerfile.backend`

- [ ] **Step 1: Dashboard** — 统计卡片 (数据源数/表数/字段数/新标签数)、最近活动时间线、业务发现摘要
- [ ] **Step 2: Dockerfile.backend**

```dockerfile
FROM python:3.12-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY . .
CMD ["uvicorn", "app.main:app", "--host", "0.0.0.0", "--port", "8000"]
```

- [ ] **Step 3: frontend Docker + Nginx** — 多阶段构建, Nginx 提供静态文件 + API 反向代理

```dockerfile
# Dockerfile.frontend
FROM node:20-alpine AS build
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build

FROM nginx:alpine
COPY --from=build /app/dist /usr/share/nginx/html
COPY nginx.conf /etc/nginx/conf.d/default.conf
```

- [ ] **Step 4: 最终验证** — `docker-compose up --build` 后验证全链路

---

## Phase 5: Post-MVP (未来)

| 特性 | 说明 |
|------|------|
| 规则引擎 | 从 Pattern Memory 导出为 YAML 规则文件，热加载执行 |
| 定时扫描 | APScheduler / Celery Beat cron 触发 |
| 通知集成 | 标注完成 / 新发现通过 Webhook / 邮件通知 |
| RBAC | 多角色权限 (admin / editor / viewer) |
| 知识图谱 | Neo4j 可视化实体关系 |
| 联邦标注 | 跨数据源表关联发现 |

---

## Spec 覆盖检查

| 设计文档章节 | 对应 Task | 说明 |
|------------|----------|------|
| §4 后端架构 | Task 1.1-1.4 | FastAPI base + CRUD |
| §4.3 数据库模型 | Task 1.2 | 6 个核心模型 |
| §5 Agent 标注引擎 | Task 2.1-2.3 | Schema Discovery + Sampler + LLM |
| §6 LLM 多模型 | Task 2.1 | 3 Provider + Router |
| §7 业务发现 | Task 4.1 | Discovery API + 前端 |
| §8 数据资产 | Task 4.2 | Governance API + 前端 |
| §9 Memory | Task 3.2 | 4 种记忆类型 + 检索 |
| §10 Skills | Task 3.3 | Registry + Pipeline + 5 built-in |
| §11 前端 | Task 1.5-1.6, 2.4, 3.1-3.4, 4.1-4.3 | 11 个页面 |
| §12 部署 | Task 4.3 | Docker compose full stack |

---

Plan complete and saved to `docs/superpowers/plans/2026-06-10-data-label-agent-plan.md`.

两个执行方式：

**1. Subagent-Driven (推荐)** — 逐个任务派发独立 subagent，每完成一个任务做 review，快速迭代

**2. Inline Execution** — 在当前会话执行，批量执行带检查点

你倾向哪种？

# Study-Abroad Demo Golden Journey Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Deliver one deterministic, offline-capable “留学金融机会发现” Demo journey whose knowledge, tags, segments, opportunities, data value, governance, and audit results remain consistent across Chat, Canvas, and product pages.

**Architecture:** Define a versioned Python scenario dataset as the single source for stable identities and named metrics. Shared golden-journey services return typed business results used by Demo APIs and Workbench Runs; the SQLite seed materializes supporting records but does not become the source of business rules. Existing tables are preserved, keeping the scenario portable to PostgreSQL.

**Tech Stack:** FastAPI, SQLAlchemy async ORM, SQLite/PostgreSQL-compatible data types, Pydantic, pytest, React 18, TypeScript.

---

## File Map

- Create `backend/app/demo/__init__.py`: Demo scenario package exports.
- Create `backend/app/demo/study_abroad_finance_v1.py`: version, stable IDs, facts, metrics, and validation.
- Create `backend/app/services/golden_journey_service.py`: typed shared results for tags, segment, opportunities, data value, knowledge, and governance.
- Create `backend/tests/test_demo_golden_journey.py`: dataset and cross-result consistency contracts.
- Modify `backend/app/seed_demo_data.py`: idempotent scenario materialization.
- Create `backend/tests/test_demo_seed.py`: repeatable seed and record-presence tests.
- Modify `backend/app/routers/tags.py`, `backend/app/routers/customer_intelligence.py`, `backend/app/routers/discovery.py`, `backend/app/routers/data_governance.py`, and `backend/app/routers/governance.py`: use shared Demo results.
- Modify `backend/app/services/workbench_run_service.py`: build Demo Run results from the same service.
- Modify `backend/tests/test_workbench_runs.py`: Run/result consistency tests.
- Modify `frontend/src/pages/TagAnalysis.tsx`: remove random authoritative Demo metrics.
- Modify affected frontend API types only where required by the shared response contracts.
- Create `docs/demo/study-abroad-golden-journey.md`: demonstration script and expected values.

### Task 1: Define the Versioned Scenario Dataset

**Files:**
- Create: `backend/app/demo/__init__.py`
- Create: `backend/app/demo/study_abroad_finance_v1.py`
- Create: `backend/tests/test_demo_golden_journey.py`

- [ ] **Step 1: Write failing dataset stability and completeness tests**

Test the public scenario contract:

```python
def test_scenario_has_stable_version_and_ids():
    assert scenario.DATASET_VERSION == "study_abroad_finance_v1"
    assert scenario.stable_id("tag", "study_abroad_intent") == scenario.stable_id("tag", "study_abroad_intent")
    assert scenario.stable_id("tag", "study_abroad_intent") != scenario.stable_id("tag", "marketing_contactable")


def test_scenario_contains_complete_golden_journey():
    assert len(scenario.KNOWLEDGE_DOCUMENTS) >= 5
    assert len(scenario.CORE_TAGS) >= 7
    assert scenario.METRICS["study_abroad_prospect_count"] > 0
    assert scenario.SEGMENTS["study_abroad_prospects"]["customer_count"] == scenario.METRICS["study_abroad_prospect_count"]
    assert scenario.MARKET_OPPORTUNITIES
    assert scenario.DATA_VALUE_ASSESSMENTS
    assert len(scenario.AUDIT_EVENTS) >= 4
```

- [ ] **Step 2: Run the dataset tests and confirm import failure**

Run:

```bash
cd backend
pytest tests/test_demo_golden_journey.py -q
```

Expected: collection fails because the Demo scenario package does not exist.

- [ ] **Step 3: Implement deterministic identity and named metrics**

Use UUID5 and immutable module-level facts:

```python
DATASET_VERSION = "study_abroad_finance_v1"
DATASET_NAMESPACE = UUID("d65d67a2-9038-5d31-b463-c04b94cd5ec8")


def stable_id(kind: str, key: str) -> str:
    return str(uuid5(DATASET_NAMESPACE, f"{DATASET_VERSION}:{kind}:{key}"))


METRICS = {
    "retail_customer_count": 1_280_000,
    "study_abroad_intent_count": 18_640,
    "study_abroad_prospect_count": 12_480,
    "prior_study_abroad_remittance_count": 4_960,
    "supporting_data_value_score": 86,
    "quality_issue_count": 7,
}
```

Define the five required knowledge documents, core data assets, seven core tags, deterministic customer-tag aggregate assignments, one saved segment, at least three market opportunities, data-value evidence, governance findings, requirements/tasks, audit events, and selected memory records. Every reference must use `stable_id()`. Add `validate()` that raises `ValueError` for missing references, duplicate IDs, assignment/segment mismatches, or metric mismatches.

- [ ] **Step 4: Verify the dataset contract**

Run:

```bash
cd backend
pytest tests/test_demo_golden_journey.py -q
```

Expected: all dataset tests pass and `validate()` returns without error.

- [ ] **Step 5: Commit the scenario dataset**

```bash
git add backend/app/demo backend/tests/test_demo_golden_journey.py
git commit -m "feat: define study abroad demo dataset"
```

### Task 2: Implement Typed Shared Golden-Journey Services

**Files:**
- Create: `backend/app/services/golden_journey_service.py`
- Modify: `backend/tests/test_demo_golden_journey.py`

- [ ] **Step 1: Add failing typed-result and reconciliation tests**

Assert:

```python
def test_tag_search_segment_opportunity_and_value_results_reconcile():
    tags = service.search_tags("留学")
    segment = service.evaluate_segment("study_abroad_prospects")
    opportunities = service.discover_market_opportunities(segment.id)
    value = service.assess_data_value(segment.id)

    assert {tag.id for tag in tags} >= {
        scenario.stable_id("tag", "study_abroad_intent"),
        scenario.stable_id("tag", "study_abroad_remittance"),
    }
    assert segment.customer_count == scenario.METRICS["study_abroad_prospect_count"]
    assert all(item.segment_id == segment.id for item in opportunities)
    assert value.score == scenario.METRICS["supporting_data_value_score"]
```

- [ ] **Step 2: Run the focused tests and confirm missing service failure**

Run:

```bash
cd backend
pytest tests/test_demo_golden_journey.py -q
```

Expected: failure importing `golden_journey_service`.

- [ ] **Step 3: Implement explicit typed result models and service methods**

Create Pydantic result models and these methods:

```python
def search_tags(keyword: str | None) -> list[TagResult]
def get_tag(tag_id: str) -> TagResult
def evaluate_segment(segment_key: str = "study_abroad_prospects") -> SegmentResult
def discover_market_opportunities(segment_id: str) -> list[MarketOpportunityResult]
def assess_data_value(segment_id: str) -> DataValueResult
def get_knowledge_evidence(tag_id: str) -> list[KnowledgeEvidenceResult]
def get_governance_evidence(segment_id: str) -> GovernanceEvidenceResult
```

Service methods must read only the versioned dataset, return stable IDs, and reject unknown IDs with a typed domain error. Do not read endpoint-specific constants or calculate Demo metrics from row ordering.

- [ ] **Step 4: Verify cross-result consistency**

Run:

```bash
cd backend
pytest tests/test_demo_golden_journey.py -q
```

Expected: all consistency tests pass.

- [ ] **Step 5: Commit shared services**

```bash
git add backend/app/services/golden_journey_service.py backend/tests/test_demo_golden_journey.py
git commit -m "feat: add shared demo business services"
```

### Task 3: Make Demo Seed Idempotent and Complete

**Files:**
- Modify: `backend/app/seed_demo_data.py`
- Create: `backend/tests/test_demo_seed.py`

- [ ] **Step 1: Write failing seed tests**

Run the seed twice against a temporary SQLite database and assert:

```python
async def test_seed_is_idempotent_and_materializes_required_records(db_session):
    await seed_demo_data(db_session, dataset_version="study_abroad_finance_v1")
    first = await record_counts(db_session)
    await seed_demo_data(db_session, dataset_version="study_abroad_finance_v1")
    second = await record_counts(db_session)

    assert second == first
    assert first["documents"] >= 5
    assert first["tag_definitions"] >= 7
    assert first["requirements"] >= 4
    assert first["audit_logs"] >= 4
    assert first["memory_entries"] >= 2
```

- [ ] **Step 2: Run the seed test and confirm missing-record failures**

Run:

```bash
cd backend
pytest tests/test_demo_seed.py -q
```

Expected: failure because the current seed skips when any connection exists and does not materialize all required records.

- [ ] **Step 3: Replace random IDs and all-or-nothing skip logic**

For every scenario-backed row:

1. Use the dataset stable ID.
2. Upsert by stable primary key or a documented unique business key.
3. Update mutable Demo fields when the dataset version changes.
4. Leave non-Demo/user-created records untouched.
5. Materialize connections, tables, columns, annotations, documents, tags, requirements, tasks, audit events, and memory records supported by existing models.

Store the dataset version in a dedicated seeded memory/config record using key `demo_dataset_version`; do not add a column to an existing table.

- [ ] **Step 4: Add explicit initialization validation**

Call `scenario.validate()` before any write. If validation fails, abort the transaction and report the dataset version and validation error. Do not present partially seeded Demo data.

- [ ] **Step 5: Verify seed repeatability**

Run:

```bash
cd backend
pytest tests/test_demo_seed.py tests/test_demo_golden_journey.py -q
```

Expected: both tests pass, with identical record counts after the second seed.

- [ ] **Step 6: Commit the seed expansion**

```bash
git add backend/app/seed_demo_data.py backend/tests/test_demo_seed.py
git commit -m "feat: seed complete study abroad demo journey"
```

### Task 4: Consolidate Demo APIs Around Shared Results

**Files:**
- Modify: `backend/app/routers/tags.py`
- Modify: `backend/app/routers/customer_intelligence.py`
- Modify: `backend/app/routers/discovery.py`
- Modify: `backend/app/routers/data_governance.py`
- Modify: `backend/app/routers/governance.py`
- Create: `backend/tests/test_demo_api_consistency.py`

- [ ] **Step 1: Write failing cross-API contract tests**

Use the HTTP client to assert the same stable IDs and metrics appear across endpoints:

```python
async def test_demo_tag_segment_opportunity_and_governance_apis_reconcile(client, demo_mode):
    tags = (await client.get("/api/tags/market", params={"keyword": "留学"})).json()
    segment = (await client.post("/api/tags/segment", json={"segment_key": "study_abroad_prospects"})).json()
    opportunities = (await client.get("/api/discovery/opportunities", params={"segment_id": segment["id"]})).json()
    governance = (await client.get("/api/data-governance/evidence", params={"segment_id": segment["id"]})).json()

    assert segment["customer_count"] == scenario.METRICS["study_abroad_prospect_count"]
    assert all(item["segment_id"] == segment["id"] for item in opportunities)
    assert governance["quality_issue_count"] == scenario.METRICS["quality_issue_count"]
    assert scenario.stable_id("tag", "study_abroad_intent") in {item["id"] for item in tags}
```

- [ ] **Step 2: Run the API consistency test and confirm drift**

Run:

```bash
cd backend
pytest tests/test_demo_api_consistency.py -q
```

Expected: failures show endpoint-specific constants or derived values do not reconcile.

- [ ] **Step 3: Route Demo branches through `golden_journey_service`**

Replace `_demo_market_tags`, `_demo_dev_sources`, `_demo_dev_candidates`, `_demo_segment_result`, index-derived synthetic values, and other endpoint-local authoritative Demo constants with service calls. Preserve existing response fields where the frontend depends on them; add stable `id`, `segment_id`, `source_ids`, and evidence fields required by the shared contract.

- [ ] **Step 4: Keep real-mode behavior isolated**

Only `is_demo_mode()` branches use the scenario service in this task. Do not silently return Demo facts in AI/real mode. Existing real-mode queries remain unchanged until the shared business-tool plan is executed.

- [ ] **Step 5: Verify cross-API consistency**

Run:

```bash
cd backend
pytest tests/test_demo_api_consistency.py tests/test_demo_golden_journey.py -q
```

Expected: all tests pass.

- [ ] **Step 6: Commit consolidated Demo APIs**

```bash
git add backend/app/routers/tags.py backend/app/routers/customer_intelligence.py backend/app/routers/discovery.py backend/app/routers/data_governance.py backend/app/routers/governance.py backend/tests/test_demo_api_consistency.py
git commit -m "refactor: unify demo API results"
```

### Task 5: Build Workbench Runs from the Shared Demo Service

**Files:**
- Modify: `backend/app/services/workbench_run_service.py`
- Modify: `backend/tests/test_workbench_runs.py`

- [ ] **Step 1: Add failing prompt-to-shared-result tests**

For each golden prompt, call Studio Chat and the corresponding independent API, then compare stable IDs and metrics:

```python
@pytest.mark.parametrize(
    ("prompt", "action_type"),
    [
        ("留学标签有哪些", "tag_discovery"),
        ("圈选有留学需求且可营销触达的客户", "customer_segment"),
        ("有哪些留学金融市场机会", "market_opportunity"),
        ("分析这些数据的价值", "data_value_analysis"),
    ],
)
async def test_golden_prompts_create_structured_demo_runs(client, demo_mode, prompt, action_type):
    response = (await client.post("/api/studio/chat", json={"session_id": "golden", "message": prompt})).json()
    assert response["run"]["action_type"] == action_type
    assert response["run"]["status"] == "completed"
    assert response["run"]["result_data"]
```

Add explicit assertions comparing tag IDs, segment count, opportunity segment ID, and data-value score with `golden_journey_service`.

- [ ] **Step 2: Run the Workbench tests and confirm result drift**

Run:

```bash
cd backend
pytest tests/test_workbench_runs.py -q
```

Expected: one or more golden prompts return `run: null` or endpoint-specific values.

- [ ] **Step 3: Map deterministic Demo actions to service calls**

Implement a single Demo result builder:

```python
def build_demo_action_result(action_type: str, parameters: dict[str, Any]) -> dict[str, Any]:
    if action_type == "tag_discovery":
        return TagDiscoveryActionResult(tags=service.search_tags(parameters.get("keyword"))).model_dump()
    if action_type == "customer_segment":
        return SegmentActionResult(segment=service.evaluate_segment()).model_dump()
    if action_type == "market_opportunity":
        segment = service.evaluate_segment()
        return MarketOpportunityActionResult(
            segment=segment,
            opportunities=service.discover_market_opportunities(segment.id),
        ).model_dump()
    if action_type == "data_value_analysis":
        segment = service.evaluate_segment()
        return DataValueActionResult(value=service.assess_data_value(segment.id)).model_dump()
    raise UnsupportedActionError(action_type)
```

Chat explanation and Canvas must both use this structured result. Do not duplicate metrics in the explanation generator.

- [ ] **Step 4: Verify Workbench and API consistency**

Run:

```bash
cd backend
pytest tests/test_workbench_runs.py tests/test_demo_api_consistency.py -q
```

Expected: all prompt, Run, and cross-API tests pass.

- [ ] **Step 5: Commit Workbench integration**

```bash
git add backend/app/services/workbench_run_service.py backend/tests/test_workbench_runs.py
git commit -m "feat: ground demo runs in shared journey services"
```

### Task 6: Remove Frontend Authoritative Random and Mock Metrics

**Files:**
- Modify: `frontend/src/pages/TagAnalysis.tsx`
- Modify: `frontend/src/lib/api/tags.ts`
- Modify: `frontend/src/types/discovery.ts`
- Create: `frontend/src/pages/TagAnalysis.test.tsx`

- [ ] **Step 1: Add a failing stable-render test**

Mock the shared backend segment response and render the page twice:

```tsx
it("renders backend segment metrics without random changes", async () => {
  const first = render(<TagAnalysis />);
  expect(await screen.findByText("12,480")).toBeInTheDocument();
  first.unmount();
  render(<TagAnalysis />);
  expect(await screen.findByText("12,480")).toBeInTheDocument();
});
```

- [ ] **Step 2: Run the test and confirm local/random behavior**

Run:

```bash
cd frontend
npm test -- src/pages/TagAnalysis.test.tsx
```

Expected: failure because the page does not consistently use the backend result.

- [ ] **Step 3: Replace random and local authoritative values**

Remove `Math.random()` from scenario comparisons and stop treating localStorage segment totals as authoritative. The page may retain local UI preferences, but tag coverage, segment count, opportunity value, and data-quality metrics must come from backend response fields.

- [ ] **Step 4: Verify frontend tests and build**

Run:

```bash
cd frontend
npm test -- src/pages/TagAnalysis.test.tsx
npm run build
```

Expected: stable-render test and build pass.

- [ ] **Step 5: Commit frontend consistency repair**

```bash
git add frontend/src/pages/TagAnalysis.tsx frontend/src/pages/TagAnalysis.test.tsx frontend/src/lib/api/tags.ts frontend/src/types/discovery.ts
git commit -m "fix: render authoritative demo metrics from APIs"
```

### Task 7: Document and Execute the Full Demo Journey

**Files:**
- Create: `docs/demo/study-abroad-golden-journey.md`
- Create: `backend/tests/test_demo_acceptance.py`

- [ ] **Step 1: Write a failing backend acceptance script**

Implement one ordered test that:

1. initializes Demo data;
2. asks the four golden prompts;
3. verifies matching independent API outputs;
4. verifies knowledge source and lineage for a returned tag;
5. verifies segment, market opportunity, data value, governance, and audit references;
6. executes the demonstrated actions and verifies their audit events use the same stable tag, segment, and opportunity IDs;
7. verifies the journey works with external model access disabled.

- [ ] **Step 2: Run the acceptance test**

Run:

```bash
cd backend
pytest tests/test_demo_acceptance.py -q
```

Expected: the test identifies any remaining missing journey link.

- [ ] **Step 3: Close only failures exposed by the acceptance test**

Make the smallest changes in the owning service/router so every failed reference uses the versioned dataset and shared results. Do not add frontend-only values or endpoint-specific Demo metrics.

- [ ] **Step 4: Write the demonstration runbook**

Document the exact 13-step journey from the approved design, including prompts, navigation targets, expected stable object names, expected named metrics, and troubleshooting checks. State that the source of truth is `study_abroad_finance_v1`, and describe how a SQLite snapshot can be generated after seeding while retaining PostgreSQL portability.

- [ ] **Step 5: Run full verification**

Run:

```bash
cd backend
pytest -q
cd ../frontend
npm test
npm run build
```

Expected: all backend tests, frontend tests, and build pass.

- [ ] **Step 6: Verify the journey through the in-app browser**

Execute the documented journey in Demo mode. Confirm Chat and Canvas match at every step, independent pages show the same IDs/metrics, audit contains the demonstrated actions, and no external model request occurs.

- [ ] **Step 7: Commit the acceptance suite and runbook**

```bash
git add backend/tests/test_demo_acceptance.py docs/demo/study-abroad-golden-journey.md
git commit -m "test: cover complete study abroad demo journey"
```

## Completion Criteria

- `study_abroad_finance_v1` is the only authoritative source for Demo scenario identities and metrics.
- Re-seeding is idempotent and produces a portable SQLite dataset compatible with later PostgreSQL deployment.
- The four golden prompts create matching structured Runs.
- Chat, Canvas, Tag Market, Tag Analysis, Business Discovery, Data Value, Governance, and Audit reconcile.
- Demo mode works without external network or model access.
- Full backend tests, frontend tests, build, browser journey, and documented acceptance script pass.

# Stage 0 Engineering Trust Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Restore a reproducible green build and enforce stable frontend/backend contracts for routing, API clients, tag definitions, execution logs, and structured Chat Action responses.

**Architecture:** Keep the existing React, Axios, FastAPI, SQLAlchemy, and Pydantic structure. Treat the Axios response interceptor and FastAPI response models as contract boundaries, add focused Vitest and pytest coverage, and avoid introducing Stage 1 customer/tag computation models. Chat endpoints will only pass through backend-produced actions in this stage; real opportunity actions are implemented after the customer tag and segment model exists.

**Tech Stack:** React 18, TypeScript, Vite, Vitest, Axios, FastAPI, Pydantic 2, SQLAlchemy async, pytest, httpx

---

## Baseline

- `frontend/npm run build` currently fails with five TypeScript errors:
  - optional `total_opportunities`
  - invalid `agentApi.resetConfig()` return
  - wrong `Connection` import
  - missing `MarketTag.icon`
- `backend/pytest -q` currently passes: `12 passed`.
- `frontend/src/lib/api.ts` already unwraps Axios responses with `(res) => res.data`.
- `frontend/src/lib/api/execution.ts` incorrectly adds a second `/api` prefix and unwraps `.data` again.
- `frontend/src/App.tsx` registers `/governance` twice; the first registration makes `DataGovernanceCenter` unreachable.
- Frontend tag clients call definition create/update/delete endpoints that the backend does not expose.
- Frontend Studio currently synthesizes Canvas actions from reply text when the backend omits an action.
- The worktree contains unrelated in-progress changes. Never reset or revert them. Before each commit, stage only the files listed in that task and inspect `git diff --cached --stat`.

## File Structure

### New files

- `frontend/src/lib/api/__tests__/contracts.test.ts` — protects the shared Axios unwrap and request paths.
- `frontend/src/App.test.tsx` — protects unique application route registration.
- `frontend/src/types/chat.ts` — shared structured Chat Action response type.
- `backend/tests/test_execution.py` — characterizes execution-log API output.
- `backend/tests/test_tags.py` — protects tag-definition CRUD behavior.
- `backend/tests/test_chat_actions.py` — protects Chat Action pass-through on both chat endpoints.
- `backend/tests/test_api_contracts.py` — protects request IDs and the shared error response envelope.
- `backend/tests/test_runtime_dependencies.py` — verifies imported runtime packages are declared and installable.
- `backend/app/schemas/chat.py` — shared Pydantic Chat Action schema.
- `backend/app/schemas/api.py` — shared error response contract.

### Modified files

- `frontend/package.json`, `frontend/package-lock.json` — add Vitest and the frontend test command.
- `frontend/src/lib/api/agent.ts` — use the existing Axios response unwrap correctly.
- `frontend/src/lib/api/execution.ts` — remove duplicate `/api` and duplicate `.data` unwrap.
- `frontend/src/App.tsx` — use one route registry and one `/governance` route.
- `frontend/src/components/discovery/SignalsSegmentsView.tsx` — normalize optional opportunity count.
- `frontend/src/pages/DataGovernanceCenter.tsx` — correct the `Connection` type import.
- `frontend/src/pages/TagMarket.tsx` — derive icons from category instead of adding UI state to the API DTO.
- `frontend/src/lib/api/chat.ts`, `frontend/src/lib/api/studio.ts` — use the shared Chat Action response type.
- `frontend/src/pages/DataAgentStudio.tsx` — consume only backend-produced actions.
- `backend/app/schemas/tag.py` — add tag update and response contracts.
- `backend/app/routers/tags.py` — restore definition create/update/delete endpoints.
- `backend/app/routers/agent_chat.py`, `backend/app/routers/studio_chat.py` — expose the shared optional Chat Action.
- `backend/app/main.py` — attach request IDs and standardize HTTP/validation errors.
- `frontend/src/lib/api.ts` — consume the standardized error message and request ID.
- `backend/requirements.txt` — declare packages already imported by runtime code with compatible ranges.
- `backend/.env.example`, `README.md`, `docs/deployment-guide.md` — document the actual `LLM` and `DEMO_MODE` settings.

## Task 1: Add API Contract Tests and Normalize Frontend API Clients

**Files:**
- Modify: `frontend/package.json`
- Modify: `frontend/package-lock.json`
- Create: `frontend/src/lib/api/__tests__/contracts.test.ts`
- Modify: `frontend/src/lib/api/agent.ts`
- Modify: `frontend/src/lib/api/execution.ts`
- Create: `backend/tests/test_execution.py`

- [ ] **Step 1: Install the frontend contract-test runner**

Run:

```bash
cd /Users/Apple/codes/data-label/frontend
npm install --save-dev vitest
```

Update `frontend/package.json` scripts to include:

```json
{
  "scripts": {
    "dev": "vite",
    "build": "tsc && vite build",
    "test": "vitest run",
    "preview": "vite preview"
  }
}
```

Expected: `package.json` and `package-lock.json` contain Vitest.

- [ ] **Step 2: Write failing frontend API contract tests**

Create `frontend/src/lib/api/__tests__/contracts.test.ts`:

```typescript
import { beforeEach, describe, expect, it, vi } from 'vitest';

const apiMock = vi.hoisted(() => ({
  get: vi.fn(),
  post: vi.fn(),
  put: vi.fn(),
  delete: vi.fn(),
}));

vi.mock('../../api', () => ({ default: apiMock }));

import { agentApi } from '../agent';
import { executionApi, type ExecutionStep } from '../execution';

const config = {
  id: 'agent-1',
  name: '数据分析助手',
  role: '分析',
  personality: 'professional',
  description: 'test',
  auto_extract_memory: true,
  proactive_monitoring: false,
  confidence_threshold: 70,
  max_concurrent_tables: 5,
  preferred_strategy: 'balanced',
};

const log: ExecutionStep = {
  id: 'log-1',
  connection_id: 'conn-1',
  table_name: 'customers',
  step_type: 'schema_discovery',
  step_label: '发现字段',
  status: 'completed',
  input_summary: null,
  output_summary: 'ok',
  duration_ms: 10,
  metadata_json: null,
  created_at: '2026-06-14T00:00:00Z',
};

describe('frontend API contracts', () => {
  beforeEach(() => vi.clearAllMocks());

  it('uses the already-unwrapped response for agent reset', async () => {
    apiMock.post.mockResolvedValue(config);

    await expect(agentApi.resetConfig()).resolves.toEqual(config);
    expect(apiMock.post).toHaveBeenCalledWith('/agent/config/reset');
  });

  it('requests execution logs without a second /api prefix or data unwrap', async () => {
    apiMock.get.mockResolvedValue([log]);

    await expect(executionApi.getLogs('conn-1', 'customers')).resolves.toEqual([log]);
    expect(apiMock.get).toHaveBeenCalledWith('/execution/conn-1', {
      params: { table_name: 'customers' },
    });
  });

  it('returns traced table names from the unwrapped payload', async () => {
    apiMock.get.mockResolvedValue({ tables: ['customers'] });

    await expect(executionApi.getTables('conn-1')).resolves.toEqual(['customers']);
    expect(apiMock.get).toHaveBeenCalledWith('/execution/conn-1/tables');
  });
});
```

- [ ] **Step 3: Run the frontend contract tests and confirm the execution tests fail**

Run:

```bash
cd /Users/Apple/codes/data-label/frontend
npm test -- src/lib/api/__tests__/contracts.test.ts
```

Expected: execution contract tests fail because the current client calls `/api/execution/...` and reads `.data`.

- [ ] **Step 4: Write a backend execution response characterization test**

Create `backend/tests/test_execution.py`:

```python
import pytest

from app.models.execution import ExecutionLog


@pytest.mark.asyncio
async def test_execution_logs_and_tables_contract(client, db_session):
    db_session.add(
        ExecutionLog(
            id="log-1",
            connection_id="conn-1",
            table_name="customers",
            step_type="schema_discovery",
            step_label="发现字段",
            status="completed",
            output_summary="ok",
            duration_ms=10,
        )
    )
    await db_session.commit()

    logs = await client.get("/api/execution/conn-1", params={"table_name": "customers"})
    assert logs.status_code == 200
    assert logs.json()[0]["connection_id"] == "conn-1"
    assert logs.json()[0]["table_name"] == "customers"
    assert logs.json()[0]["status"] == "completed"

    tables = await client.get("/api/execution/conn-1/tables")
    assert tables.status_code == 200
    assert tables.json() == {"tables": ["customers"]}
```

- [ ] **Step 5: Run the backend characterization test**

Run:

```bash
cd /Users/Apple/codes/data-label/backend
pytest tests/test_execution.py -q
```

Expected: `1 passed`.

- [ ] **Step 6: Normalize the frontend clients**

Replace `resetConfig()` in `frontend/src/lib/api/agent.ts` with:

```typescript
async resetConfig(): Promise<AgentConfig> {
  return api.post('/agent/config/reset') as Promise<AgentConfig>;
},
```

Replace the methods in `frontend/src/lib/api/execution.ts` with:

```typescript
async getLogs(connectionId: string, tableName?: string): Promise<ExecutionStep[]> {
  const params = tableName ? { table_name: tableName } : {};
  return api.get('/execution/' + connectionId, { params }) as Promise<ExecutionStep[]>;
},

async getTables(connectionId: string): Promise<string[]> {
  const payload = await api.get('/execution/' + connectionId + '/tables') as { tables: string[] };
  return payload.tables;
},
```

- [ ] **Step 7: Run focused and build verification**

Run:

```bash
cd /Users/Apple/codes/data-label/frontend
npm test -- src/lib/api/__tests__/contracts.test.ts
npm run build
```

Expected: contract tests pass; build still fails only on the remaining route/UI TypeScript errors handled in Task 2.

- [ ] **Step 8: Commit only Task 1 files**

```bash
cd /Users/Apple/codes/data-label
git add frontend/package.json frontend/package-lock.json frontend/src/lib/api/__tests__/contracts.test.ts frontend/src/lib/api/agent.ts frontend/src/lib/api/execution.ts backend/tests/test_execution.py
git diff --cached --check
git diff --cached --stat
git commit -m "test: lock frontend API client contracts"
```

## Task 2: Make Frontend Routing Unique and Restore a Green Build

**Files:**
- Create: `frontend/src/App.test.tsx`
- Modify: `frontend/src/App.tsx`
- Modify: `frontend/src/components/discovery/SignalsSegmentsView.tsx`
- Modify: `frontend/src/pages/DataGovernanceCenter.tsx`
- Modify: `frontend/src/pages/TagMarket.tsx`

- [ ] **Step 1: Write a failing route uniqueness test**

Create `frontend/src/App.test.tsx`:

```tsx
import { describe, expect, it } from 'vitest';

import { APP_ROUTES } from './App';

describe('application routes', () => {
  it('registers each path exactly once', () => {
    const paths = APP_ROUTES.map((route) => route.path);
    expect(new Set(paths).size).toBe(paths.length);
  });

  it('uses the data governance center for /governance', () => {
    expect(APP_ROUTES.find((route) => route.path === '/governance')?.id)
      .toBe('data-governance-center');
  });
});
```

- [ ] **Step 2: Run the route test and confirm it fails**

Run:

```bash
cd /Users/Apple/codes/data-label/frontend
npm test -- src/App.test.tsx
```

Expected: FAIL because `APP_ROUTES` is not exported.

- [ ] **Step 3: Replace inline routes with one exported registry**

In `frontend/src/App.tsx`, remove the unused `DataAssets` lazy import and add this registry after `PageLoader`:

```tsx
export const APP_ROUTES = [
  { id: 'dashboard', path: '/', element: <Dashboard /> },
  { id: 'connections', path: '/connections', element: <Connections /> },
  { id: 'annotations', path: '/annotations', element: <Annotations /> },
  { id: 'discovery', path: '/discovery', element: <BusinessDiscovery /> },
  { id: 'tags', path: '/tags', element: <TagManagement /> },
  { id: 'skills', path: '/skills', element: <SkillsManager /> },
  { id: 'memory', path: '/memory', element: <MemoryBrowser /> },
  { id: 'llm-config', path: '/llm-config', element: <LlmConfig /> },
  { id: 'audit', path: '/audit', element: <AuditLog /> },
  { id: 'agent', path: '/agent', element: <AgentProfile /> },
  { id: 'studio', path: '/studio', element: <DataAgentStudio /> },
  { id: 'tag-development', path: '/tags/development', element: <TagDevelopment /> },
  { id: 'tag-market', path: '/tags/market', element: <TagMarket /> },
  { id: 'tag-analysis', path: '/tags/analysis', element: <TagAnalysis /> },
  { id: 'knowledge', path: '/knowledge', element: <KnowledgeManagement /> },
  { id: 'data-governance-center', path: '/governance', element: <DataGovernanceCenter /> },
] as const;
```

Replace the inline `<Route>` list with:

```tsx
{APP_ROUTES.map((route) => (
  <Route key={route.id} path={route.path} element={route.element} />
))}
```

- [ ] **Step 4: Fix the remaining four TypeScript errors**

In `frontend/src/components/discovery/SignalsSegmentsView.tsx`, compute the optional count once before the JSX:

```tsx
const totalOpportunities = segments?.summary.total_opportunities ?? 0;
```

Use it in both places:

```tsx
color: totalOpportunities > 0 ? 'warning.main' : 'text.primary'
```

```tsx
{totalOpportunities}
```

In `frontend/src/pages/DataGovernanceCenter.tsx`, correct the type import:

```tsx
import type { Connection } from '../types/connection';
```

In `frontend/src/pages/TagMarket.tsx`, stop extending the API DTO with an `icon` property:

```tsx
tagApi.getMarket().then((data) => {
  if (data.length > 0) {
    const catNames = [...new Set(data.map((tag) => tag.category))];
    setCategories(['全部', ...catNames]);
    setTags(data);
  }
}).catch(() => {}).finally(() => setLoading(false));
```

Render the icon from the category:

```tsx
{getTagIcon(tag.category)}
```

- [ ] **Step 5: Run route tests, all frontend tests, and build**

Run:

```bash
cd /Users/Apple/codes/data-label/frontend
npm test -- src/App.test.tsx
npm test
npm run build
```

Expected: all tests pass and Vite produces `dist/` without TypeScript errors.

- [ ] **Step 6: Commit only Task 2 files**

```bash
cd /Users/Apple/codes/data-label
git add frontend/src/App.test.tsx frontend/src/App.tsx frontend/src/components/discovery/SignalsSegmentsView.tsx frontend/src/pages/DataGovernanceCenter.tsx frontend/src/pages/TagMarket.tsx
git diff --cached --check
git diff --cached --stat
git commit -m "fix: restore unique routes and frontend build"
```

## Task 3: Restore Real Tag Definition CRUD Contracts

**Files:**
- Create: `backend/tests/test_tags.py`
- Modify: `backend/app/schemas/tag.py`
- Modify: `backend/app/routers/tags.py`

- [ ] **Step 1: Write failing tag-definition API tests**

Create `backend/tests/test_tags.py`:

```python
import pytest


async def create_category(client, name="客户属性"):
    response = await client.post("/api/tags/categories", json={"name": name})
    assert response.status_code == 201
    return response.json()


@pytest.mark.asyncio
async def test_tag_definition_crud(client):
    category = await create_category(client)

    created = await client.post(
        "/api/tags/definitions",
        json={
            "category_id": category["id"],
            "value": "高净值客户",
            "description": "日均资产达到阈值",
            "color": "#1565c0",
        },
    )
    assert created.status_code == 201
    tag = created.json()
    assert tag["value"] == "高净值客户"
    assert tag["is_active"] is True

    listed = await client.get("/api/tags/definitions", params={"category_id": category["id"]})
    assert listed.status_code == 200
    assert [item["id"] for item in listed.json()] == [tag["id"]]

    updated = await client.put(
        f"/api/tags/definitions/{tag['id']}",
        json={"description": "已审核口径", "is_active": False},
    )
    assert updated.status_code == 200
    assert updated.json()["description"] == "已审核口径"
    assert updated.json()["is_active"] is False

    deleted = await client.delete(f"/api/tags/definitions/{tag['id']}")
    assert deleted.status_code == 200
    assert deleted.json() == {"message": "deleted"}

    missing = await client.put(f"/api/tags/definitions/{tag['id']}", json={"value": "不存在"})
    assert missing.status_code == 404


@pytest.mark.asyncio
async def test_tag_definition_rejects_unknown_category(client):
    response = await client.post(
        "/api/tags/definitions",
        json={"category_id": "missing", "value": "测试标签"},
    )
    assert response.status_code == 404


@pytest.mark.asyncio
async def test_tag_definition_rejects_duplicate_in_same_category(client):
    category = await create_category(client)
    payload = {"category_id": category["id"], "value": "高净值客户"}

    assert (await client.post("/api/tags/definitions", json=payload)).status_code == 201
    duplicate = await client.post("/api/tags/definitions", json=payload)

    assert duplicate.status_code == 409
```

- [ ] **Step 2: Run the tests and confirm CRUD is missing**

Run:

```bash
cd /Users/Apple/codes/data-label/backend
pytest tests/test_tags.py -q
```

Expected: FAIL because `POST /api/tags/definitions` returns `405 Method Not Allowed`.

- [ ] **Step 3: Define tag update and response schemas**

Replace `backend/app/schemas/tag.py` with:

```python
from datetime import datetime

from pydantic import BaseModel, ConfigDict


class TagCategoryCreate(BaseModel):
    name: str
    is_system: bool = False


class TagDefinitionCreate(BaseModel):
    category_id: str
    value: str
    description: str | None = None
    color: str = "#666666"


class TagDefinitionUpdate(BaseModel):
    category_id: str | None = None
    value: str | None = None
    description: str | None = None
    color: str | None = None
    is_active: bool | None = None


class TagDefinitionResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    category_id: str
    value: str
    description: str | None
    color: str
    is_active: bool
    created_at: datetime
```

- [ ] **Step 4: Implement definition CRUD in the existing tag router**

Update the schema import in `backend/app/routers/tags.py`:

```python
from app.schemas.tag import (
    TagCategoryCreate,
    TagDefinitionCreate,
    TagDefinitionResponse,
    TagDefinitionUpdate,
)
```

Replace the current definition-list endpoint and add the missing endpoints:

```python
@router.get("/definitions", response_model=list[TagDefinitionResponse])
async def list_definitions(category_id: str | None = None, db: AsyncSession = Depends(get_db)):
    stmt = select(TagDefinition).order_by(TagDefinition.value)
    if category_id:
        stmt = stmt.where(TagDefinition.category_id == category_id)
    result = await db.execute(stmt)
    return result.scalars().all()


@router.post("/definitions", response_model=TagDefinitionResponse, status_code=201)
async def create_definition(data: TagDefinitionCreate, db: AsyncSession = Depends(get_db)):
    if not await db.get(TagCategory, data.category_id):
        raise HTTPException(status_code=404, detail="Category not found")
    existing = (
        await db.execute(
            select(TagDefinition).where(
                TagDefinition.category_id == data.category_id,
                TagDefinition.value == data.value,
            )
        )
    ).scalar_one_or_none()
    if existing:
        raise HTTPException(status_code=409, detail="Tag definition already exists")

    definition = TagDefinition(**data.model_dump())
    db.add(definition)
    await db.commit()
    await db.refresh(definition)
    return definition


@router.put("/definitions/{definition_id}", response_model=TagDefinitionResponse)
async def update_definition(
    definition_id: str,
    data: TagDefinitionUpdate,
    db: AsyncSession = Depends(get_db),
):
    definition = await db.get(TagDefinition, definition_id)
    if not definition:
        raise HTTPException(status_code=404, detail="Tag definition not found")

    updates = data.model_dump(exclude_unset=True)
    target_category = updates.get("category_id", definition.category_id)
    target_value = updates.get("value", definition.value)
    if not await db.get(TagCategory, target_category):
        raise HTTPException(status_code=404, detail="Category not found")

    duplicate = (
        await db.execute(
            select(TagDefinition).where(
                TagDefinition.category_id == target_category,
                TagDefinition.value == target_value,
            )
        )
    ).scalar_one_or_none()
    if duplicate and duplicate.id != definition_id:
        raise HTTPException(status_code=409, detail="Tag definition already exists")

    for field, value in updates.items():
        setattr(definition, field, value)
    await db.commit()
    await db.refresh(definition)
    return definition


@router.delete("/definitions/{definition_id}")
async def delete_definition(definition_id: str, db: AsyncSession = Depends(get_db)):
    definition = await db.get(TagDefinition, definition_id)
    if not definition:
        raise HTTPException(status_code=404, detail="Tag definition not found")
    await db.delete(definition)
    await db.commit()
    return {"message": "deleted"}
```

- [ ] **Step 5: Run focused and full backend tests**

Run:

```bash
cd /Users/Apple/codes/data-label/backend
pytest tests/test_tags.py -q
pytest -q
```

Expected: tag tests pass; full backend suite remains green.

- [ ] **Step 6: Commit only Task 3 files**

```bash
cd /Users/Apple/codes/data-label
git add backend/tests/test_tags.py backend/app/schemas/tag.py backend/app/routers/tags.py
git diff --cached --check
git diff --cached --stat
git commit -m "feat: restore tag definition CRUD contracts"
```

## Task 4: Make Chat Action a Backend-Owned Response Contract

**Files:**
- Create: `backend/app/schemas/chat.py`
- Create: `backend/tests/test_chat_actions.py`
- Modify: `backend/app/routers/agent_chat.py`
- Modify: `backend/app/routers/studio_chat.py`
- Create: `frontend/src/types/chat.ts`
- Modify: `frontend/src/lib/api/chat.ts`
- Modify: `frontend/src/lib/api/studio.ts`
- Modify: `frontend/src/pages/DataAgentStudio.tsx`

- [ ] **Step 1: Write failing backend Chat Action pass-through tests**

Create `backend/tests/test_chat_actions.py`:

```python
import pytest

from app.routers import agent_chat, studio_chat


ACTION = {
    "id": "action-1",
    "type": "search_tags",
    "title": "标签搜索",
    "data": {"keyword": "留学", "total": 0, "tags": []},
    "status": "READY",
    "risk_level": "LOW",
    "request_id": "request-1",
    "actor_id": None,
    "idempotency_key": None,
    "next_step": None,
}


async def fake_agent(*args, **kwargs):
    return {
        "reply": "完成",
        "suggestions": ["查看标签市场"],
        "mode": "react",
        "steps": [],
        "action": ACTION,
    }


@pytest.mark.asyncio
async def test_agent_chat_preserves_backend_action(client, monkeypatch):
    monkeypatch.setattr(agent_chat, "run_react_agent", fake_agent)

    response = await client.post("/api/agent/chat", json={"message": "搜索标签 留学"})

    assert response.status_code == 200
    assert response.json()["action"] == ACTION


@pytest.mark.asyncio
async def test_studio_chat_preserves_backend_action(client, monkeypatch):
    monkeypatch.setattr(studio_chat, "run_react_agent", fake_agent)

    response = await client.post("/api/studio/chat", json={"message": "搜索标签 留学"})

    assert response.status_code == 200
    assert response.json()["action"] == ACTION
```

- [ ] **Step 2: Run the tests and confirm both response models drop the action**

Run:

```bash
cd /Users/Apple/codes/data-label/backend
pytest tests/test_chat_actions.py -q
```

Expected: FAIL because the JSON responses do not contain `action`.

- [ ] **Step 3: Add the shared backend Chat Action schema**

Create `backend/app/schemas/chat.py`:

```python
from typing import Any

from pydantic import BaseModel, Field


class ChatAction(BaseModel):
    id: str | None = None
    type: str
    title: str
    data: dict[str, Any] = Field(default_factory=dict)
    status: str = "READY"
    risk_level: str = "LOW"
    request_id: str | None = None
    actor_id: str | None = None
    idempotency_key: str | None = None
    next_step: str | None = None
```

In both `backend/app/routers/agent_chat.py` and `backend/app/routers/studio_chat.py`:

```python
from app.schemas.chat import ChatAction
```

Add this field to `ChatResponse` and `StudioChatResponse`:

```python
action: ChatAction | None = None
```

Pass the backend agent result through when constructing each response:

```python
action=result.get("action"),
```

Do not infer an action from reply text in either router. Real action producers belong to the later customer-opportunity implementation.

- [ ] **Step 4: Run backend Chat Action tests**

Run:

```bash
cd /Users/Apple/codes/data-label/backend
pytest tests/test_chat_actions.py -q
```

Expected: `2 passed`.

- [ ] **Step 5: Align frontend Chat Action types**

Create `frontend/src/types/chat.ts`:

```typescript
import type { ActionType } from '../contexts/ChatActionContext';

export interface BackendChatAction {
  id?: string;
  type: ActionType;
  title: string;
  data: Record<string, unknown>;
  status: string;
  risk_level: string;
  request_id?: string | null;
  actor_id?: string | null;
  idempotency_key?: string | null;
  next_step?: string | null;
}
```

In `frontend/src/lib/api/chat.ts`, remove the local `ChatAction` interface and use:

```typescript
import type { BackendChatAction } from '../../types/chat';
```

```typescript
action?: BackendChatAction;
```

In `frontend/src/lib/api/studio.ts`, add:

```typescript
import type { BackendChatAction } from '../../types/chat';
```

Replace its inline action type with:

```typescript
action?: BackendChatAction;
```

- [ ] **Step 6: Remove frontend reply-text action synthesis**

In `frontend/src/pages/DataAgentStudio.tsx`, replace the action branch in `handleSend` with:

```tsx
if (response.action) {
  pushAction({
    type: response.action.type,
    title: response.action.title,
    data: response.action.data,
  });
}
```

Delete `ACTION_TITLES` and `detectActionFromReply`. Keep the current Chat and Canvas rendering behavior unchanged for backend-produced actions.

- [ ] **Step 7: Run all Chat, frontend, and backend verification**

Run:

```bash
cd /Users/Apple/codes/data-label/backend
pytest tests/test_chat_actions.py -q
pytest -q

cd /Users/Apple/codes/data-label/frontend
npm test
npm run build
```

Expected: all commands pass.

- [ ] **Step 8: Commit only Task 4 files**

```bash
cd /Users/Apple/codes/data-label
git add backend/app/schemas/chat.py backend/tests/test_chat_actions.py backend/app/routers/agent_chat.py backend/app/routers/studio_chat.py frontend/src/types/chat.ts frontend/src/lib/api/chat.ts frontend/src/lib/api/studio.ts frontend/src/pages/DataAgentStudio.tsx
git diff --cached --check
git diff --cached --stat
git commit -m "feat: make Chat Action a backend response contract"
```

## Task 5: Standardize Request IDs and Error Responses

**Files:**
- Create: `backend/app/schemas/api.py`
- Create: `backend/tests/test_api_contracts.py`
- Modify: `backend/app/main.py`
- Modify: `frontend/src/lib/api.ts`

- [ ] **Step 1: Write failing request-ID and error-envelope tests**

Create `backend/tests/test_api_contracts.py`:

```python
import pytest


@pytest.mark.asyncio
async def test_http_error_uses_shared_envelope_and_request_id(client):
    response = await client.get(
        "/api/connections/missing",
        headers={"X-Request-ID": "request-123"},
    )

    assert response.status_code == 404
    assert response.headers["X-Request-ID"] == "request-123"
    assert response.json() == {
        "code": "http_404",
        "message": "Connection not found",
        "details": None,
        "request_id": "request-123",
    }


@pytest.mark.asyncio
async def test_validation_error_uses_shared_envelope(client):
    response = await client.post(
        "/api/connections",
        json={"name": "Broken", "port": {"invalid": True}},
    )

    assert response.status_code == 422
    payload = response.json()
    assert payload["code"] == "validation_error"
    assert payload["message"] == "Request validation failed"
    assert isinstance(payload["details"], list)
    assert payload["request_id"] == response.headers["X-Request-ID"]
```

- [ ] **Step 2: Run the tests and confirm FastAPI still returns the default error shape**

Run:

```bash
cd /Users/Apple/codes/data-label/backend
pytest tests/test_api_contracts.py -q
```

Expected: FAIL because errors currently use `{"detail": ...}` and no `X-Request-ID` header.

- [ ] **Step 3: Add the shared error schema**

Create `backend/app/schemas/api.py`:

```python
from typing import Any

from pydantic import BaseModel


class ErrorResponse(BaseModel):
    code: str
    message: str
    details: Any | None = None
    request_id: str
```

- [ ] **Step 4: Add request-ID middleware and exception handlers**

Add these imports to `backend/app/main.py`:

```python
from uuid import uuid4

from fastapi import FastAPI, HTTPException, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse

from app.schemas.api import ErrorResponse
```

After CORS middleware registration, add:

```python
@app.middleware("http")
async def attach_request_id(request: Request, call_next):
    request_id = request.headers.get("X-Request-ID") or str(uuid4())
    request.state.request_id = request_id
    response = await call_next(request)
    response.headers["X-Request-ID"] = request_id
    return response


@app.exception_handler(HTTPException)
async def handle_http_exception(request: Request, exc: HTTPException):
    request_id = request.state.request_id
    payload = ErrorResponse(
        code=f"http_{exc.status_code}",
        message=str(exc.detail),
        request_id=request_id,
    )
    return JSONResponse(
        status_code=exc.status_code,
        content=payload.model_dump(mode="json"),
        headers={"X-Request-ID": request_id},
    )


@app.exception_handler(RequestValidationError)
async def handle_validation_exception(request: Request, exc: RequestValidationError):
    request_id = request.state.request_id
    payload = ErrorResponse(
        code="validation_error",
        message="Request validation failed",
        details=exc.errors(),
        request_id=request_id,
    )
    return JSONResponse(
        status_code=422,
        content=payload.model_dump(mode="json"),
        headers={"X-Request-ID": request_id},
    )
```

- [ ] **Step 5: Make the frontend error interceptor consume both contracts during transition**

Replace the error branch in `frontend/src/lib/api.ts` with:

```typescript
(err) => {
  const payload = err.response?.data;
  const msg = payload?.message || payload?.detail || err.message;
  const error = new Error(msg) as Error & { code?: string; requestId?: string };
  error.code = payload?.code;
  error.requestId = payload?.request_id || err.response?.headers?.['x-request-id'];
  console.error('[API Error]', msg, error.requestId || '');
  return Promise.reject(error);
}
```

- [ ] **Step 6: Run focused and full verification**

Run:

```bash
cd /Users/Apple/codes/data-label/backend
pytest tests/test_api_contracts.py -q
pytest -q

cd /Users/Apple/codes/data-label/frontend
npm test
npm run build
```

Expected: all commands pass.

- [ ] **Step 7: Commit only Task 5 files**

```bash
cd /Users/Apple/codes/data-label
git add backend/app/schemas/api.py backend/tests/test_api_contracts.py backend/app/main.py frontend/src/lib/api.ts
git diff --cached --check
git diff --cached --stat
git commit -m "feat: standardize API request and error contracts"
```

## Task 6: Make Runtime Dependencies and Configuration Reproducible

**Files:**
- Create: `backend/tests/test_runtime_dependencies.py`
- Modify: `backend/requirements.txt`
- Modify: `backend/.env.example`
- Modify: `README.md`
- Modify: `docs/deployment-guide.md`

- [ ] **Step 1: Write the runtime dependency smoke test**

Create `backend/tests/test_runtime_dependencies.py`:

```python
import importlib

import pytest


@pytest.mark.parametrize(
    "module_name",
    [
        "langchain_openai",
        "langgraph",
        "multipart",
        "openpyxl",
        "pymysql",
    ],
)
def test_runtime_dependency_is_importable(module_name):
    importlib.import_module(module_name)
```

- [ ] **Step 2: Run the smoke test and confirm the missing MySQL driver**

Run:

```bash
cd /Users/Apple/codes/data-label/backend
pytest tests/test_runtime_dependencies.py -q
```

Expected: FAIL for `pymysql`; the other imported runtime packages pass in the current environment.

- [ ] **Step 3: Align runtime dependency declarations**

Update `backend/requirements.txt` so these entries are present and compatible with the runtime code:

```text
pydantic>=2.7,<3
pydantic-settings>=2.2,<3
openai>=2,<3
langchain-openai>=1.2,<2
langgraph>=1.2,<2
openpyxl>=3.1,<4
python-multipart>=0.0.20,<1
PyMySQL>=1.1,<2
```

Remove the older exact `pydantic`, `pydantic-settings`, and `openai` lines before adding these ranges. Keep the remaining existing dependencies.

- [ ] **Step 4: Verify the dependency file can create a coherent environment**

Run:

```bash
cd /Users/Apple/codes/data-label/backend
python -m pip install -r requirements.txt
python -m pip check
pytest tests/test_runtime_dependencies.py -q
```

Expected: `pip check` reports no broken requirements and all dependency smoke tests pass.

- [ ] **Step 5: Document the actual environment contract**

Replace `backend/.env.example` with:

```env
DATABASE_URL=sqlite+aiosqlite:///./data_label.db
DATABASE_URL_SYNC=sqlite+pysqlite:///./data_label_sync.db
ENCRYPTION_KEY=change-me-in-production
DEMO_MODE=true
LLM={"deepseek":{"api_key":"","base_url":"https://api.deepseek.com/v1"}}
```

In `README.md` and `docs/deployment-guide.md`, replace references to `LLM_PROVIDERS` and `LLM_STRATEGY` with:

```env
DEMO_MODE=true
LLM={"deepseek":{"api_key":"...","base_url":"https://api.deepseek.com/v1"}}
```

Document these exact rules:

- `DEMO_MODE=true` uses seeded demo data and the LLM-free demo agent.
- `DEMO_MODE=false` enables real Agent execution.
- Supported provider keys are `deepseek` and `copilot`.
- DeepSeek accepts `api_key` and optional `base_url`.
- Copilot accepts `token`.
- No key should be committed to the repository.

- [ ] **Step 6: Run backend tests and documentation consistency search**

Run:

```bash
cd /Users/Apple/codes/data-label/backend
pytest -q

cd /Users/Apple/codes/data-label
rg -n "LLM_PROVIDERS|LLM_STRATEGY|claude|openai" README.md docs/deployment-guide.md backend/.env.example
```

Expected: backend tests pass; the search returns no stale provider configuration instructions.

- [ ] **Step 7: Commit only Task 5 files**

```bash
cd /Users/Apple/codes/data-label
git add backend/tests/test_runtime_dependencies.py backend/requirements.txt backend/.env.example README.md docs/deployment-guide.md
git diff --cached --check
git diff --cached --stat
git commit -m "chore: align runtime dependencies and configuration"
```

## Task 7: Verify Stage 0 Exit Criteria

**Files:**
- No new files.
- Only fix defects directly revealed by the verification commands, and add the matching regression test before each fix.

- [ ] **Step 1: Run the complete backend suite**

```bash
cd /Users/Apple/codes/data-label/backend
pytest -q
```

Expected: all tests pass.

- [ ] **Step 2: Run the complete frontend suite and production build**

```bash
cd /Users/Apple/codes/data-label/frontend
npm test
npm run build
```

Expected: all tests pass and the production build completes.

- [ ] **Step 3: Verify API routes and OpenAPI generation**

Run:

```bash
cd /Users/Apple/codes/data-label/backend
python -c "from app.main import app; schema=app.openapi(); assert '/api/tags/definitions' in schema['paths']; assert '/api/agent/chat' in schema['paths']; assert '/api/studio/chat' in schema['paths']; print('OpenAPI contracts present')"
```

Expected: prints `OpenAPI contracts present`.

- [ ] **Step 4: Verify repository hygiene**

Run:

```bash
cd /Users/Apple/codes/data-label
git diff --check
git status --short
```

Expected: no whitespace errors. Existing unrelated worktree changes remain untouched.

- [ ] **Step 5: Record Stage 0 completion**

Update the execution checklist in this plan only after every exit criterion passes:

- Frontend TypeScript and Vite build are green.
- Frontend API client and route contracts have automated tests.
- Tag definition create/read/update/delete endpoints are implemented and tested.
- Execution-log API behavior is characterized and the frontend client matches it.
- Both chat endpoints preserve optional backend-produced Chat Actions.
- Frontend no longer invents Chat Actions from reply text.
- HTTP and validation errors include a request ID and shared error envelope.
- Runtime imports are declared and `pip check` is clean.

Commit any verification-driven regression fix separately with its test. Do not create an empty completion commit.

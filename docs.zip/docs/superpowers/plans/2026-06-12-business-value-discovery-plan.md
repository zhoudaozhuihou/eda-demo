# Business Value Discovery Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Transform Business Discovery page from technical metadata display into a business value platform focused on Customer 360 insights, covering data map, segment analysis, and cross-sell discovery.

**Architecture:** Backend business logic layer (`business_discovery.py`) that queries annotated data (domain=客户信息 tables, columns, relationships) and returns structured business insights. Frontend splits into 3 self-contained components (CustomerDataMap, CustomerInsights, ProductAffinity) integrated into the existing BusinessDiscovery page.

**Tech Stack:** Python FastAPI + SQLAlchemy async (backend), React + MUI + TypeScript (frontend)

---

## File Structure

| File | Action | Responsibility |
|------|--------|---------------|
| `backend/app/agent/business_discovery.py` | Create | Core business logic: customer profile field classification, completeness scoring, value tier detection, product affinity analysis |
| `backend/app/routers/discovery.py` | Modify | Add 3 new endpoints: customer-data-map, customer-insights, product-affinity |
| `frontend/src/types/discovery.ts` | Modify | Add CustomerDataMapResponse, CustomerInsight, ProductAffinity types |
| `frontend/src/lib/api/discovery.ts` | Modify | Add getCustomerDataMap, getCustomerInsights, getProductAffinity API calls |
| `frontend/src/components/discovery/CustomerDataMap.tsx` | Create | Phase 1: Customer data map with overview metrics, table cards grid, completeness matrix |
| `frontend/src/components/discovery/CustomerInsights.tsx` | Create | Phase 2: Profile coverage radar, value tier analysis, suggestions |
| `frontend/src/components/discovery/ProductAffinity.tsx` | Create | Phase 3: Product table relations, cross-sell opportunities, data gap alerts |
| `frontend/src/pages/BusinessDiscovery.tsx` | Modify | Add tab navigation (Overview / Customer Map / Insights / Cross-Sell) and integrate new components |

---

### Task 1: Backend business logic module

**Files:**
- Create: `backend/app/agent/business_discovery.py`

This module contains all business-level analysis logic, separate from the router layer.

```python
import re
from sqlalchemy import select, func, and_, or_
from sqlalchemy.ext.asyncio import AsyncSession
from app.models.table import DiscoveredTable
from app.models.column import DiscoveredColumn
from app.models.annotation import Annotation

# Profile dimension patterns for completeness matrix
PROFILE_DIMENSIONS = {
    "基本信息": r"\b(name|gender|sex|age|birth|birthday|national|marital|occupation)\b",
    "联系方式": r"\b(phone|mobile|tel|email|mail|address|addr|wechat|contact)\b",
    "身份认证": r"\b(id_card|passport|ssn|id_no|identity|certificate|id_type|cert_no)\b",
    "风险画像": r"\b(income|salary|credit|risk|tier|score|rating|level|grade)\b",
    "产品持有": r"\b(product|account|holding|balance|asset|portfolio|deposit|loan)\b",
}

# Product type patterns for cross-sell analysis
PRODUCT_CATEGORIES = {
    "贷款产品": r"\b(loan|mortgage|credit|debit|overdraft)\b",
    "存款产品": r"\b(deposit|saving|current|fixed|time)\b",
    "投资产品": r"\b(wealth|fund|investment|portfolio|finance|treasury)\b",
    "保险产品": r"\b(insurance|policy|coverage|premium|assure)\b",
    "卡产品": r"\b(card|credit_card|debit_card)\b",
}

# Value tier field patterns
VALUE_TIER_PATTERNS = {
    "收入": r"\b(income|salary|wage|compensation|earnings)\b",
    "信用": r"\b(credit|credit_score|credit_rating|risk_score)\b",
    "客户等级": r"\b(tier|customer_tier|vip|vip_level|segment_class)\b",
    "资产": r"\b(balance|asset|asset_amount|net_worth|wealth)\b",
    "渗透度": r"\b(product_count|holding_count|products_held|tenure)\b",
}

# Relationship inference field pairs
RELATIONSHIP_FIELD_PAIRS = [
    ("customer_id", "cust_id", "user_id"),
    ("user_id", "customer_id", "cust_id"),
    ("cust_id", "customer_id", "user_id"),
]


def _match_dimensions(column_name: str) -> list[str]:
    """Match a column name against profile dimensions."""
    name_lower = column_name.lower().replace("_", " ").replace("-", " ")
    matches = []
    for dimension, pattern in PROFILE_DIMENSIONS.items():
        if re.search(pattern, name_lower):
            matches.append(dimension)
    return matches


def _match_product_category(column_name: str) -> list[str]:
    """Match a column name against product categories."""
    name_lower = column_name.lower().replace("_", " ").replace("-", " ")
    matches = []
    for category, pattern in PRODUCT_CATEGORIES.items():
        if re.search(pattern, name_lower):
            matches.append(category)
    return matches


def _match_value_tier(column_name: str) -> list[str]:
    """Match a column name against value tier dimensions."""
    name_lower = column_name.lower().replace("_", " ").replace("-", " ")
    matches = []
    for dimension, pattern in VALUE_TIER_PATTERNS.items():
        if re.search(pattern, name_lower):
            matches.append(dimension)
    return matches


async def get_customer_tables(db: AsyncSession) -> list[dict]:
    """Get all tables annotated as domain=客户信息 with their columns and annotations."""
    # Find tables with customer-related annotations
    cust_table_ids = (
        await db.execute(
            select(DiscoveredTable.id)
            .join(Annotation, Annotation.target_id == DiscoveredTable.id)
            .where(
                Annotation.tag_category == "domain",
                Annotation.tag_value == "客户信息",
                Annotation.target_type == "table",
            )
        )
    ).scalars().all()

    # Also find tables whose name matches customer patterns
    name_match_ids = (
        await db.execute(
            select(DiscoveredTable.id).where(
                or_(
                    DiscoveredTable.table_name.ilike("%cust%"),
                    DiscoveredTable.table_name.ilike("%client%"),
                    DiscoveredTable.table_name.ilike("%consumer%"),
                    DiscoveredTable.table_name.ilike("%member%"),
                    DiscoveredTable.table_name.ilike("%user%profile%"),
                    DiscoveredTable.table_name.ilike("%customer%"),
                )
            )
        )
    ).scalars().all()

    all_ids = list(set(list(cust_table_ids) + list(name_match_ids)))
    if not all_ids:
        return []

    tables_result = await db.execute(
        select(DiscoveredTable).where(DiscoveredTable.id.in_(all_ids))
    )
    tables = tables_result.scalars().all()

    result = []
    for table in tables:
        cols_result = await db.execute(
            select(DiscoveredColumn).where(DiscoveredColumn.table_id == table.id)
        )
        columns = cols_result.scalars().all()

        # Get table-level annotations
        ann_result = await db.execute(
            select(Annotation).where(
                Annotation.target_type == "table",
                Annotation.target_id == table.id,
            )
        )
        annotations = ann_result.scalars().all()

        # Get column annotation counts
        col_ids = [c.id for c in columns]
        pii_count = 0
        if col_ids:
            pii_count = (
                await db.execute(
                    select(func.count(Annotation.id)).where(
                        Annotation.target_id.in_(col_ids),
                        Annotation.tag_category == "sensitivity",
                        Annotation.tag_value == "PII",
                    )
                )
            ).scalar() or 0

        # Match columns to profile dimensions
        dimension_map: dict[str, int] = {}
        matched_columns = 0
        for col in columns:
            dims = _match_dimensions(col.column_name)
            if dims:
                matched_columns += 1
                for d in dims:
                    dimension_map[d] = dimension_map.get(d, 0) + 1

        # Calculate completeness
        completeness = matched_columns / len(columns) if columns else 0

        # Get quality tag
        quality_tag = "未知"
        for ann in annotations:
            if ann.tag_category == "quality":
                quality_tag = ann.tag_value
                break

        # Find related tables (by same column names)
        related = await _find_related_tables(db, table, all_ids, columns)

        result.append({
            "id": table.id,
            "name": table.table_name,
            "comment": table.table_comment or "",
            "column_count": len(columns),
            "quality": quality_tag,
            "completeness": round(completeness, 2),
            "pii_count": pii_count,
            "status": table.scan_status,
            "related_tables": related,
            "dimension_coverage": dimension_map,
            "all_dimensions": list(PROFILE_DIMENSIONS.keys()),
        })

    return result


async def _find_related_tables(
    db: AsyncSession, table, all_ids: list[str], columns: list
) -> list[dict]:
    """Find tables related to this one through shared column names."""
    if not all_ids:
        return []
    col_names = [c.column_name.lower() for c in columns]
    if not col_names:
        return []

    related = []
    other_result = await db.execute(
        select(DiscoveredTable).where(
            DiscoveredTable.id.in_(all_ids),
            DiscoveredTable.id != table.id,
        )
    )
    other_tables = other_result.scalars().all()

    for ot in other_tables:
        ot_cols = await db.execute(
            select(DiscoveredColumn).where(DiscoveredColumn.table_id == ot.id)
        )
        ot_col_names = [c.column_name.lower() for c in ot_cols.scalars().all()]
        shared = [n for n in col_names if n in ot_col_names and any(
            pair for pair in ["customer_id", "user_id", "cust_id", "id", "customer"]
            if pair in n
        )]
        if shared:
            related.append({
                "table_name": ot.table_name,
                "via_fields": shared[:3],
            })

    return related


async def get_customer_insights(db: AsyncSession, tables: list[dict]) -> list[dict]:
    """Generate per-table customer insights."""
    insights = []
    for table in tables:
        # Coverage per dimension
        coverage = {}
        for dim in PROFILE_DIMENSIONS:
            coverage[dim] = table["dimension_coverage"].get(dim, 0) / max(table["column_count"], 1)

        # Value tier analysis
        tier_fields = []
        # We need to re-query columns for value tier matching
        cols_result = await db.execute(
            select(DiscoveredColumn).where(
                DiscoveredColumn.table_id == table["id"]
            )
        )
        columns = cols_result.scalars().all()
        for col in columns:
            tiers = _match_value_tier(col.column_name)
            if tiers:
                tier_fields.append({"field": col.column_name, "dimensions": tiers})

        # Generate suggestions
        suggestions = []
        missing_dims = [d for d in PROFILE_DIMENSIONS if coverage.get(d, 0) == 0]
        if missing_dims:
            suggestions.append(f"缺少{', '.join(missing_dims)}相关字段，建议补充以完善客户画像")
        if table["pii_count"] > 0:
            suggestions.append(f"含{table['pii_count']}个PII字段，需确保合规处理")
        if table["completeness"] < 0.5:
            suggestions.append("画像完整度较低，建议补充更多客户属性字段")

        # Build summary
        covered_dims = [d for d in PROFILE_DIMENSIONS if coverage.get(d, 0) > 0]
        summary = (
            f"{table['name']} — {table['comment'] or '未标注'}: "
            f"含{table['column_count']}个字段，覆盖{len(covered_dims)}/{len(PROFILE_DIMENSIONS)}个画像维度"
        )
        if table["pii_count"] > 0:
            summary += f"，{table['pii_count']}个PII字段"
        summary += f"，数据质量{table['quality']}"

        insights.append({
            "table_name": table["name"],
            "comment": table["comment"],
            "field_count": table["column_count"],
            "profile_coverage": {k: round(v, 2) for k, v in coverage.items()},
            "coverage_score": round(sum(coverage.values()) / max(len(coverage), 1), 2),
            "value_tier_fields": tier_fields,
            "value_tier_completeness": len(tier_fields),
            "pii_count": table["pii_count"],
            "suggestions": suggestions,
            "summary": summary,
        })

    return insights


async def get_product_affinity(db: AsyncSession) -> dict:
    """Analyze product-related tables and cross-sell opportunities."""
    # Find product-related tables
    prod_result = await db.execute(
        select(DiscoveredTable).where(
            DiscoveredTable.table_name.ilike("%product%"),
        )
    )
    product_tables_raw = prod_result.scalars().all()

    # Also check annotations for product domain
    prod_from_ann = (
        await db.execute(
            select(DiscoveredTable.id)
            .join(Annotation, Annotation.target_id == DiscoveredTable.id)
            .where(
                Annotation.tag_category == "domain",
                Annotation.tag_value == "产品信息",
            )
        )
    ).scalars().all()

    # Find customer tables (from domain annotation or name match)
    cust_result = await db.execute(
        select(DiscoveredTable).where(
            or_(
                DiscoveredTable.table_name.ilike("%cust%"),
                DiscoveredTable.table_name.ilike("%consumer%"),
                DiscoveredTable.table_name.ilike("%customer%"),
                DiscoveredTable.table_name.ilike("%member%"),
            )
        )
    )
    customer_tables_raw = cust_result.scalars().all()

    # Analyze product table fields
    product_tables = []
    for pt in product_tables_raw:
        cols_result = await db.execute(
            select(DiscoveredColumn).where(DiscoveredColumn.table_id == pt.id)
        )
        cols = cols_result.scalars().all()
        product_fields = []
        categories_found = set()
        for col in cols:
            cats = _match_product_category(col.column_name)
            if cats:
                product_fields.append({"field": col.column_name, "categories": cats})
                categories_found.update(cats)

        product_tables.append({
            "name": pt.table_name,
            "comment": pt.table_comment or "",
            "product_fields": [pf["field"] for pf in product_fields],
            "categories": list(categories_found),
        })

    # Analyze relationships between product and customer tables
    relations = []
    for ct in customer_tables_raw:
        ct_cols = await db.execute(
            select(DiscoveredColumn).where(DiscoveredColumn.table_id == ct.id)
        )
        ct_col_names = [c.column_name.lower() for c in ct_cols.scalars().all()]

        for pt in product_tables_raw:
            pt_cols = await db.execute(
                select(DiscoveredColumn).where(DiscoveredColumn.table_id == pt.id)
            )
            pt_col_names = [c.column_name.lower() for c in pt_cols.scalars().all()]

            # Find shared fields
            shared = set(ct_col_names) & set(pt_col_names)
            relation_fields = [s for s in shared if any(
                pair in s for pair in ["id", "key", "code", "no", "num"]
            )]
            if relation_fields:
                relations.append({
                    "from_table": ct.table_name,
                    "to_table": pt.table_name,
                    "via_fields": list(relation_fields)[:3],
                    "confidence": "high" if len(relation_fields) > 1 else "medium",
                })

    # Generate cross-sell opportunities
    opportunities = []
    # If customer tables exist with shared fields to product tables, suggest
    product_table_names = {pt.table_name for pt in product_tables_raw}
    customer_table_names = {ct.table_name for ct in customer_tables_raw}
    if relations:
        for rel in relations:
            opportunities.append({
                "customer_table": rel["from_table"],
                "product_table": rel["to_table"],
                "opportunity": f"客户表'{rel['from_table']}'与产品表'{rel['to_table']}'通过{', '.join(rel['via_fields'])}关联，可分析产品交叉持有",
                "confidence": rel["confidence"],
            })
    elif customer_table_names and product_table_names:
        for ct_name in list(customer_table_names)[:3]:
            for pt_name in list(product_table_names)[:3]:
                opportunities.append({
                    "customer_table": ct_name,
                    "product_table": pt_name,
                    "opportunity": f"发现潜在关联：{ct_name} ↔ {pt_name}，需确认关联字段",
                    "confidence": "low",
                })

    # Product field categories summary
    field_categories = []
    for cat_name, _ in PRODUCT_CATEGORIES.items():
        field_categories.append({"category": cat_name})

    return {
        "product_tables": product_tables,
        "customer_table_relations": relations,
        "cross_sell_opportunities": opportunities,
        "product_field_categories": field_categories,
    }
```

- [ ] **Step 1: Write the module**

Write the above content to `backend/app/agent/business_discovery.py`.

- [ ] **Step 2: Verify it imports correctly**

```bash
cd backend
python3 -c "from app.agent.business_discovery import get_customer_tables, get_customer_insights, get_product_affinity; print('OK')"
```

Expected: `OK`

---

### Task 2: Backend API endpoints

**Files:**
- Modify: `backend/app/routers/discovery.py`

Add 3 new endpoints after the existing `get_discovery_summary` function. The router already imports `Annotation`, `DiscoveredTable`, `DiscoveredColumn`, `Connection` from models.

- [ ] **Step 1: Add import for business_discovery module**

```python
from app.agent.business_discovery import (
    get_customer_tables,
    get_customer_insights,
    get_product_affinity,
)
```

Add this import at the top of `discovery.py`, after the existing imports.

- [ ] **Step 2: Add customer-data-map endpoint**

```python
@router.get("/customer-data-map")
async def customer_data_map(db: AsyncSession = Depends(get_db)):
    """Phase 1: Customer data map with completeness matrix."""
    tables = await get_customer_tables(db)
    if not tables:
        return {"tables": [], "summary": _empty_customer_summary()}

    total_columns = sum(t["column_count"] for t in tables)
    total_pii = sum(t["pii_count"] for t in tables)
    avg_completeness = round(
        sum(t["completeness"] for t in tables) / len(tables), 2
    ) if tables else 0

    return {
        "tables": tables,
        "summary": {
            "total_customer_tables": len(tables),
            "total_customer_columns": total_columns,
            "pii_fields": total_pii,
            "avg_completeness": avg_completeness,
        },
    }


def _empty_customer_summary() -> dict:
    return {
        "total_customer_tables": 0,
        "total_customer_columns": 0,
        "pii_fields": 0,
        "avg_completeness": 0,
    }
```

Add these before the `get_customer_segments` endpoint.

- [ ] **Step 3: Add customer-insights endpoint**

```python
@router.get("/customer-insights")
async def customer_insights(db: AsyncSession = Depends(get_db)):
    """Phase 2: Per-table customer profile analysis."""
    tables = await get_customer_tables(db)
    if not tables:
        return []
    insights = await get_customer_insights(db, tables)
    return insights
```

- [ ] **Step 4: Add product-affinity endpoint**

```python
@router.get("/product-affinity")
async def product_affinity(db: AsyncSession = Depends(get_db)):
    """Phase 3: Cross-sell and product affinity analysis."""
    result = await get_product_affinity(db)
    return result
```

- [ ] **Step 5: Test the endpoints**

Wait for uvicorn --reload to pick up changes, then test:

```bash
curl -s http://localhost:8000/api/discovery/customer-data-map | python3 -m json.tool | head -30
curl -s http://localhost:8000/api/discovery/customer-insights | python3 -m json.tool | head -20
curl -s http://localhost:8000/api/discovery/product-affinity | python3 -m json.tool | head -30
```

Expected: Each returns JSON arrays/objects with the defined structure (may be empty if no customer tables annotated yet).

---

### Task 3: Frontend types and API client

**Files:**
- Modify: `frontend/src/types/discovery.ts`
- Modify: `frontend/src/lib/api/discovery.ts`

- [ ] **Step 1: Add types to discovery.ts**

Append to the end of `frontend/src/types/discovery.ts`:

```typescript
export interface CustomerTableInfo {
  id: string;
  name: string;
  comment: string;
  column_count: number;
  quality: string;
  completeness: number;
  pii_count: number;
  status: string;
  related_tables: { table_name: string; via_fields: string[] }[];
  dimension_coverage: Record<string, number>;
  all_dimensions: string[];
}

export interface CustomerDataMapResponse {
  tables: CustomerTableInfo[];
  summary: {
    total_customer_tables: number;
    total_customer_columns: number;
    pii_fields: number;
    avg_completeness: number;
  };
}

export interface ValueTierField {
  field: string;
  dimensions: string[];
}

export interface CustomerInsight {
  table_name: string;
  comment: string;
  field_count: number;
  profile_coverage: Record<string, number>;
  coverage_score: number;
  value_tier_fields: ValueTierField[];
  value_tier_completeness: number;
  pii_count: number;
  suggestions: string[];
  summary: string;
}

export interface ProductTable {
  name: string;
  comment: string;
  product_fields: string[];
  categories: string[];
}

export interface TableRelation {
  from_table: string;
  to_table: string;
  via_fields: string[];
  confidence: string;
}

export interface CrossSellOpportunity {
  customer_table: string;
  product_table: string;
  opportunity: string;
  confidence: string;
}

export interface ProductAffinityResponse {
  product_tables: ProductTable[];
  customer_table_relations: TableRelation[];
  cross_sell_opportunities: CrossSellOpportunity[];
  product_field_categories: { category: string }[];
}
```

- [ ] **Step 2: Add API calls to discovery.ts**

```typescript
import type {
  CustomerDataMapResponse, CustomerInsight, ProductAffinityResponse,
} from '../../types/discovery';

export const discoveryApi = {
  // Existing methods...
  getSummary: () => api.get<any, DiscoverySummary>('/discovery/summary'),
  getInsights: () => api.get<any, Insight[]>('/discovery/insights'),
  getCustomerSegments: () => api.get<any, CustomerSegment>('/discovery/customer-segments'),
  getAgentAlerts: () => api.get<any, AgentAlert[]>('/discovery/agent-alerts'),
  // New methods:
  getCustomerDataMap: () => api.get<any, CustomerDataMapResponse>('/discovery/customer-data-map'),
  getCustomerInsights: () => api.get<any, CustomerInsight[]>('/discovery/customer-insights'),
  getProductAffinity: () => api.get<any, ProductAffinityResponse>('/discovery/product-affinity'),
};
```

---

### Task 4: CustomerDataMap component (Phase 1)

**Files:**
- Create: `frontend/src/components/discovery/CustomerDataMap.tsx`

- [ ] **Step 1: Create CustomerDataMap component**

```tsx
import { Box, Typography, Grid, Paper, Chip, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, LinearProgress, Tooltip } from '@mui/material';
import { Storage, TableChart, ViewColumn, CheckCircle, Warning, ErrorOutline } from '@mui/icons-material';
import type { CustomerTableInfo, CustomerDataMapResponse } from '../../types/discovery';

function TableCard({ table }: { table: CustomerTableInfo }) {
  const qualityColor = table.quality === '高' ? 'success' : table.quality === '中' ? 'warning' : 'error';
  const completePct = Math.round(table.completeness * 100);

  return (
    <Paper variant="outlined" sx={{ p: 2.5, borderRadius: 2, transition: 'all 0.2s ease', '&:hover': { boxShadow: '0 4px 12px rgba(0,0,0,0.06)' } }}>
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 1.5 }}>
        <Storage sx={{ color: 'primary.main', fontSize: 20 }} />
        <Typography variant="subtitle2" sx={{ fontWeight: 600, fontFamily: '"IBM Plex Mono", monospace' }}>{table.name}</Typography>
        <Chip label={table.quality} size="small" color={qualityColor} variant="outlined" />
        <Chip label={table.status} size="small" variant="outlined" sx={{ ml: 'auto' }} />
      </Box>
      {table.comment && <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 1.5 }}>{table.comment}</Typography>}
      <Box sx={{ display: 'flex', gap: 1.5, mb: 1.5, flexWrap: 'wrap' }}>
        <Chip icon={<ViewColumn sx={{ fontSize: 14 }} />} label={`${table.column_count} 字段`} size="small" variant="outlined" />
        {table.pii_count > 0 && <Chip icon={<Warning sx={{ fontSize: 14 }} />} label={`${table.pii_count} PII`} size="small" color="warning" variant="outlined" />}
        {table.related_tables.length > 0 && (
          <Tooltip title={table.related_tables.map(r => `${r.table_name}(${r.via_fields.join(',')})`).join('\n')}>
            <Chip label={`关联 ${table.related_tables.length} 张表`} size="small" color="primary" variant="outlined" />
          </Tooltip>
        )}
      </Box>
      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
        <Box sx={{ flex: 1 }}>
          <LinearProgress variant="determinate" value={completePct} sx={{ height: 6, borderRadius: 3 }} />
        </Box>
        <Typography variant="caption" sx={{ fontWeight: 500, minWidth: 36, textAlign: 'right' }}>{completePct}%</Typography>
      </Box>
      <Typography variant="caption" color="text.secondary">画像完整度</Typography>
    </Paper>
  );
}

interface Props {
  data: CustomerDataMapResponse | null;
  loading: boolean;
}

export default function CustomerDataMap({ data, loading }: Props) {
  if (loading) {
    return <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>{[1, 2, 3].map(i => <Box key={i} className="skeleton-shimmer" sx={{ height: 120, borderRadius: 2 }} />)}</Box>;
  }
  if (!data || data.tables.length === 0) {
    return (
      <Paper variant="outlined" sx={{ p: 6, textAlign: 'center', borderRadius: 2 }}>
        <Storage sx={{ fontSize: 48, color: 'text.disabled', mb: 2 }} />
        <Typography color="text.secondary">尚未发现客户数据表</Typography>
        <Typography variant="caption" color="text.disabled">请先运行数据源标注，标注 domain=客户信息 的表将自动出现在这里</Typography>
      </Paper>
    );
  }

  const { summary, tables } = data;
  const allDims = tables.length > 0 ? tables[0].all_dimensions : [];

  return (
    <Box>
      {/* Summary metrics */}
      <Grid container spacing={2} sx={{ mb: 3 }}>
        <Grid size={{ xs: 6, md: 3 }}>
          <Paper variant="outlined" sx={{ p: 2, borderRadius: 2, textAlign: 'center' }}>
            <Typography variant="h5" sx={{ fontWeight: 700, color: 'primary.main' }}>{summary.total_customer_tables}</Typography>
            <Typography variant="caption" color="text.secondary">客户表</Typography>
          </Paper>
        </Grid>
        <Grid size={{ xs: 6, md: 3 }}>
          <Paper variant="outlined" sx={{ p: 2, borderRadius: 2, textAlign: 'center' }}>
            <Typography variant="h5" sx={{ fontWeight: 700, color: 'success.main' }}>{summary.total_customer_columns}</Typography>
            <Typography variant="caption" color="text.secondary">字段总数</Typography>
          </Paper>
        </Grid>
        <Grid size={{ xs: 6, md: 3 }}>
          <Paper variant="outlined" sx={{ p: 2, borderRadius: 2, textAlign: 'center' }}>
            <Typography variant="h5" sx={{ fontWeight: 700, color: summary.pii_fields > 0 ? 'warning.main' : 'text.primary' }}>{summary.pii_fields}</Typography>
            <Typography variant="caption" color="text.secondary">PII 字段</Typography>
          </Paper>
        </Grid>
        <Grid size={{ xs: 6, md: 3 }}>
          <Paper variant="outlined" sx={{ p: 2, borderRadius: 2, textAlign: 'center' }}>
            <Typography variant="h5" sx={{ fontWeight: 700, color: summary.avg_completeness >= 0.5 ? 'success.main' : 'warning.main' }}>{(summary.avg_completeness * 100).toFixed(0)}%</Typography>
            <Typography variant="caption" color="text.secondary">平均完整度</Typography>
          </Paper>
        </Grid>
      </Grid>

      {/* Table cards */}
      <Typography variant="h6" sx={{ fontWeight: 600, mb: 2 }}>客户数据表</Typography>
      <Grid container spacing={2} sx={{ mb: 4 }}>
        {tables.map((t) => (
          <Grid size={{ xs: 12, md: 6, lg: 4 }} key={t.id}>
            <TableCard table={t} />
          </Grid>
        ))}
      </Grid>

      {/* Completeness matrix */}
      {allDims.length > 0 && (
        <Box>
          <Typography variant="h6" sx={{ fontWeight: 600, mb: 2 }}>画像维度完整性矩阵</Typography>
          <TableContainer component={Paper} variant="outlined" sx={{ borderRadius: 2 }}>
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell sx={{ fontWeight: 600 }}>维度</TableCell>
                  {tables.map((t) => (
                    <TableCell key={t.id} align="center" sx={{ fontFamily: '"IBM Plex Mono", monospace', fontSize: '0.75rem' }}>{t.name}</TableCell>
                  ))}
                </TableRow>
              </TableHead>
              <TableBody>
                {allDims.map((dim) => (
                  <TableRow key={dim}>
                    <TableCell sx={{ fontWeight: 500 }}>{dim}</TableCell>
                    {tables.map((t) => {
                      const count = t.dimension_coverage[dim] || 0;
                      const hasField = count > 0;
                      return (
                        <TableCell key={t.id} align="center">
                          {hasField ? (
                            <Tooltip title={`${count} 个字段`}>
                              <CheckCircle sx={{ fontSize: 20, color: 'success.main' }} />
                            </Tooltip>
                          ) : (
                            <Tooltip title="无匹配字段">
                              <ErrorOutline sx={{ fontSize: 20, color: 'text.disabled' }} />
                            </Tooltip>
                          )}
                        </TableCell>
                      );
                    })}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </Box>
      )}
    </Box>
  );
}
```

---

### Task 5: CustomerInsights component (Phase 2)

**Files:**
- Create: `frontend/src/components/discovery/CustomerInsights.tsx`

- [ ] **Step 1: Create CustomerInsights component**

```tsx
import { Box, Typography, Grid, Paper, Chip, Alert, Tooltip } from '@mui/material';
import { InsightsOutlined, Lightbulb, Warning } from '@mui/icons-material';
import type { CustomerInsight } from '../../types/discovery';

function RadarShape({ coverage }: { coverage: Record<string, number> }) {
  const entries = Object.entries(coverage);
  const size = 160;
  const cx = size / 2;
  const cy = size / 2;
  const r = 60;
  const angleStep = (2 * Math.PI) / entries.length;

  const gridPoints = entries.map((_, i) => {
    const a = angleStep * i - Math.PI / 2;
    return `${cx + r * Math.cos(a)},${cy + r * Math.sin(a)}`;
  }).join(' ');

  const dataPoints = entries.map(([_, v], i) => {
    const a = angleStep * i - Math.PI / 2;
    const vr = r * v;
    return `${cx + vr * Math.cos(a)},${cy + vr * Math.sin(a)}`;
  }).join(' ');

  const labels = entries.map(([k, v], i) => {
    const a = angleStep * i - Math.PI / 2;
    const lr = r + 18;
    const lx = cx + lr * Math.cos(a);
    const ly = cy + lr * Math.sin(a);
    return { label: k, x: lx, y: ly, value: `${(v * 100).toFixed(0)}%` };
  });

  return (
    <Box sx={{ display: 'flex', justifyContent: 'center', mb: 1 }}>
      <svg width={size + 60} height={size + 40} viewBox={`0 0 ${size + 60} ${size + 40}`}>
        {/* Grid */}
        <polygon points={gridPoints} fill="none" stroke="#e0e0e0" strokeWidth="1" />
        {/* Axis lines */}
        {entries.map((_, i) => {
          const a = angleStep * i - Math.PI / 2;
          return <line key={i} x1={cx} y1={cy} x2={cx + r * Math.cos(a)} y2={cy + r * Math.sin(a)} stroke="#e0e0e0" strokeWidth="1" />;
        })}
        {/* 50% reference */}
        <polygon
          points={entries.map((_, i) => {
            const a = angleStep * i - Math.PI / 2;
            const hr = r * 0.5;
            return `${cx + hr * Math.cos(a)},${cy + hr * Math.sin(a)}`;
          }).join(' ')}
          fill="none" stroke="#e0e0e0" strokeWidth="1" strokeDasharray="3,3"
        />
        {/* Data polygon */}
        <polygon points={dataPoints} fill="rgba(21, 101, 192, 0.15)" stroke="#1565c0" strokeWidth="2" />
        {/* Data points */}
        {entries.map((_, i) => {
          const a = angleStep * i - Math.PI / 2;
          const vr = r * (entries[i][1] || 0);
          return <circle key={i} cx={cx + vr * Math.cos(a)} cy={cy + vr * Math.sin(a)} r="3" fill="#1565c0" />;
        })}
        {/* Labels */}
        {labels.map((l, i) => (
          <text key={i} x={l.x} y={l.y} textAnchor="middle" dominantBaseline="middle" fontSize="11" fill="#666">
            {l.label}
          </text>
        ))}
        {/* Center value */}
        <text x={cx} y={cy + 4} textAnchor="middle" dominantBaseline="middle" fontSize="14" fontWeight="600" fill="#1565c0">
          {entries.length > 0 ? `${(entries.reduce((s, [, v]) => s + v, 0) / entries.length * 100).toFixed(0)}%` : ''}
        </text>
      </svg>
    </Box>
  );
}

interface Props {
  insights: CustomerInsight[];
  loading: boolean;
}

export default function CustomerInsights({ insights, loading }: Props) {
  if (loading) {
    return <Box sx={{ display: 'flex', gap: 2 }}>{[1, 2].map(i => <Box key={i} className="skeleton-shimmer" sx={{ flex: 1, height: 200, borderRadius: 2 }} />)}</Box>;
  }
  if (insights.length === 0) return null;

  return (
    <Box>
      <Typography variant="h6" sx={{ fontWeight: 600, mb: 2 }}>客户画像分析</Typography>
      <Grid container spacing={2.5}>
        {insights.map((insight) => (
          <Grid size={{ xs: 12, md: 6 }} key={insight.table_name}>
            <Paper variant="outlined" sx={{ p: 2.5, borderRadius: 2 }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 2 }}>
                <InsightsOutlined color="primary" />
                <Typography variant="subtitle2" sx={{ fontWeight: 600, fontFamily: '"IBM Plex Mono", monospace' }}>{insight.table_name}</Typography>
                <Chip label={`${insight.field_count} 字段`} size="small" variant="outlined" sx={{ ml: 'auto' }} />
              </Box>
              <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 2 }}>{insight.summary}</Typography>

              <Grid container spacing={2}>
                <Grid size={{ xs: 12, md: 5 }}>
                  <RadarShape coverage={insight.profile_coverage} />
                </Grid>
                <Grid size={{ xs: 12, md: 7 }}>
                  {/* Value tier fields */}
                  {insight.value_tier_fields.length > 0 && (
                    <Box sx={{ mb: 1.5 }}>
                      <Typography variant="caption" sx={{ fontWeight: 600, display: 'block', mb: 0.5 }}>价值分层字段:</Typography>
                      <Box sx={{ display: 'flex', gap: 0.5, flexWrap: 'wrap' }}>
                        {insight.value_tier_fields.map((vtf) => (
                          <Tooltip key={vtf.field} title={vtf.dimensions.join(', ')}>
                            <Chip label={vtf.field} size="small" variant="outlined" color="primary" sx={{ height: 22, fontSize: '0.7rem', fontFamily: '"IBM Plex Mono", monospace' }} />
                          </Tooltip>
                        ))}
                      </Box>
                    </Box>
                  )}
                  {/* Suggestions */}
                  {insight.suggestions.map((s, i) => (
                    <Alert key={i} severity={s.includes('PII') ? 'warning' : 'info'} variant="outlined" sx={{ py: 0.5, px: 1.5, mb: 0.5, fontSize: '0.75rem' }}>
                      {s}
                    </Alert>
                  ))}
                </Grid>
              </Grid>
            </Paper>
          </Grid>
        ))}
      </Grid>
    </Box>
  );
}
```

---

### Task 6: ProductAffinity component (Phase 3)

**Files:**
- Create: `frontend/src/components/discovery/ProductAffinity.tsx`

- [ ] **Step 1: Create ProductAffinity component**

```tsx
import { Box, Typography, Paper, Chip, Alert, Grid } from '@mui/material';
import { AccountTree, Lightbulb, LinkOff } from '@mui/icons-material';
import type { ProductAffinityResponse } from '../../types/discovery';

interface Props {
  data: ProductAffinityResponse | null;
  loading: boolean;
}

export default function ProductAffinity({ data, loading }: Props) {
  if (loading) {
    return <Box sx={{ display: 'flex', gap: 2 }}>{[1, 2].map(i => <Box key={i} className="skeleton-shimmer" sx={{ flex: 1, height: 160, borderRadius: 2 }} />)}</Box>;
  }
  if (!data) return null;

  const hasRelations = data.customer_table_relations.length > 0 || data.cross_sell_opportunities.length > 0;

  return (
    <Box>
      <Typography variant="h6" sx={{ fontWeight: 600, mb: 2 }}>产品关联与交叉销售</Typography>

      {!hasRelations ? (
        <Paper variant="outlined" sx={{ p: 6, textAlign: 'center', borderRadius: 2 }}>
          <AccountTree sx={{ fontSize: 48, color: 'text.disabled', mb: 2 }} />
          <Typography color="text.secondary">未发现产品关联数据</Typography>
          <Typography variant="caption" color="text.disabled">运行标注后，含产品信息的表将自动参与分析</Typography>
        </Paper>
      ) : (
        <Grid container spacing={2.5}>
          {/* Product tables */}
          {data.product_tables.length > 0 && (
            <Grid size={{ xs: 12, md: 6 }}>
              <Paper variant="outlined" sx={{ p: 2.5, borderRadius: 2 }}>
                <Typography variant="subtitle2" sx={{ fontWeight: 600, mb: 1.5 }}>产品相关表</Typography>
                {data.product_tables.map((pt) => (
                  <Box key={pt.name} sx={{ mb: 1.5, pb: 1.5, borderBottom: '1px solid', borderColor: 'divider', '&:last-child': { borderBottom: 0, mb: 0, pb: 0 } }}>
                    <Typography variant="body2" sx={{ fontWeight: 500, fontFamily: '"IBM Plex Mono", monospace', fontSize: '0.8rem' }}>{pt.name}</Typography>
                    <Typography variant="caption" color="text.secondary">{pt.comment}</Typography>
                    <Box sx={{ display: 'flex', gap: 0.5, mt: 0.5, flexWrap: 'wrap' }}>
                      {pt.categories.map((cat) => (
                        <Chip key={cat} label={cat} size="small" color="primary" variant="outlined" sx={{ height: 22, fontSize: '0.7rem' }} />
                      ))}
                    </Box>
                  </Box>
                ))}
              </Paper>
            </Grid>
          )}

          {/* Cross-sell opportunities */}
          {data.cross_sell_opportunities.length > 0 && (
            <Grid size={{ xs: 12, md: 6 }}>
              <Paper variant="outlined" sx={{ p: 2.5, borderRadius: 2 }}>
                <Typography variant="subtitle2" sx={{ fontWeight: 600, mb: 1.5 }}>
                  <Lightbulb sx={{ fontSize: 16, verticalAlign: 'middle', mr: 0.5, color: 'warning.main' }} />
                  交叉销售机会
                </Typography>
                {data.cross_sell_opportunities.map((opp, i) => (
                  <Alert
                    key={i}
                    severity={opp.confidence === 'high' ? 'success' : opp.confidence === 'medium' ? 'info' : 'warning'}
                    variant="outlined"
                    sx={{ mb: 1, py: 1, px: 1.5, '& .MuiAlert-message': { fontSize: '0.8rem' } }}
                  >
                    <Typography variant="caption">{opp.opportunity}</Typography>
                    <Chip label={`${opp.confidence} confidence`} size="small" variant="outlined" sx={{ ml: 1, height: 20, fontSize: '0.65rem' }} />
                  </Alert>
                ))}
              </Paper>
            </Grid>
          )}

          {/* Relations summary */}
          {data.customer_table_relations.length > 0 && (
            <Grid size={12}>
              <Paper variant="outlined" sx={{ p: 2.5, borderRadius: 2 }}>
                <Typography variant="subtitle2" sx={{ fontWeight: 600, mb: 1 }}>
                  <AccountTree sx={{ fontSize: 16, verticalAlign: 'middle', mr: 0.5 }} />
                  客户 ↔ 产品表关系
                </Typography>
                <Box sx={{ display: 'flex', gap: 1, flexWrap: 'wrap' }}>
                  {data.customer_table_relations.map((rel, i) => (
                    <Chip
                      key={i}
                      icon={<LinkOff sx={{ fontSize: 14, transform: 'rotate(45deg)' }} />}
                      label={`${rel.from_table} ↔ ${rel.to_table} (${rel.via_fields.join(', ')})`}
                      size="small"
                      variant="outlined"
                      color={rel.confidence === 'high' ? 'success' : 'default'}
                      sx={{ height: 28, fontSize: '0.75rem', fontFamily: '"IBM Plex Mono", monospace' }}
                    />
                  ))}
                </Box>
              </Paper>
            </Grid>
          )}
        </Grid>
      )}
    </Box>
  );
}
```

---

### Task 7: BusinessDiscovery page integration

**Files:**
- Modify: `frontend/src/pages/BusinessDiscovery.tsx`

- [ ] **Step 1: Rewrite BusinessDiscovery page with tabs and integrated components**

Replace the full file content:

```tsx
import { useState, useEffect } from 'react';
import {
  Box, Typography, Tabs, Tab, Alert, CircularProgress,
} from '@mui/material';
import { InsightsOutlined, MapOutlined, AccountTree, Crosshair } from '@mui/icons-material';
import { discoveryApi } from '../lib/api/discovery';
import InsightCard from '../components/discovery/InsightCard';
import CustomerSegmentView from '../components/discovery/CustomerSegment';
import CustomerDataMap from '../components/discovery/CustomerDataMap';
import CustomerInsights from '../components/discovery/CustomerInsights';
import ProductAffinity from '../components/discovery/ProductAffinity';
import type { Insight, CustomerSegment } from '../types/discovery';
import type { CustomerDataMapResponse, CustomerInsight, ProductAffinityResponse } from '../types/discovery';

type TabKey = 'overview' | 'data-map' | 'insights' | 'cross-sell';

export default function BusinessDiscovery() {
  const [tab, setTab] = useState<TabKey>('overview');
  const [insights, setInsights] = useState<Insight[]>([]);
  const [customerData, setCustomerData] = useState<CustomerSegment | null>(null);
  const [dataMap, setDataMap] = useState<CustomerDataMapResponse | null>(null);
  const [customerInsights, setCustomerInsights] = useState<CustomerInsight[]>([]);
  const [productAffinity, setProductAffinity] = useState<ProductAffinityResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    Promise.all([
      discoveryApi.getInsights(),
      discoveryApi.getCustomerSegments(),
      discoveryApi.getCustomerDataMap(),
      discoveryApi.getCustomerInsights(),
      discoveryApi.getProductAffinity(),
    ]).then(([i, c, dm, ci, pa]) => {
      setInsights(i);
      setCustomerData(c);
      setDataMap(dm);
      setCustomerInsights(ci);
      setProductAffinity(pa);
    }).catch((e) => {
      setError(e.message);
    }).finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <Box>
        <Typography variant="h4" sx={{ fontWeight: 700, mb: 0.5 }}>业务发现</Typography>
        <Box className="flex justify-center py-16"><CircularProgress size={40} /></Box>
      </Box>
    );
  }

  const tabs: { key: TabKey; label: string; icon: React.ReactNode }[] = [
    { key: 'overview', label: '总览', icon: <InsightsOutlined /> },
    { key: 'data-map', label: '客户数据地图', icon: <MapOutlined /> },
    { key: 'insights', label: '客户画像分析', icon: <Crosshair /> },
    { key: 'cross-sell', label: '交叉销售', icon: <AccountTree /> },
  ];

  return (
    <Box>
      <Typography variant="h4" sx={{ fontWeight: 700, mb: 0.5 }}>
        业务发现
      </Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
        从数据中发现商业价值 — 客户360洞察
      </Typography>

      {error && <Alert severity="error" sx={{ mb: 2, borderRadius: 1 }}>{error}</Alert>}

      <Tabs
        value={tab}
        onChange={(_, v) => setTab(v)}
        sx={{ mb: 3, borderBottom: 1, borderColor: 'divider' }}
      >
        {tabs.map((t) => (
          <Tab key={t.key} value={t.key} label={t.label} icon={t.icon} iconPosition="start" />
        ))}
      </Tabs>

      {tab === 'overview' && (
        <Box>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2.5, mb: 4 }}>
            {insights.map((insight, i) => (
              <InsightCard key={i} insight={insight} />
            ))}
            {insights.length === 0 && (
              <Box sx={{ textAlign: 'center', py: 12 }}>
                <Typography variant="h6" color="text.secondary">暂无分析数据</Typography>
                <Typography variant="body2" color="text.disabled">请先完成数据源标注</Typography>
              </Box>
            )}
          </Box>
          {customerData && (
            <Box sx={{ mb: 4 }}>
              <Typography variant="h5" sx={{ fontWeight: 600, mb: 2 }}>客户数据域分析</Typography>
              <CustomerSegmentView data={customerData} />
            </Box>
          )}
        </Box>
      )}

      {tab === 'data-map' && (
        <CustomerDataMap data={dataMap} loading={loading} />
      )}

      {tab === 'insights' && (
        <CustomerInsights insights={customerInsights} loading={loading} />
      )}

      {tab === 'cross-sell' && (
        <ProductAffinity data={productAffinity} loading={loading} />
      )}
    </Box>
  );
}
```

- [ ] **Step 2: TypeScript check**

```bash
cd frontend && npx tsc --noEmit
```

Expected: No errors.

---

### Task 8: Integration testing

- [ ] **Step 1: Verify backend endpoints**

```bash
# Customer Data Map
curl -s http://localhost:8000/api/discovery/customer-data-map | python3 -c "import sys,json; d=json.load(sys.stdin); print(f'Tables: {len(d[\"tables\"])}, Summary: {d[\"summary\"]}')"

# Customer Insights
curl -s http://localhost:8000/api/discovery/customer-insights | python3 -c "import sys,json; d=json.load(sys.stdin); print(f'Insights: {len(d)}')"

# Product Affinity
curl -s http://localhost:8000/api/discovery/product-affinity | python3 -c "import sys,json; d=json.load(sys.stdin); print(f'Product tables: {len(d[\"product_tables\"])}, Relations: {len(d[\"customer_table_relations\"])}, Opportunities: {len(d[\"cross_sell_opportunities\"])}')"
```

Expected: All return valid JSON with expected structure.

- [ ] **Step 2: Verify frontend build**

```bash
cd frontend && npx vite build
```

Expected: Build succeeds.

- [ ] **Step 3: Visual check in browser**

Open `http://localhost:5173/discovery` and verify:
- Tab navigation shows 4 tabs: 总览 / 客户数据地图 / 客户画像分析 / 交叉销售
- Customer Data Map tab shows metrics + table cards + completeness matrix
- Customer Insights tab shows radar charts + suggestions
- Cross-sell tab shows product tables + opportunities

---

## Self-Review

**1. Spec coverage:**
- Phase 1 (Customer Data Map): Task 2 (endpoint) + Task 4 (component) ✅
- Phase 2 (Customer Insights): Task 2 (endpoint) + Task 5 (component) ✅
- Phase 3 (Product Affinity): Task 2 (endpoint) + Task 6 (component) ✅
- Completeness matrix with ✅/❌: Task 4 (matrix table) ✅
- Radar chart: Task 5 (SVG radar) ✅
- Cross-sell opportunities: Task 6 (alerts with confidence) ✅
- Empty states: Included in all components ✅
- Error handling: Page shows Alert on API failure ✅

**2. Placeholder scan:** No TBD, TODO, or placeholder patterns found ✅

**3. Type consistency:** 
- `CustomerDataMapResponse.tables` → `CustomerTableInfo[]` matches API return ✅
- `profile_coverage` in both API (`get_customer_insights`) and frontend types (`CustomerInsight`) ✅
- `cross_sell_opportunities` in both backend and frontend ✅
- All component props match their parent's data shape ✅

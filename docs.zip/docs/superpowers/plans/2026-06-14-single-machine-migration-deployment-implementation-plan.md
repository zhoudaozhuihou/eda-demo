# Single-Machine Migration and Deployment Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Produce a repeatable, one-port Linux and Windows Server deployment that safely migrates SQLite and uploaded knowledge files, uses Alembic for schema evolution, remains PostgreSQL-ready, and exposes the existing frontend pages as an embeddable route module.

**Architecture:** Build the React app before packaging and serve its static assets from FastAPI after all API routes. Externalize runtime paths, seed behavior, secrets, and service settings through environment variables; manage schema changes with Alembic; package data with checksums and SQLite integrity validation; use systemd on Linux and WinSW on Windows.

**Tech Stack:** FastAPI, Uvicorn, SQLAlchemy async, Alembic, SQLite, PostgreSQL/asyncpg readiness, React 18, TypeScript, Vite, pytest, shell, PowerShell, systemd, WinSW.

---

## File Structure

- Modify `backend/app/config.py`: absolute runtime paths, static directory, seed mode, and environment validation.
- Modify `backend/app/database.py`: portable engine options and schema management boundary.
- Modify `backend/app/main.py`: readiness endpoint, explicit seed behavior, and SPA static hosting.
- Modify `backend/app/services/document_parser.py`: persistent upload directory from configuration.
- Create `backend/app/runtime.py`: runtime directory validation and readiness checks.
- Create `backend/tests/test_runtime_config.py`: runtime path, seed, readiness, and static hosting tests.
- Create `backend/alembic.ini`, `backend/alembic/env.py`, `backend/alembic/script.py.mako`, and `backend/alembic/versions/0001_current_schema_baseline.py`: schema baseline.
- Create `backend/app/commands/backup.py`, `restore.py`, and `migrate_sqlite_to_postgres.py`: migration commands.
- Create `backend/tests/test_backup_restore.py` and `test_migrations.py`: migration safety tests.
- Modify `backend/app/seed_demo_data.py`: explicit versioned and idempotent demo seeding.
- Create `backend/app/demo/__init__.py` and `backend/app/demo/v1.py`: versioned demo dataset metadata.
- Create `frontend/src/app/DataLabelProviders.tsx`, `DataLabelRoutes.tsx`, and `StandaloneShell.tsx`: shell-independent route module.
- Modify `frontend/src/App.tsx` and `frontend/vite.config.ts`: standalone composition and configurable base.
- Create `scripts/build-release.sh`, `scripts/smoke-test.sh`, and `scripts/smoke-test.ps1`: release and smoke checks.
- Create `deploy/linux/data-label.service`, `deploy/linux/data-label.env.example`, `deploy/windows/data-label-service.xml`, and `deploy/windows/data-label.env.example`: service definitions.
- Create `docs/deployment/single-machine-runbook.md`: installation, migration, rollback, and incident runbook.

### Task 1: Externalize Runtime Paths and Seed Behavior

**Files:**
- Modify: `backend/app/config.py`
- Create: `backend/app/runtime.py`
- Modify: `backend/app/services/document_parser.py`
- Modify: `backend/app/main.py`
- Test: `backend/tests/test_runtime_config.py`

- [ ] **Step 1: Write failing runtime configuration tests**

Test that an isolated `DATA_LABEL_DATA_DIR` creates `uploads`, `backups`, and `logs`; uploaded files use the configured upload directory; invalid unwritable paths fail readiness; and `seed_mode=none` never invokes demo seeding.

- [ ] **Step 2: Run the tests and verify RED**

Run: `cd backend && pytest tests/test_runtime_config.py -v`

Expected: failures because paths are relative, uploads use the temporary directory, and seed mode does not exist.

- [ ] **Step 3: Add the deployment configuration contract**

Add settings for `data_dir`, `upload_dir`, `static_dir`, `seed_mode`, `host`, `port`, and `log_dir`. Resolve default database and upload paths from `data_dir`, while preserving explicit `database_url` overrides.

- [ ] **Step 4: Add runtime validation**

Implement `ensure_runtime_directories()` and `readiness_report()` in `backend/app/runtime.py`. Readiness must verify writable directories, database connectivity, and the current migration revision once Alembic is introduced.

- [ ] **Step 5: Move uploads out of the temporary directory**

Make `save_file()` create and use the configured persistent upload directory. Reject unsafe filenames and store generated unique names while retaining the original filename in the database.

- [ ] **Step 6: Make seed behavior explicit**

Replace automatic demo seeding based only on `demo_mode` with `seed_mode`. `none` and `migrate` must never seed; `demo` may seed only an empty database.

- [ ] **Step 7: Run focused and full tests**

Run:

```bash
cd backend
pytest tests/test_runtime_config.py -v
pytest -q
```

Expected: runtime tests pass and the existing backend suite has no regressions.

### Task 2: Establish Alembic as the Schema Authority

**Files:**
- Create: `backend/alembic.ini`
- Create: `backend/alembic/env.py`
- Create: `backend/alembic/script.py.mako`
- Create: `backend/alembic/versions/0001_current_schema_baseline.py`
- Modify: `backend/app/main.py`
- Test: `backend/tests/test_migrations.py`

- [ ] **Step 1: Write failing migration tests**

Test that `alembic upgrade head` creates a complete empty SQLite schema, that the current application can start against it, and that a second upgrade is idempotent.

- [ ] **Step 2: Run the tests and verify RED**

Run: `cd backend && pytest tests/test_migrations.py -v`

Expected: failure because Alembic configuration and baseline revision do not exist.

- [ ] **Step 3: Create the Alembic environment**

Configure Alembic to import all ORM models, read `settings.database_url`, convert async URLs for migration execution where required, and compare column types and server defaults.

- [ ] **Step 4: Create and review the baseline revision**

Generate the baseline from the current ORM metadata, then manually verify foreign keys, indexes, JSON columns, timestamps, and every current table including `workbench_runs`, chat messages, documents, requirements, and background tasks.

- [ ] **Step 5: Remove production reliance on `create_all()`**

Allow `create_all()` only in tests or an explicit development bootstrap command. Production startup must require the database to be at Alembic head.

- [ ] **Step 6: Mark an existing SQLite database at baseline**

Document and test the controlled `alembic stamp 0001_current_schema_baseline` path for the existing database after verifying its tables match the baseline.

- [ ] **Step 7: Run migration and full tests**

Run:

```bash
cd backend
alembic upgrade head
pytest tests/test_migrations.py -v
pytest -q
```

Expected: migrations and all backend tests pass.

### Task 3: Version Demo Data and Separate It from Business Data

**Files:**
- Create: `backend/app/demo/__init__.py`
- Create: `backend/app/demo/v1.py`
- Modify: `backend/app/seed_demo_data.py`
- Test: `backend/tests/test_demo_seed.py`

- [ ] **Step 1: Write failing seed tests**

Test explicit demo version selection, idempotent reseeding, deterministic entity identifiers, rejection when business data already exists, and no seeding in `none` or `migrate` mode.

- [ ] **Step 2: Run the tests and verify RED**

Run: `cd backend && pytest tests/test_demo_seed.py -v`

Expected: failure because demo version and deterministic identifiers are not recorded.

- [ ] **Step 3: Define demo dataset metadata**

Move demo definitions into `backend/app/demo/v1.py` and expose a version string plus deterministic records. Use stable UUID5 identifiers or stable natural-key lookup.

- [ ] **Step 4: Persist demo dataset version**

Add an Alembic migration for an `application_metadata` table and record the applied demo version. Do not use runtime-only flags as the source of truth.

- [ ] **Step 5: Implement explicit seed command behavior**

Seed only when requested, verify the target database is empty or already contains the same demo version, and fail with an actionable error when business data exists.

- [ ] **Step 6: Run tests**

Run: `cd backend && pytest tests/test_demo_seed.py tests/test_migrations.py -v`

Expected: seed and migration tests pass.

### Task 4: Add Verified SQLite Backup and Restore Bundles

**Files:**
- Create: `backend/app/commands/backup.py`
- Create: `backend/app/commands/restore.py`
- Test: `backend/tests/test_backup_restore.py`

- [ ] **Step 1: Write failing backup and restore tests**

Create a temporary database and upload file, produce a bundle, verify its manifest and checksums, corrupt one file and assert restore rejects it, then restore a valid bundle and verify records plus upload content.

- [ ] **Step 2: Run the tests and verify RED**

Run: `cd backend && pytest tests/test_backup_restore.py -v`

Expected: failure because backup and restore commands do not exist.

- [ ] **Step 3: Implement backup bundle creation**

Use Python's `sqlite3.Connection.backup()` API, copy persistent uploads, write `manifest.json`, calculate SHA-256 checksums, and run `PRAGMA integrity_check` on the produced database.

- [ ] **Step 4: Implement validated restore**

Reject missing files, checksum mismatches, failed integrity checks, incompatible manifest versions, and target directories containing unprotected data. Restore first to a staging directory, then atomically activate it.

- [ ] **Step 5: Add clear command output and exit codes**

Commands must print the bundle path, schema revision, record counts, and validation result without printing secrets or customer content.

- [ ] **Step 6: Run tests**

Run: `cd backend && pytest tests/test_backup_restore.py -v`

Expected: valid round trip passes and corrupted bundles are rejected.

### Task 5: Serve the Production SPA from FastAPI

**Files:**
- Modify: `backend/app/main.py`
- Modify: `frontend/vite.config.ts`
- Test: `backend/tests/test_static_app.py`

- [ ] **Step 1: Write failing static application tests**

Test that `/health` and `/api/*` still resolve to backend routes, `/studio` returns the SPA entry document, static assets return correct content types, and a missing configured static directory produces a clear startup error in production.

- [ ] **Step 2: Run the tests and verify RED**

Run: `cd backend && pytest tests/test_static_app.py -v`

Expected: failure because FastAPI does not serve the built frontend.

- [ ] **Step 3: Add SPA hosting after API routes**

Mount built assets and a final SPA route fallback after all API and health routes. Never allow the SPA fallback to turn missing API endpoints into HTTP 200 HTML responses.

- [ ] **Step 4: Add configurable frontend base**

Read `VITE_APP_BASE` and retain `VITE_API_BASE`, so standalone deployment uses the same origin and target-template deployment may use a path prefix.

- [ ] **Step 5: Build and run tests**

Run:

```bash
cd frontend
npm run build
cd ../backend
pytest tests/test_static_app.py -v
```

Expected: production build succeeds and static routing tests pass.

### Task 6: Extract an Embeddable Frontend Route Module

**Files:**
- Create: `frontend/src/app/DataLabelProviders.tsx`
- Create: `frontend/src/app/DataLabelRoutes.tsx`
- Create: `frontend/src/app/StandaloneShell.tsx`
- Modify: `frontend/src/App.tsx`
- Modify: `frontend/package.json`
- Test: `frontend/src/app/DataLabelRoutes.test.tsx`

- [ ] **Step 1: Add route composition tests**

Test that standalone composition renders the current `AppLayout`, embedded composition renders routes without the current Sidebar, and `/studio`, `/knowledge`, `/tags/market`, `/tags/development`, `/tags/analysis`, `/discovery`, and `/governance` resolve in both modes.

- [ ] **Step 2: Run the tests and verify RED**

Install the compatible test dependencies and add `"test": "vitest run"` to `frontend/package.json`:

```bash
cd frontend
npm install -D vitest@1.6.1 jsdom@24.1.3 @testing-library/react@16.3.0 @testing-library/jest-dom@6.6.3
```

Then run:

```bash
cd frontend
npm run test -- DataLabelRoutes.test.tsx
```

Expected: failure because providers, routes, and shell are coupled in `App.tsx`.

- [ ] **Step 3: Extract providers and routes**

Move theme and shared contexts into `DataLabelProviders`, and move lazy page routes into `DataLabelRoutes`. Keep every page component unchanged.

- [ ] **Step 4: Extract the current shell**

Make `StandaloneShell` own the current `AppLayout` and Sidebar composition. `App.tsx` becomes the standalone assembly of provider, router, shell, and routes.

- [ ] **Step 5: Verify layout preservation**

Build the frontend and compare screenshots of the Workbench, Knowledge Management, Tag Market, Tag Development, Tag Analysis, Business Discovery, and Data Governance pages before and after extraction.

- [ ] **Step 6: Run frontend verification**

Run:

```bash
cd frontend
npm run build
```

Expected: production build passes with no route or TypeScript regressions.

### Task 7: Create Linux and Windows Service Definitions

**Files:**
- Create: `deploy/linux/data-label.service`
- Create: `deploy/linux/data-label.env.example`
- Create: `deploy/windows/data-label-service.xml`
- Create: `deploy/windows/data-label.env.example`
- Create: `scripts/run.py`
- Test: `backend/tests/test_service_config.py`

- [ ] **Step 1: Write service configuration validation tests**

Parse the service templates and assert they call the platform-neutral entrypoint, reference external config and data directories, restart on failure, and do not contain secrets.

- [ ] **Step 2: Run the tests and verify RED**

Run: `cd backend && pytest tests/test_service_config.py -v`

Expected: failure because service definitions do not exist.

- [ ] **Step 3: Implement the platform-neutral startup entrypoint**

Validate configuration, ensure runtime directories, apply Alembic upgrades, validate readiness, and start Uvicorn with configured host and port.

- [ ] **Step 4: Add systemd service**

Run under a dedicated non-login user, load `/etc/data-label/data-label.env`, use `/opt/data-label/current`, restart on failure, and set filesystem protections for config and data.

- [ ] **Step 5: Add WinSW service**

Run the same entrypoint from `C:\DataLabel\current`, load environment configuration, write service logs to `C:\ProgramData\DataLabel\logs`, and restart on failure.

- [ ] **Step 6: Run validation tests**

Run: `cd backend && pytest tests/test_service_config.py -v`

Expected: both service templates pass validation.

### Task 8: Build Release, Smoke Test, and Rollback Tooling

**Files:**
- Create: `scripts/build-release.sh`
- Create: `scripts/smoke-test.sh`
- Create: `scripts/smoke-test.ps1`
- Create: `docs/deployment/single-machine-runbook.md`

- [ ] **Step 1: Implement release build**

Build the frontend, run backend tests, collect backend source and frontend assets, create a dependency lock or wheelhouse reference, calculate checksums, and write `RELEASE_MANIFEST.json`.

- [ ] **Step 2: Implement cross-platform smoke checks**

Check `/health`, readiness, initial SPA load, Studio latest Run, Studio Chat-to-Run flow, knowledge document listing, and database schema revision.

- [ ] **Step 3: Write installation and migration runbook**

Document Linux and Windows prerequisites, release install, environment configuration, new demo install, empty install, existing-data migration, service start, smoke checks, backup, restore, upgrade, and rollback.

- [ ] **Step 4: Execute a local release rehearsal**

Build a release into a temporary directory, restore a copied SQLite bundle, start the packaged service, and run the smoke script.

- [ ] **Step 5: Verify rollback rehearsal**

Stop the rehearsed service, restore the prior database bundle and release pointer, restart, and rerun smoke checks.

Expected: both forward deployment and rollback complete without manual edits to application files.

### Task 9: Add the Controlled PostgreSQL Cutover Command

**Files:**
- Create: `backend/app/commands/migrate_sqlite_to_postgres.py`
- Test: `backend/tests/test_postgres_migration.py`
- Modify: `docs/deployment/single-machine-runbook.md`

- [ ] **Step 1: Write PostgreSQL migration contract tests**

Test deterministic table ordering, dry-run counts, reference validation, batch insertion, and failure rollback. Keep contract tests active in every run, and add a separately marked PostgreSQL integration test that CI runs only when `DATA_LABEL_TEST_POSTGRES_URL` is present.

- [ ] **Step 2: Implement dry-run and reconciliation**

Report source counts, target counts, foreign-key dependencies, incompatible records, and required schema revision without changing the target.

- [ ] **Step 3: Implement controlled transfer**

Transfer domain records in dependency order using SQLAlchemy, commit in bounded batches, preserve identifiers and timestamps, and stop on validation errors.

- [ ] **Step 4: Implement post-transfer reconciliation**

Compare row counts, critical aggregates, and sample identifiers. Emit a machine-readable report and require successful reconciliation before the service URL switches.

- [ ] **Step 5: Document cutover and rollback**

Document write freeze, final backup, ETL, validation, configuration switch, smoke checks, and rollback to SQLite.

- [ ] **Step 6: Run verification**

Run:

```bash
cd backend
pytest tests/test_postgres_migration.py -v
pytest -q
cd ../frontend
npm run build
```

Expected: migration contract, backend suite, and frontend build pass.

### Task 10: Final Security and Operational Review

**Files:**
- Modify: `docs/deployment/single-machine-runbook.md`
- Modify: deployment templates and scripts only if review finds a defect.

- [ ] **Step 1: Scan release contents**

Verify the bundle excludes `.env`, database files, raw uploads, caches, source-control metadata, and secrets.

- [ ] **Step 2: Verify permissions**

Confirm service accounts can read releases, write only runtime directories, and cannot expose config or backup files through static hosting.

- [ ] **Step 3: Verify failure behavior**

Test missing config, incompatible schema revision, corrupt SQLite database, missing upload directory, occupied port, and unavailable database.

- [ ] **Step 4: Run final verification**

Run:

```bash
cd backend
pytest -q
cd ../frontend
npm run build
cd ..
git diff --check
```

Expected: all tests and builds pass, and no whitespace errors remain.

## Self-Review

- Spec coverage: Linux and Windows services, one-port hosting, SQLite migration, upload migration, demo separation, PostgreSQL readiness, target-template integration, rollback, health, and security each have a corresponding task.
- Placeholder scan: the plan contains no deferred implementation placeholders; each task defines exact files, verification commands, and expected behavior.
- Type and boundary consistency: runtime settings, Alembic revision, backup manifest, seed mode, and route-module names are used consistently across tasks.

# 外资银行数据标注 Agent 设计文档

**日期:** 2026-06-10
**版本:** v1.0
**状态:** Draft

---

## 1. 产品概述

外资银行数据标注 Agent 是一个面向数据部门的企业级平台，通过 LLM Agent 自动读取和理解数据源，实现自动化的数据标注（Labeling）与打标签（Tagging），并在此基础上提供业务发现和数据资产发现两大核心价值。

### 1.1 双引擎定位

```
Data Label Agent
├── 业务发现引擎 (Business Discovery)
│   初期数据源: 信用卡数据 + 支付数据
│   输出: 潜力客户、交叉销售机会、流失预警
│   用户: 业务部门（卡中心、市场部）
│
└── 数据资产发现引擎 (Data Platform Discovery)
    接入: 所有已标注的数据源
    输出: 数据盘点、数据质量报告、数据关联发现
    用户: 数据治理团队、CDO 办公室
```

### 1.2 核心原则

- **人工在环 (Human-in-the-Loop):** Agent 提出标注建议，低敏感数据自动生效，PII/合规相关需人工审核
- **渐进式学习:** 人工修正会反馈给 Agent，持续提升标注准确率
- **审计完备:** 所有标注操作均有不可篡改的审计日志
- **供应商中立:** 支持多种 LLM Provider，避免单一锁定

---

## 2. 目标用户

| 用户角色 | 使用场景 | 核心需求 |
|---------|---------|---------|
| 数据管理员 | 管理数据源、审核标注 | 效率、准确性、合规 |
| 数据分析师 | 浏览标注结果、数据资产发现 | 数据可发现性、质量评估 |
| 业务用户(卡中心) | 潜力客户发现、营销线索 |  actionable insights |
| CDO/治理团队 | 数据资产盘点、合规审查 | 全景视图、治理报告 |

---

## 3. 技术栈

| 层 | 技术 | 版本 | 说明 |
|----|------|------|------|
| **后端框架** | Python FastAPI | >=0.110 | REST API + 异步后台任务 |
| **数据库** | PostgreSQL | 16 | 元数据 + 标签 + 审计日志 |
| **向量扩展** | pgvector | - | 语义搜索（标签/相似字段） |
| **数据连接** | SQLAlchemy 2.0 | >=2.0 | PostgreSQL / MySQL / Oracle |
| **数据连接** | pyodbc + ODBC | - | MaxCompute 接入 |
| **数据连接** | google-cloud-bigquery | - | BigQuery 接入 |
| **LLM 多模型** | Claude API / Copilot / OpenAI 兼容 | - | 标注 Agent 核心推理 |
| **LLM 路由** | LLMRouter (自定义) | - | 按策略分发到不同 Provider/Model |
| **任务队列** | FastAPI BackgroundTasks (MVP) | - | 后续可升级为 Celery |
| **前端** | React 18 + Vite | - | SPA |
| **UI 组件** | Material UI v7 | - | 企业级组件库 |
| **CSS** | TailwindCSS | - | 布局 + 微调样式 |
| **HTTP 客户端** | axios | - | API 通信 |
| **部署** | Docker + docker-compose | - | 容器化部署 |

---

## 4. 后端架构

### 4.1 整体架构

```
FastAPI Backend
│
├── API Layer (REST)
│   ├── /api/connections/*     数据源管理
│   ├── /api/annotations/*     标注管理 + 审核
│   ├── /api/tasks/*           异步任务状态
│   ├── /api/discovery/*       业务发现
│   ├── /api/governance/*      数据资产
│   ├── /api/tags/*            标签体系
│   ├── /api/llm/*             LLM 配置
│   └── /api/audit/*           审计日志
│
├── Agent Core
│   ├── Schema Discovery Engine
│   ├── Data Sampling Engine
│   ├── LLM Annotation Engine
│   ├── Rule Engine (Phase 2+)
│   └── Tag Manager
│
├── LLM Layer
│   ├── LLMRouter (策略分发)
│   ├── ClaudeProvider
│   ├── CopilotProvider
│   └── OpenAIProvider
│
├── Data Layer (SQLAlchemy)
│   └── PostgreSQL: connections, tables, columns,
│                   annotations, tags, audit_logs
│
└── Task Queue (BackgroundTasks)
    └── annotation_runner: 异步执行标注任务
```

### 4.2 API 接口设计

| 方法 | 路径 | 描述 |
|------|------|------|
| POST | /api/connections | 创建数据源连接 |
| GET | /api/connections | 列表数据源 |
| GET | /api/connections/{id} | 获取连接详情 |
| PUT | /api/connections/{id} | 更新连接 |
| DELETE | /api/connections/{id} | 删除连接 |
| POST | /api/connections/{id}/test | 测试连接 |
| POST | /api/connections/{id}/scan | 触发全量标注（异步） |
| GET | /api/connections/{id}/tables | 已发现的表列表 |
| GET | /api/tasks/{id} | 查询异步任务进度 |
| GET | /api/annotations | 查询标注（支持过滤） |
| GET | /api/annotations/{table_id} | 表的字段级标注 |
| PUT | /api/annotations/{id}/review | 审核标注 |
| GET | /api/discovered-tags | 新发现的标签 |
| POST | /api/tags/approve | 确认新标签 |
| GET | /api/discovery/insights | 业务发现报告 |
| GET | /api/governance/inventory | 数据资产盘点 |
| GET | /api/governance/quality | 数据质量报告 |
| GET | /api/audit-logs | 审计日志 |
| GET/PUT | /api/llm/providers | LLM Provider 管理 |
| GET/PUT | /api/llm/strategy | 路由策略配置 |

### 4.3 数据库核心模型

```sql
-- 数据源连接
CREATE TABLE connections (
    id UUID PRIMARY KEY,
    name VARCHAR(200),
    db_type VARCHAR(50),        -- postgresql | maxcompute | bigquery | mysql
    host VARCHAR(500),
    port INTEGER,
    database_name VARCHAR(200),
    username VARCHAR(200),
    password_encrypted TEXT,    -- AES 加密存储
    status VARCHAR(20),         -- connected | disconnected | error
    created_at TIMESTAMP,
    updated_at TIMESTAMP
);

-- 发现的表
CREATE TABLE discovered_tables (
    id UUID PRIMARY KEY,
    connection_id UUID REFERENCES connections(id),
    table_name VARCHAR(500),
    table_comment TEXT,
    row_count_estimate BIGINT,
    column_count INTEGER,
    scan_status VARCHAR(20),    -- pending | scanning | completed | failed
    created_at TIMESTAMP
);

-- 发现的字段
CREATE TABLE discovered_columns (
    id UUID PRIMARY KEY,
    table_id UUID REFERENCES discovered_tables(id),
    column_name VARCHAR(500),
    data_type VARCHAR(100),
    is_nullable BOOLEAN,
    is_primary_key BOOLEAN,
    is_foreign_key BOOLEAN,
    sample_values JSONB,        -- 采样值
    null_ratio FLOAT,
    distinct_count INTEGER,
    created_at TIMESTAMP
);

-- 标注记录（核心表）
CREATE TABLE annotations (
    id UUID PRIMARY KEY,
    target_type VARCHAR(10),     -- table | column
    target_id UUID,              -- 指向 discovered_tables 或 discovered_columns
    tag_category VARCHAR(50),    -- sensitivity | domain | quality | compliance | business
    tag_value VARCHAR(200),      -- PII | 客户信息 | ...
    confidence FLOAT,            -- 0.0 - 1.0
    evidence TEXT,               -- 标注推理依据
    source VARCHAR(20),          -- agent | rule | manual
    status VARCHAR(20),          -- suggested | approved | rejected
    created_by VARCHAR(100),
    approved_by VARCHAR(100),
    created_at TIMESTAMP,
    reviewed_at TIMESTAMP
);

-- 标签体系（预设 + 自定义）
CREATE TABLE tag_categories (
    id UUID PRIMARY KEY,
    name VARCHAR(100),           -- sensitivity | domain | quality | ...
    is_system BOOLEAN            -- true=系统预设, false=用户自定义
);

CREATE TABLE tag_definitions (
    id UUID PRIMARY KEY,
    category_id UUID REFERENCES tag_categories(id),
    value VARCHAR(200),
    description TEXT,
    color VARCHAR(7),            -- 展示颜色 #hex
    is_active BOOLEAN
);

-- 审计日志
CREATE TABLE audit_logs (
    id UUID PRIMARY KEY,
    action VARCHAR(50),          -- create | update | approve | reject | delete
    entity_type VARCHAR(50),     -- connection | annotation | tag
    entity_id UUID,
    old_value JSONB,
    new_value JSONB,
    operator VARCHAR(100),
    created_at TIMESTAMP
);
```

---

## 5. Agent 标注引擎

### 5.1 标注工作流

```
用户创建数据源连接
    │
    ▼
POST /api/connections/{id}/scan → 返回 task_id
    │
    ▼ (后台异步执行)
┌──── 标注 Pipeline ──────────────────────────────────┐
│                                                      │
│  Step 1: 测试连接                                     │
│  Step 2: Schema Discovery                            │
│    → 获取所有表名、注释、行数估计                        │
│    → 写入 discovered_tables                          │
│                                                      │
│  Step 3: 逐表分析                                     │
│    ┌─────────────────────────────────────────────┐   │
│    │ 对每张表:                                     │   │
│    │  3a. 获取字段信息 → 写入 discovered_columns   │   │
│    │  3b. 采样数据 (每字段5行 + 统计)               │   │
│    │  3c. LLM 标注 (分批, 每批 ≤ 50字段)           │   │
│    │  3d. 写入 annotations                         │   │
│    └─────────────────────────────────────────────┘   │
│                                                      │
│  Step 4: 标注后处理                                   │
│    → 发现新标签 (不在预设列表中的高频标签)              │
│    → 更新 task 状态为 completed                       │
└──────────────────────────────────────────────────────┘
```

### 5.2 LLM Prompt 模板

```python
# System Prompt (角色定义)
BANK_LABELING_SYSTEM_PROMPT = """
你是一个银行数据标注专家 Agent。

【角色】
- 你是外资银行的数据治理助手，遵循国际银行业数据分类标准
- 标注必须可解释，每一步推理需记录 evidence
- 对不确定的标注（confidence < 0.7），标注为"需人工确认"

【敏感度分级规则】
- 字段名匹配 id_card, passport, ssn, 身份证, 护照 → PII (最高)
- 字段含 name, phone, email, address, 姓名, 电话 → PII
- 字段含 amount, balance, salary, income, 金额, 余额 → Financial
- 其他业务字段 → Internal
- 配置/代码/引用表 → Public

【数据域映射规则】
- 表名含 cust/client/consumer/客户 → 客户信息
- 表名含 tx/trade/transaction/交易 → 交易记录
- 表名含 acct/account/账户 → 账户信息
- 表名含 risk/risk_model/风控 → 风控指标
- 无明确匹配 → 根据字段内容语义推断

【新标签发现】
- 如果数据不属于任何已有标签，可提出新标签值
- 新标签的 confidence 上限为 0.8
- 在 evidence 中明确标注 "新发现" 及理由

【输出格式】
必须输出标准 JSON，不要包含其他文字。
"""

# User Message (每次调用)
SCHEMA_AND_SAMPLE_PROMPT = """
数据源: {connection_name}
表名: {table_name}
表注释: {table_comment}
预估行数: {row_count}

字段信息:
{columns_json}

采样数据 (前{ sample_rows}行):
{sample_rows}

请分析并输出表级标注和字段级标注。
"""
```

### 5.3 Tool Function Calling

```python
# Agent 可调用的工具函数
agent_tools = [
    {
        "name": "get_schema",
        "description": "获取指定表的Schema信息：字段名、类型、主键、外键、注释",
        "parameters": {
            "table_name": {"type": "string", "description": "表名"}
        }
    },
    {
        "name": "sample_data",
        "description": "对指定表采样数据，返回样例行和字段统计信息",
        "parameters": {
            "table_name": {"type": "string", "description": "表名"},
            "row_count": {"type": "integer", "description": "采样行数"},
            "include_stats": {"type": "boolean", "description": "是否包含字段统计"}
        }
    },
    {
        "name": "apply_tags",
        "description": "将标注结果写入标签库",
        "parameters": {
            "table_tags": {"type": "array", "description": "表级标签列表"},
            "column_tags": {"type": "array", "description": "字段级标签列表"}
        }
    },
    {
        "name": "lookup_rules",
        "description": "查询已有标注规则和历史标注",
        "parameters": {
            "pattern": {"type": "string", "description": "表名或字段名模糊匹配"}
        }
    }
]
```

### 5.4 分批标注策略

对于超过 50 个字段的大表，自动分批处理：

| 轮次 | 输入 | 输出 |
|------|------|------|
| 第1轮 | 表名 + 注释 | 表级标签 |
| 第2轮 | 字段 1-50 | 字段级标签 |
| 第3轮 | 字段 51-100 | 字段级标签 |
| ... | ... | ... |
| 最终轮 | 汇总结果 | 一致性检查 → 写入 |

---

## 6. LLM 多模型适配层

### 6.1 Provider 抽象

```python
class LLMProvider(ABC):
    @abstractmethod
    async def chat(self, messages: list, **kwargs) -> LLMResponse: ...
    @abstractmethod
    async def chat_stream(self, messages: list, **kwargs) -> AsyncIterator[str]: ...
    @property
    @abstractmethod
    def models(self) -> list[str]: ...
```

### 6.2 支持的 Provider

| Provider | SDK | 认证方式 | 兼容性 |
|----------|-----|---------|--------|
| Claude (Anthropic) | anthropic Python SDK | API Key | 原生 |
| GitHub Copilot | openai SDK | Personal Token | OpenAI 兼容 |
| OpenAI | openai SDK | API Key | 原生 |
| 阿里云百炼 | openai SDK | API Key | OpenAI 兼容 |
| DeepSeek | openai SDK | API Key | OpenAI 兼容 |
| 自定义 (Custom) | 自定义 | 用户定义 | 接口适配 |

### 6.3 GitHub Copilot 接入

```
Endpoint: https://api.githubcopilot.com/v1/chat/completions
Auth: Bearer token (GitHub PAT with copilot scope)
Models: gpt-4o, gpt-4o-mini, o3-mini, claude-sonnet (取决于订阅)
```

### 6.4 LLMRouter 路由策略

| 策略 | Schema 分析 | 数据采样处理 | 标准标注 | 复杂推理 |
|------|------------|------------|---------|---------|
| cost_first | Haiku/mini | Haiku/mini | Sonnet | Opus |
| quality_first | Sonnet | Sonnet | Opus | Opus |
| balanced | Haiku/mini | Haiku/mini | Sonnet | Opus |
| manual | 用户指定 | 用户指定 | 用户指定 | 用户指定 |

---

## 7. 业务发现引擎

基于已标注的信用卡和支付数据，Agent 自动运行以下分析：

### 7.1 预置分析场景

| 场景 | 输入 | 方法 | 输出 |
|------|------|------|------|
| 高价值潜力客户 | 消费金额 + 还款记录 | 趋势分析 + 阈值判定 | TOP 10% 客户清单 |
| 交叉销售机会 | 产品持有情况 + 消费画像 | 行为模式匹配 | 产品推荐清单 |
| 流失预警 | 消费频次 + 额度使用率 | 下降趋势检测 | 预警客户群 |
| 客户画像聚类 | MCC 码 + 消费时段 + 金额 | 规则聚类 | 客户分群报告 |

### 7.2 约束

- 不得输出 PII 原始值（使用脱敏客户 ID）
- 结果只提供群体分析，不暴露单个客户隐私
- 所有发现结果需要标注置信度

---

## 8. 数据资产发现引擎

### 8.1 发现维度

| 维度 | 方法 | 输出示例 |
|------|------|---------|
| **数据盘点** | 聚合标注结果 | 45张表 / 320字段 / 8个业务域 |
| **敏感数据分布** | 按 PII/Financial 过滤 | 23个PII字段分布在5张表中 |
| **数据质量** | 空值率+格式校验 | phone 空值率35% ⚠️ |
| **数据关联发现** | 字段名+类型相似度匹配 | merchant_id 出现在3张表，建议建外键 |
| **数据价值未释放** | 标注 + 无下游引用 | table_x 有"客户评分"字段但未被模型使用 |
| **冗余数据发现** | 同名表/相似表检测 | 2张表结构相似度 >90%，疑似重复 |

---

## 9. Memory 记忆系统

Agent 不能每次都从零推理，需要持续积累"经验"。

### 9.1 Memory 层次

| 层级 | 存储位置 | 生命周期 | 内容 |
|------|---------|---------|------|
| **工作记忆** | Python 内存 (dict) | 单次标注任务 | 当前表 Schema、采样数据、临时推理 |
| **会话记忆** | PostgreSQL (sessions 表) | 用户会话周期 | 用户的审核记录、手动修正历史 |
| **长期记忆** | PostgreSQL (memory 表) + pgvector | 永久 | 标注模式、用户反馈、经验规则 |
| **知识记忆** | pgvector 向量库 | 永久 (可更新) | 银行业数据分类知识、合规规则 |

### 9.2 长期记忆存储

```sql
CREATE TABLE memory_entries (
    id UUID PRIMARY KEY,
    memory_type VARCHAR(50),     -- pattern | correction | experience | knowledge
    key VARCHAR(500),
    content TEXT,                -- JSON
    embedding vector(1536),      -- pgvector 语义检索
    source VARCHAR(50),          -- agent_learned | user_feedback | admin_defined
    confidence FLOAT,
    hit_count INTEGER DEFAULT 0,
    last_accessed TIMESTAMP,
    created_at TIMESTAMP,
    expires_at TIMESTAMP
);
```

### 9.3 记忆类型

| 类型 | 内容 | 来源 | 用途 |
|------|------|------|------|
| **Pattern Memory** | 高频标注模式（如"字段名含 id_card → PII"） | Agent 自动提取 | 复用高频模式，减少 LLM 调用 |
| **Correction Memory** | 用户修正记录 | 人工审核 | 不再重复相同错误 |
| **Experience Memory** | 标注任务性能经验 | 任务执行后 | 优化分批策略、模型选择 |
| **Knowledge Memory** | 银行业知识、合规规则 | 管理员预置 | 注入领域上下文到 Prompt |

### 9.4 记忆检索流程

```
Agent 标注新字段
    │
    ▼
1. 检索 Pattern Memory → 有历史模式且 confidence > 0.9？
    ├── 是 → 直接复用，无需 LLM
    └── 否 → 进入下一步
    │
    ▼
2. 检索 Correction Memory → 用户纠正过？
    ├── 是 → 参考纠正结果调整 Prompt
    └── 否 → 进入下一步
    │
    ▼
3. 检索 Knowledge Memory → 相关合规规则？
    ├── 是 → 注入 Prompt
    └── 否 → 纯 LLM 推理
    │
    ▼
4. 调用 LLM → 用户审核
    └── 如果被修改 → 写入 Correction Memory
         → 提取 Pattern Memory
```

---

## 10. Skills 技能管理系统

Skills 是 Agent 能力的模块化单元，每个 Skill 封装一个特定的标注/分析能力。

### 10.1 Skill 分类

| 分类 | Skills | 说明 |
|------|--------|------|
| **系统内置** | schema_discovery, data_sampling, pii_detection, domain_classifier, quality_assessment, sensitive_classifier, tag_recommendation | 核心标注能力 |
| **业务** | customer_insight, cross_sell, churn_prediction, merchant_analysis | 业务分析能力 |
| **数据治理** | asset_inventory, data_lineage, redundancy_detection, relationship_discovery | 数据资产管理 |
| **自定义** | 用户上传 | 热加载扩展 |

### 10.2 Skill 目录结构

```
skills/
├── registry.py            # 技能注册中心
├── base.py                # Skill 基类
│
├── builtin/
│   ├── schema_discovery/
│   │   ├── __init__.py
│   │   ├── skill.yaml     # 元数据声明
│   │   └── executor.py    # 执行逻辑
│   ├── pii_detection/
│   │   └── ...
│   └── domain_classifier/
│       └── ...
│
├── business/
│   ├── customer_insight/
│   └── cross_sell/
│
└── custom/                # 用户自定义 (热加载)
```

### 10.3 Skill 元数据 (skill.yaml)

```yaml
name: pii_detection
version: 1.2.0
type: builtin
description: 检测数据中的个人身份信息 (PII)

dependencies:
  - schema_discovery >= 1.0
  - data_sampling >= 1.0

llm_config:
  provider: any
  min_model: sonnet

inputs:
  - name: connection_id
    type: string
  - name: table_name
    type: string
  - name: column_name
    type: string
    optional: true

outputs:
  - name: pii_fields
    type: array
    schema:
      field: string
      pii_type: string
      confidence: float
      evidence: string

configurable:
  thresholds:
    pii_confidence_min:
      type: float
      default: 0.7
```

### 10.4 Skill 执行接口

```python
class BaseSkill(ABC):
    @property
    @abstractmethod
    def metadata(self) -> SkillMetadata: ...

    @abstractmethod
    async def validate(self, context: SkillContext) -> bool: ...

    @abstractmethod
    async def execute(self, context: SkillContext) -> SkillResult: ...

    @abstractmethod
    async def estimate_cost(self, context: SkillContext) -> CostEstimate: ...
```

### 10.5 Skill Pipeline 编排

多个 Skill 可组合为 Pipeline，自动完成复杂标注流程：

```yaml
name: full_annotation_pipeline
steps:
  - skill: schema_discovery
  - skill: data_sampling
    depends_on: [schema_discovery]
  - skill: pii_detection
    depends_on: [data_sampling]
  - skill: domain_classifier
    depends_on: [data_sampling]
  - skill: sensitive_classifier
    depends_on: [pii_detection, domain_classifier]
  - skill: quality_assessment
    depends_on: [data_sampling]
  - skill: tag_recommendation
    depends_on: [pii_detection, domain_classifier, sensitive_classifier, quality_assessment]
```

### 10.6 Skills 与 Memory 联动

```
Skills 执行 → 产出标注结果 → 用户审核
                                ↓
                 如果用户修改 → 写入 Correction Memory
                 如果高频模式 → 提取 Pattern Memory

Skills 执行前 → 检索 Pattern Memory → 命中则跳过 LLM
              → 检索 Knowledge Memory → 注入上下文到 Prompt
```

---

## 11. 前端架构

### 9.1 页面结构

| 路由 | 页面 | 说明 |
|------|------|------|
| / | Dashboard | 仪表盘总体概览 |
| /connections | Connections | 数据源管理 |
| /annotations | AnnotationResult | 标注结果浏览 |
| /annotations/:id | AnnotationDetail | 单表标注详情 |
| /discovery | BusinessDiscovery | 业务发现 |
| /governance | DataAssets | 数据资产 |
| /tags | TagManagement | 标签体系管理 |
| /skills | SkillsManager | 技能管理 + Pipeline 编排 |
| /memory | MemoryBrowser | 记忆检索与浏览 |
| /llm-config | LlmConfig | LLM 配置 |
| /audit | AuditLog | 审计日志 |

### 9.2 组件层级

```
App
└── AppLayout
    ├── Sidebar (导航)
    └── MainContent
        │
        ├── Dashboard
        │   ├── StatCard (x4)
        │   ├── ActivityTimeline
        │   ├── DiscoveryCard
        │   └── RecentScansTable
        │
        ├── Connections
        │   ├── ConnectionCard (列表)
        │   └── ConnectionForm (对话框)
        │
        ├── AnnotationResult
        │   ├── TableTagCard
        │   └── ColumnTagTable
        │       └── TagChip
        │
        ├── BusinessDiscovery
        │   ├── InsightCard
        │   └── CustomerSegmentTable
        │
        └── DataAssets
            ├── InventorySummary
            ├── QualityReport
            └── RelationshipGraph
```

### 9.3 MUI v7 + TailwindCSS 分工

```
MUI v7 → 复杂组件 (数据表格、对话框、表单、Stepper、图表)
Tailwind → 布局、间距、flex/grid、响应式断点、hover/focus 状态

不混用 sx 和 className 做同一件事。
```

### 9.4 axios API 封装

```typescript
// src/lib/api.ts - 全局 axios 实例
const api = axios.create({
  baseURL: import.meta.env.VITE_API_BASE || '/api',
  timeout: 30000,
});

api.interceptors.response.use(
  (res) => res.data,
  (err) => {
    const msg = err.response?.data?.detail || err.message;
    return Promise.reject(new Error(msg));
  }
);

// src/lib/api/connections.ts - 按模块分类
export const connectionApi = {
  list: () => api.get('/connections'),
  get: (id: string) => api.get(`/connections/${id}`),
  create: (data) => api.post('/connections', data),
  test: (id) => api.post(`/connections/${id}/test`),
  scan: (id, opts?) => api.post(`/connections/${id}/scan`, opts),
  delete: (id) => api.delete(`/connections/${id}`),
};
```

---

## 10. 部署架构

```
┌── docker-compose.yml ──────────────────────────┐
│                                                   │
│  services:                                        │
│    postgres:   image: pgvector/pgvector:16        │
│                volumes: postgres_data             │
│                                                   │
│    backend:    build: ./backend                    │
│                env: LLM_PROVIDERS, DATABASE_URL   │
│                depends_on: postgres               │
│                ports: 8000                        │
│                                                   │
│    frontend:   build: ./frontend                   │
│                (Nginx + React build)              │
│                ports: 80                          │
│                depends_on: backend                │
│                                                   │
│  volumes: postgres_data                           │
└───────────────────────────────────────────────────┘

Nginx 配置:
   /api/* → proxy_pass http://backend:8000
   /*     → 静态文件 (React build)
```

---

## 11. 实施计划 (8周)

### Phase 1 - 基础骨架 (Week 1-2)

| 任务 | 产出 |
|------|------|
| 项目初始化 (FastAPI + React + Docker) | 可运行的项目骨架 |
| 数据库 Schema + Migrations | 完整的表结构 |
| 数据源 CRUD API | POST/GET/PUT/DELETE |
| 数据源管理前端页面 | 连接配置表单 + 列表 |
| Schema Discovery 引擎 | 连接数据库并获取表结构 |
| 连接测试 API | 测试连通性 |

### Phase 2 - 核心标注链路 (Week 3-4)

| 任务 | 产出 |
|------|------|
| 数据采样引擎 | 每字段采样 + 统计 |
| LLM Provider 抽象 (Claude/Copilot/OpenAI) | 3个Provider实现 |
| LLMRouter 路由 | 策略分发 |
| 标注 Prompt 工程 | 标注 Agent 核心逻辑 |
| 异步任务系统 | BackgroundTasks |
| 标注入库 API + 前端展示 | 标注结果浏览 |

### Phase 3 - 审核 + 标签体系 + Memory + Skills (Week 5-6)

| 任务 | 产出 |
|------|------|
| 标注审核 API | 通过/驳回/修改 |
| 审核前端界面 | 批量操作 |
| 标签体系管理 | 预设 + 新标签发现 |
| **Memory 系统** | memory_entries 表 + CRUD + 向量检索 |
| **Pattern Memory 提取** | Agent 自动识别高频标注模式 |
| **Correction Memory** | 用户修正自动记录 |
| **Skills 框架** | BaseSkill 基类 + Registry + Pipeline 编排 |
| **系统内置 Skills** | schema_discovery, data_sampling, pii_detection, domain_classifier, quality_assessment |
| Skills 前端管理界面 | 启用/禁用/配置 + Pipeline 创建 |
| Memory 前端浏览页面 | 检索/查看记忆条目 |
| LLM 配置前端页面 | Provider/策略管理 |
| 审计日志 | 所有操作记录 |

### Phase 4 - 业务发现 + 数据资产 (Week 7-8)

| 任务 | 产出 |
|------|------|
| 业务发现 Agent | 3个预置分析场景 |
| 潜力客户发现 | 分析报告 + 前端展示 |
| 数据资产盘点 | 盘点 + 质量报告 |
| Dashboard | 全局概览 |
| Docker 部署 | 完整部署编排 |

---

## 12. 未来扩展 (Post-MVP)

| 特性 | 说明 | 优先级 |
|------|------|--------|
| 规则引擎 | 从 Agent 历史标注提取规则，降低 LLM 成本 | P1 |
| 定时扫描 | 支持 cron 表达式定期自动标注 | P1 |
| 通知集成 | 标注完成/新发现通过邮件/飞书/企微通知 | P2 |
| 数据血缘 | 基于标注的关系发现，构建全链路血缘图 | P2 |
| 知识图谱 (KAG) | 实体关系图可视化 (Neo4j) | P2 |
| RBAC 权限 | 多角色访问控制 | P2 |
| 在线数据预览 | 直接在平台查看已连接数据的原始行 | P2 |
| 自定义标注规则 | 用户编写自己的标注规则 DSL | P3 |
| 联邦标注 | 多个数据源联合标注，跨表关系发现 | P3 |

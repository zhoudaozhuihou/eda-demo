# Chat-Driven Workbench 设计文档

**日期:** 2026-06-14
**版本:** v1.0
**状态:** Draft

---

## 1. 概述

### 1.1 目标

在不改变现有页面布局的前提下，将工作台（`/studio`）改造为 Chat 驱动的全能界面——通过右侧 Chat 对话即可触发所有平台功能，结果实时在中间 Canvas 区域展示。

### 1.2 设计原则

- **布局不变** — 左侧 Sidebar、顶部导航、右侧 ChatPanel 的结构完全保留
- **渐进增强** — 工作台增强，其他页面保持现有行为（折叠 Chat 图标 + 页面辅助问答）
- **结果可导航** — Canvas 中每个结果都带"在 XX 模块中打开"按钮，可跳转至对应详情页
- **多结果历史** — Chat 触发的每次操作结果都保留，用户可回看

### 1.3 范围

| 模块 | Chat 触发操作 | Canvas 结果类型 | 跳转目标 |
|------|-------------|---------------|---------|
| 标签市场 | 搜索标签 | TagResultGrid | /tags/market |
| 标签分析 | 分析客群 | ProfileResult | /tags/analysis |
| 标签开发 | 创建规则 | RuleBuilderResult | /tags/development |
| 数据治理 | 系统概览 | OverviewResult | /governance |
| 知识管理 | 导入文件/抽取知识 | KnowledgeExtractResult | /knowledge |
| 知识管理 | 查知识+抽标签 | KnowledgeTagResult | /knowledge → /tags/market |
| 场景执行 | 执行业务场景 | ScenarioPipeline (现有) | - |

---

## 2. 架构设计

### 2.1 整体架构

```
AppLayout
├─ Sidebar (260px left)
├─ Center ({children})
│   └─ DataAgentStudio (/studio)
│       ├─ CanvasHeader (tab: 场景入口 | 执行记录)
│       ├─ ScenarioGrid (默认视图 — 现有场景卡片)
│       └─ CanvasResult[] (动态渲染 — 新增)
│           ├─ TagResultGrid
│           ├─ ProfileResult
│           ├─ RuleBuilderResult
│           ├─ OverviewResult
│           ├─ KnowledgeExtractResult
│           ├─ KnowledgeTagResult
│           └─ ScenarioPipeline
├─ ChatPanel (380px right)
│   └─ 增强：检测 actionable intent → 写入 ChatActionContext
└─ ChatActionContext (React Context)
    └─ 承载 { actionType, actionData } 的队列
```

### 2.2 ChatActionContext

全局 React Context，用于 ChatPanel 与工作台页面的跨组件通信。

**Context 结构：**

```typescript
interface CanvasAction {
  id: string;
  type: ActionType;
  title: string;
  data: unknown;
  timestamp: number;
}

type ActionType =
  | 'search_tags'
  | 'analyze_segment'
  | 'create_rule'
  | 'system_overview'
  | 'import_knowledge'
  | 'knowledge_to_tags'
  | 'run_scenario';

interface ChatActionContextValue {
  actions: CanvasAction[];
  pushAction: (action: Omit<CanvasAction, 'id' | 'timestamp'>) => void;
  clearActions: () => void;
  removeAction: (id: string) => void;
}
```

**工作流程：**

1. 用户在 ChatPanel 中输入指令
2. ChatPanel 调用后端 Chat API，后端返回 reply + 可选的结构化 action
3. ChatPanel 检测到 action 时，调用 `pushAction()` 写入 Context
4. DataAgentStudio 通过 Context 读取 `actions`，渲染对应 Canvas 组件
5. 用户点击"在 XX 中打开" → 跳转目标页面，Chat 折叠

### 2.3 后端 Chat API 扩展

现有后端 Chat API 增加结构化响应字段：

```typescript
// Chat API 响应扩展
interface ChatResponse {
  reply: string;
  suggestions: string[];
  action?: {
    type: ActionType;
    data: Record<string, unknown>;  // 结构化结果数据
  };
  timestamp: string;
}
```

当用户指令涉及可执行操作时，后端不仅返回文本回复，还附带结构化 action 数据供前端 Canvas 渲染。

---

## 3. Canvas 结果组件

### 3.1 TagResultGrid — 标签搜索结果

**触发条件：** 用户说"搜索标签 X" → Action `search_tags`

**展示内容：**
- 搜索关键词 + 结果数量
- 标签卡片网格（名称、类型、覆盖率、置信度、状态）
- "在标签市场中打开"跳转按钮

**数据结构：**
```typescript
interface TagResultData {
  keyword: string;
  total: number;
  tags: {
    id: string;
    name: string;
    type: string;
    coverage: number;
    confidence: number;
    status: 'published' | 'draft';
  }[];
}
```

### 3.2 ProfileResult — 客群分析结果

**触发条件：** 用户说"分析 X 客群" → Action `analyze_segment`

**展示内容：**
- 客群名称
- 画像雷达图（从现有 ProfileRadar 组件复⽤）
- 客群名片（从现有 ProfileCard 组件复⽤）
- "在标签分析中打开"按钮

**数据结构：**
```typescript
interface ProfileResultData {
  segmentName: string;
  profiles: { name: string; tags: number; score: number }[];
  tags: { name: string; score: number }[];
}
```

### 3.3 RuleBuilderResult — 规则创建结果

**触发条件：** 用户说"创建标签 X" → Action `create_rule`

**展示内容：**
- 标签名称
- 规则条件可视化（标签 AND/OR 组合）
- 预估覆盖人数
- "在标签开发中打开"按钮

**数据结构：**
```typescript
interface RuleResultData {
  tagName: string;
  conditions: { field: string; operator: string; value: string }[];
  estimatedCoverage: number;
  status: 'draft' | 'saved';
}
```

### 3.4 OverviewResult — 系统概览

**触发条件：** 用户说"系统概览"/"数据概览" → Action `system_overview`

**展示内容：**
- 四个核心指标卡片（数据源、数据表、字段、标注数）
- 综合评分
- "在数据治理中心中打开"按钮

**数据结构：**
```typescript
interface OverviewResultData {
  metrics: { label: string; value: number; color: string }[];
  totalScore: number;
}
```

### 3.5 KnowledgeExtractResult — 文件导入与知识抽取

**触发条件：** 用户拖入文件或说"导入 X 并抽取知识" → Action `import_knowledge`

**展示内容：**
- 文件名 + 分析进度条
- 抽取的实体列表（类型分色展示）
- 抽取的关系列表（主语 → 谓语 → 宾语）
- 抽取的标签列表（含置信度）+ "发布到标签市场"按钮
- "在知识管理中打开"按钮

**数据结构：**
```typescript
interface KnowledgeExtractData {
  filename: string;
  status: 'analyzing' | 'completed' | 'failed';
  progress: number;
  entities: { name: string; type: string; mentions: number }[];
  triples: { subject: string; predicate: string; object: string }[];
  tags: { name: string; category: string; confidence: number }[];
}
```

### 3.6 KnowledgeTagResult — 知识查标签

**触发条件：** 用户说"查询 X 知识并生成标签" → Action `knowledge_to_tags`

**展示内容：**
- **Step 1:** 知识条目搜索结果列表（带多选 checkbox）
- **Step 2:** 用户选择条目后点击"抽取标签"
- **Step 3:** 展示合并的标签结果，含来源说明
- "发布到标签市场"按钮

**数据结构：**
```typescript
interface KnowledgeTagData {
  entries: { id: string; filename: string; category: string; date: string; tagCount: number }[];
  selectedIds?: string[];
  extractedTags?: { name: string; confidence: number; source: string }[];
}
```

---

## 4. 工作台页面布局

### 4.1 页面结构

```
┌─────────────────────────────────────────────────────────────┐
│  Tab: [场景入口] [执行记录]                                   │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  默认状态: 场景入口卡片网格                                    │
│  (保持现有 ScenarioPipeline 卡片)                            │
│                                                             │
│  Chat 触发后: 动态渲染 CanvasResult                          │
│  - 结果上方显示标题 + 跳转按钮                                │
│  - 展示对应类型的结构化内容                                    │
│  - 多个结果可切换查看                                         │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│  Chat Panel (右侧 380px)                                     │
│                                                             │
│  "执行记录" Tab 点击查看 Chat 触发的所有操作历史               │
│  点击可切换到对应结果                                         │
└─────────────────────────────────────────────────────────────┘
```

### 4.2 状态切换

| 状态 | 显示内容 |
|------|---------|
| 默认（无 Chat 操作） | 场景入口卡片网格（现有） |
| Chat 触发了操作 | 对应 CanvasResult 组件 |
| 多次操作 | 按时间线展示，Tab 切换"执行记录"可回看 |

---

## 5. Chat 增强

### 5.1 工作台 Chat

当在工作台页面时，ChatPanel 行为增强：

1. **消息可触发操作** — 后端识别用户意图，返回结构化 action
2. **结果联动** — 通过 ChatActionContext 将结果推送到 Canvas
3. **对话上下文** — Chat 记住用户之前触发的操作，支持连续对话

### 5.2 其他页面 Chat

非工作台页面时，ChatPanel 保持现有行为：只做页面感知的问答，不写入 ChatActionContext。

---

## 6. 交互流程示例

### 示例 1: 搜索标签 + 分析客群

```
用户: "搜索标签 留学意向"
  → Chat 回复: "找到 5 个相关标签"
  → Canvas 展示: TagResultGrid (5 个标签卡片)
  → Canvas 标题: "🔍 搜索：留学意向" + [在标签市场中打开]

用户: "分析这些标签覆盖的客群"
  → Chat 回复: "正在分析..."
  → Canvas 展示: ProfileResult (画像雷达 + 客群卡片)
  → 之前的搜索结果保留在"执行记录"中可回看
  → Canvas 标题: "📊 客群分析" + [在标签分析中打开]
```

### 示例 2: 导入文件 → 抽取知识 → 发布标签

```
用户: [拖入文件] "导入这份留学报告"
  → Chat 回复: "正在分析跨境留学客群分析报告..."
  → Canvas 展示: KnowledgeExtractResult (进度条 → 实体/关系/标签)
  → Canvas 标题: "📄 知识抽取：跨境留学客群分析报告" + [在知识管理中打开]

用户: "把标签发布到市场"
  → Chat 回复: "已将 4 个标签发布到标签市场"
  → Canvas 更新: 标签状态变为"已发布"
  → 跳转提示: [在标签市场中查看]
```

### 示例 3: 系统概览 + 治理详情

```
用户: "系统概览"
  → Canvas 展示: 数据源 12 · 数据表 156 · 字段 1247 · 标注 89
  → 综合评分 76%
  → [在数据治理中心中打开]
```

---

## 7. 组件清单

### 新增组件

| 组件 | 路径 | 说明 |
|------|------|------|
| `ChatActionContext` | `src/contexts/ChatActionContext.tsx` | 全局 action 上下文 |
| `CanvasResult` | `src/components/studio/CanvasResult.tsx` | Canvas 容器，根据 action type 渲染对应组件 |
| `TagResultGrid` | `src/components/studio/result/TagResultGrid.tsx` | 标签搜索结果卡片网格 |
| `ProfileResult` | `src/components/studio/result/ProfileResult.tsx` | 客群分析结果（复用 ProfileRadar/ProfileCard） |
| `RuleBuilderResult` | `src/components/studio/result/RuleBuilderResult.tsx` | 规则创建结果 |
| `OverviewResult` | `src/components/studio/result/OverviewResult.tsx` | 系统概览指标卡片 |
| `KnowledgeExtractResult` | `src/components/studio/result/KnowledgeExtractResult.tsx` | 知识抽取结果（含进度条） |
| `KnowledgeTagResult` | `src/components/studio/result/KnowledgeTagResult.tsx` | 知识查标签结果（含多选列表） |

### 现有组件（复用/增强）

| 组件 | 说明 |
|------|------|
| `ChatPanel` | 增强：检测 action，写入 Context |
| `DataAgentStudio` | 新增 Canvas 渲染逻辑，持有 ChatActionContext 引用 |
| `ProfileRadar` | 复用至 ProfileResult |
| `ProfileCard` | 复用至 ProfileResult |
| `ScenarioPipeline` | 保持现有行为，作为 Canvas 结果类型之一 |
| `AppLayout` | 包裹 ChatActionContext Provider |

---

## 8. 不涉及变更

- **AppLayout 布局** — 完全不变
- **Sidebar** — 不变
- **ChatPanel 折叠/展开机制** — 不变
- **其他页面（/tags/*, /knowledge, /governance 等）** — 页面内容不变，ChatPanel 在其上保持现有行为
- **后端 Chat API** — 只扩展响应结构，不改变现有接口签名

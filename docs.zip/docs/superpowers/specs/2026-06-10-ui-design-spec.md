# Data Label Agent - UI Design Specification

> Generated via UI/UX Pro Max Design Intelligence

---

## 1. Design System

### 1.1 Style Identity

| Attribute | Decision | Reason |
|-----------|----------|--------|
| **Primary Style** | Data-Dense Dashboard + Minimalism | 企业数据工具，信息密度高、功能优先 |
| **Design Philosophy** | "Clarity over decoration" | 银行数据治理工具，专业可信 |
| **Mode** | Light为主 + Dark完整支持 | 数据表格在 light 模式下可读性最佳 |

### 1.2 Color Palette

**Primary Scheme (Banking Blue):**

| Role | Hex | Usage | WCAG |
|------|-----|-------|------|
| Primary | `#1E40AF` | 主色调、按钮、活跃状态 | - |
| On Primary | `#FFFFFF` | Primary 上文字 | 4.5:1 ✓ |
| Secondary | `#3B82F6` | Tab/链接、次要按钮 | - |
| Accent | `#D97706` | CTA 强调、新发现标签 | 3:1 ✓ |
| Background | `#F8FAFC` | 页面背景 | - |
| Surface/Card | `#FFFFFF` | 卡片/表格背景 | - |
| Foreground | `#1E3A8A` | 主要文字 | 4.5:1 ✓ |
| Muted | `#64748B` | 辅助文字、描述 | 3:1 ✓ |
| Border | `#E2E8F0` | 分割线、边框 | - |
| Muted BG | `#E9EEF6` | 表格行交替色 | - |
| Success | `#22C55E` | 成功状态 | - |
| Warning | `#F59E0B` | 警告状态 | - |
| Error | `#DC2626` | 错误状态 | - |

**Dark Mode Overrides:**
| Role | Hex |
|------|-----|
| Background | `#0F172A` |
| Surface | `#1E293B` |
| Border | `#334155` |
| Muted BG | `#1E293B` |
| Foreground | `#F1F5F9` |
| Muted | `#94A3B8` |

### 1.3 Typography

| Role | Font | Weight | Size | Line Height |
|------|------|--------|------|-------------|
| H1 - Page Title | IBM Plex Sans | 600 | 28px | 1.3 |
| H2 - Section Header | IBM Plex Sans | 600 | 20px | 1.4 |
| H3 - Card Title | IBM Plex Sans | 600 | 16px | 1.4 |
| Body | IBM Plex Sans | 400 | 14px | 1.5 |
| Body Small | IBM Plex Sans | 400 | 13px | 1.5 |
| Table Header | IBM Plex Sans | 600 | 13px | 1.2 |
| Table Cell | IBM Plex Sans | 400 | 13px | 1.2 |
| Label/Caption | IBM Plex Sans | 500 | 12px | 1.3 |
| Monospace (code) | JetBrains Mono | 400 | 13px | 1.4 |

**CSS Import:**
```css
@import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap');
```

### 1.4 Spacing System

| Token | px | Usage |
|-------|----|-------|
| space-1 | 4px | 微间距 |
| space-2 | 8px | 紧密排列间距 |
| space-3 | 12px | 卡片内边距 |
| space-4 | 16px | 标准间距 |
| space-5 | 20px | 段间距 |
| space-6 | 24px | 组件间距 |
| space-8 | 32px | 章节间距 |
| space-10 | 40px | 大间距 |
| space-12 | 48px | 页面间距 |

### 1.5 Corner Radius

| Token | Value | Usage |
|-------|-------|-------|
| radius-sm | 4px | 输入框、Chip |
| radius-md | 8px | 卡片、对话框 |
| radius-lg | 12px | 大卡片、面板 |
| radius-pill | 999px | 标签、徽章 |

### 1.6 Shadow

| Token | Value | Usage |
|-------|-------|-------|
| shadow-sm | `0 1px 2px rgba(0,0,0,0.05)` | 卡片默认 |
| shadow-md | `0 4px 6px rgba(30,64,175,0.08)` | 悬浮状态 |
| shadow-lg | `0 10px 15px rgba(30,64,175,0.1)` | 对话框、弹出层 |

---

## 2. Layout Architecture

### 2.1 Global Layout

```
┌─────────────────────────────────────────────────────────┐
│  ┌─────────┬─────────────────────────────────────────┐  │
│  │         │  Top Bar (56px)                          │  │
│  │         │  Burger | Logo | Breadcrumb | Notif | User│  │
│  │ 260px   ├─────────────────────────────────────────┤  │
│  │ Sidebar │                                          │  │
│  │         │  Main Content Area                       │  │
│  │         │  (padding: 24px)                         │  │
│  │         │                                          │  │
│  │         │  ┌──────────────────────────────────┐    │  │
│  │         │  │  Page Content                     │    │  │
│  │         │  │                                   │    │  │
│  │         │  └──────────────────────────────────┘    │  │
│  └─────────┴─────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────┘
```

### 2.2 Sidebar Navigation

```
┌─── Data Label Agent ─────────────────┐
│                                       │
│  📊 仪表盘           ← active state  │
│  🔌 数据源管理                       │
│  🏷️ 标注结果                         │
│  🔍 业务发现                         │
│  📈 数据资产                         │
│  ────────────────────── divider      │
│  ⚙️ 标签体系                         │
│  🧠 技能管理                         │
│  💾 记忆检索                         │
│  🤖 LLM 配置                        │
│  📋 审计日志                         │
│                                       │
│  ──────────────────────               │
│  🌙 Dark Mode Toggle                  │
│  👤 admin@bank.com                    │
└───────────────────────────────────────┘
```

**Sidebar Rules:**
- 宽度 260px
- 选中项: bg-blue-50 + text-blue-700 + left border 3px blue-700
- 悬浮: bg-gray-50
- 图标统一使用 MUI Icons (Outlined 风格)
- 分组靠分隔线 (divider)

---

## 3. Page-by-Page Design Specification

### 3.1 仪表盘 (Dashboard)

```
┌── 仪表盘 ─────────────────────────────────────────────┐
│                                                         │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐  │
│  │ 已连接    │ │ 已标注    │ │ 已发现    │ │ 待审核    │  │
│  │ 数据源    │ │ 表数量    │ │ 新标签    │ │ 标注数    │  │
│  │    3     │ │   45     │ │    5     │ │   12     │  │
│  │ +20% ↑  │ │ +12 ↑    │ │ +3 ↑     │ │ ↘ -5 ↓   │  │
│  └──────────┘ └──────────┘ └──────────┘ └──────────┘  │
│                                                         │
│  ┌── 最近标注活动 ──────────┐ ┌── 业务发现摘要 ───────┐  │
│  │ ████████░░ 80%          │ │ 高价值潜力客户  1,245 │  │
│  │ payment 表               │ │ 交叉销售机会    3,800 │  │
│  │ ██████░░░ 60%           │ │ 流失预警          520 │  │
│  │ customer 表              │ │ [查看详情 →]         │  │
│  │ ████░░░░░ 40%           │ └──────────────────────┘  │
│  │ merchant 表              │                         │
│  └──────────────────────────┘                         │
│                                                         │
│  ┌── 最近扫描 ───────────────────────────────────────┐ │
│  │ 数据源       | 状态    | 表数 | 耗时  | 操作     │ │
│  │ 生产数据库   | ✅完成  | 12  | 3:42  | [查看]   │ │
│  │ 风险集市     | ⏳进行中 | 5/8 | 1:20  | [详情]   │ │
│  └────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────┘
```

**Components:**
- `StatCard`: 图标 + 数字 + 标签 + 趋势箭头 (trend up green, down red)
- `ProgressCard`: 进度条 + 名称 + 百分比
- `ActivityTable`: 紧凑表格 + 状态 Chip

---

### 3.2 数据源管理 (Connections)

```
┌── 数据源管理 ─────────────────────────── [+ 新增数据源] ┐
│                                                         │
│  ┌── 搜索/过滤 ───────────────────────────────────────┐ │
│  │ [🔍 搜索数据源...]  [全部类型 ▼]  [全部状态 ▼]    │ │
│  └────────────────────────────────────────────────────┘ │
│                                                         │
│  ┌── 数据源卡片 ─────────────────────────────────────┐  │
│  │ 💾 生产数据库 (PostgreSQL)  ● Connected            │  │
│  │ 主机: db.prod.internal:5432/data_label              │  │
│  │ 发现: 12 张表 | 已标注: 12 | 上次扫描: 2h前       │  │
│  │ [▶ 运行标注] [↻ 测试连接] [⚙ 编辑] [🗑 删除]   │  │
│  └────────────────────────────────────────────────────┘  │
│                                                          │
│  ┌── 风险数据集市 (MaxCompute) ──────────────────────┐  │
│  │ ☁️ Risk Mart  ⚠ Connection Error                   │  │
│  │ 主机: odps.aliyun.com:443                         │  │
│  │ 发现: -- | 已标注: -- | 上次扫描: 从未            │  │
│  │ [▶ 运行标注] [↻ 测试连接] [⚙ 编辑] [🗑 删除]   │  │
│  └────────────────────────────────────────────────────┘  │
│                                                          │
│  ┌── 新增数据源对话框 ───────────────────────────────┐  │
│  │ 名称: [________________]                             │  │
│  │ 类型: [▼ PostgreSQL / MaxCompute / BigQuery]       │  │
│  │ 主机: [________________]  端口: [________]          │  │
│  │ 数据库: [________________]                          │  │
│  │ 用户名: [________________]                          │  │
│  │ 密码:  [●●●●●●●●]                                 │  │
│  │                                                    │  │
│  │ [测试连接]                     [保存] [取消]       │  │
│  └────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────┘
```

**Key Design Decisions:**
- 使用 Card 布局而非 Table，因为每个数据源的信息丰富
- 状态 Chip: `● Connected` (green), `● Disconnected` (gray), `⚠ Error` (red)
- 新建表单在 Dialog 中，非新页面 (减少跳转)
- 扫描按钮为 Primary 蓝色，删除为红色

---

### 3.3 标注结果 (Annotation Result)

```
┌── 标注结果 ────────────────────────────────────────────┐
│  数据源: [▼ 全部]  |  状态: [▼ 全部]  |  [🔍 搜索表] │
│                                                         │
│  ┌────────────────────────────────────────────────────┐ │
│  │ │ 表名       │ 数据域   │ 敏感度 │ 字段│ 状态 │ 操作│ │
│  ├────────────────────────────────────────────────────┤ │
│  │ │ customer   │ 客户信息 │ PII    │ 15 │ ✅   │ [查看]│ │
│  │ │ payment    │ 交易记录 │Financial│ 8 │ ⏳   │ [查看]│ │
│  │ │ merchant   │ 商户信息 │Internal│ 6 │ ✅   │ [查看]│ │
│  │ │ risk_score │ 风控指标 │Confid..│ 22 │ ✅   │ [查看]│ │
│  │ │ products   │ 产品信息 │ Public │ 4 │ ✅   │ [查看]│ │
│  │ │ ...        │          │        │    │      │      │ │
│  └────────────────────────────────────────────────────┘ │
│                                                         │
│  共 12 张表  < 1 2 3 >                                  │
└─────────────────────────────────────────────────────────┘
```

**点击表名 → 进入字段级标注详情页:**

```
┌── customer 表 (15 字段) ──────────────────────────────┐
│                                                         │
│  表级标签: [客户信息] [PII] [零售银行] [GDPR] [✏编辑] │
│                                                         │
│  ┌── 字段标注 ───────────────────────────────────────┐ │
│  │ □ │ 字段名     │ 类型   │ 标签              │ 置信度│状态│
│  ├───┼───────────┼────────┼──────────────────┼──────┼───┤
│  │ □ │ id        │ BIGINT │ PK,标识符         │ 1.00 │ ✅ │
│  │ □ │ name      │ VARCHAR│ 姓名,PII          │ 0.95 │ ⏳ │
│  │ □ │ id_card   │ VARCHAR│ 身份证号,PII      │ 0.98 │ ⏳ │
│  │ □ │ phone     │ VARCHAR│ 电话,PII          │ 0.80 │ ⏳ │
│  │ □ │ email     │ VARCHAR│ 邮箱,PII          │ 0.85 │ ⏳ │
│  │ □ │ balance   │ DECIMAL│ 金额,Financial    │ 0.90 │ ✅ │
│  │ □ │ created_at│ TIMESTMP│ 时间戳          │ 1.00 │ ✅ │
│  │ □ │ ...       │        │                  │      │    │
│  └────────────────────────────────────────────────────┘ │
│                                                         │
│  [全选] [批量通过] [批量驳回]  [导出结果]              │
│                                                         │
│  ┌── 标注证据详情 (点击标签展开) ─────────────────────┐ │
│  │ 字段: id_card                                       │ │
│  │ 标签: 身份证号 (PII) 置信度: 0.98                    │ │
│  │ 证据: 字段名含"id_card"，样本匹配身份证号正则        │ │
│  │ /^[1-9]\d{5}(19|20)\d{2}(0[1-9]|1[0-2])\d{3}[\dX]$/│ │
│  │ 来源: Agent | 建议时间: 2026-06-10 14:30:22         │ │
│  └────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────┘
```

**Key Design Decisions:**
- 标注状态 Chip: `✅ Approved` / `⏳ Suggested` / `❌ Rejected`
- 置信度用颜色编码: >0.95 绿, 0.8-0.95 黄, <0.8 红
- 行点击展开证据面板 (expandable row)
- 批量操作为选中的行的批量通过/驳回

---

### 3.4 业务发现 (Business Discovery)

```
┌── 业务发现 ────────────────────────────────────────────┐
│                                                         │
│  数据源: [▼ 生产数据库 ──────────]  ▶ [运行发现]       │
│                                                         │
│  ┌── 高价值潜力客户 ─────────────────────────────────┐ │
│  │ 📊                                                   │ │
│  │ 发现 1,245 位潜力客户 (TOP 10%)                      │ │
│  │ 判定依据:                                            │ │
│  │ • 月均消费 >¥50,000 + 准时还款 >12个月               │ │
│  │ • 境外消费占比 >30% + 高客单价                        │ │
│  │ • 额度使用率 >70% + 按时还款                          │ │
│  │                                                      │ │
│  │ [查看客户清单 →]                          置信度: 87% │ │
│  └──────────────────────────────────────────────────────┘ │
│                                                          │
│  ┌── 交叉销售机会 ───────────────────────────────────┐  │
│  │ 💡 发现 3,800 位客户有交叉销售机会                    │  │
│  │ 细分:                                                │  │
│  │ • 仅持有信用卡但有大额存款转账: 1,200 人              │  │
│  │   → 推荐: 理财/定期存款                              │  │
│  │ • 月消费类型单一(仅餐饮): 2,600 人                    │  │
│  │   → 推荐: 旅行/购物类联名卡                          │  │
│  └──────────────────────────────────────────────────────┘  │
│                                                          │
│  ┌── 流失预警 ───────────────────────────────────────┐  │
│  │ ⚠ 520 位客户近期消费显著下降                         │  │
│  │ 近 60 天消费下降 >50% + 高额度客户                     │  │
│  │ → 建议触发专属权益挽回                               │  │
│  └──────────────────────────────────────────────────────┘  │
│                                                          │
│  ┌── 客户画像聚类 ───────────────────────────────────┐  │
│  │ 基于 MCC + 消费时段 + 金额分群                       │  │
│  │ ┌────────────────────────────────────────────────┐   │  │
│  │ │ 分群     │ 占比   │ 月均消费 │ 特征            │   │  │
│  │ ├────────────────────────────────────────────────┤   │  │
│  │ │ 商务精英 │ 23%   │ ¥18,200 │ 工作日餐饮+差旅  │   │  │
│  │ │ 家庭支柱 │ 35%   │ ¥9,500  │ 周末超市+教育   │   │  │
│  │ │ 年轻潮流 │ 28%   │ ¥6,800  │ 线上购物+娱乐   │   │  │
│  │ │ 高端消费 │ 14%   │ ¥45,000 │ 奢侈品+境外消费 │   │  │
│  │ └────────────────────────────────────────────────┘   │  │
│  └──────────────────────────────────────────────────────┘  │
│                                                           │
│  ┌── Agent 推理日志 ───────────────────────────────────┐ │
│  │ > 2026-06-10 14:30:22 | 分析 payment 表近6月数据     │ │
│  │ > 发现模式: 高端消费群组月均增长12%                   │ │
│  │ > 交叉引用 customer_risk 表验证客户等级               │ │
│  │ > 标注 3 个发现为"高置信度" (87-92%)                 │ │
│  └──────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────┘
```

---

### 3.5 数据资产 (Data Assets)

```
┌── 数据资产 ────────────────────────────────────────────┐
│                                                         │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐  │
│  │ 总表数   │ │ 总字段   │ │ 业务域   │ │ PII 字段 │  │
│  │   45    │ │   320   │ │   8     │ │   23    │  │
│  └──────────┘ └──────────┘ └──────────┘ └──────────┘  │
│                                                         │
│  ┌── 数据质量报告 ───────────────────────────────────┐ │
│  │ 🔴 字段       │ 表          │ 问题   │ 严重度     │ │
│  │ phone        │ customer    │ 空值35%│ ⚠️ Medium  │ │
│  │ mcc_code     │ transaction │ 未知15%│ ⚠️ Medium  │ │
│  │ currency     │ payment     │ 不一致 │ 🔴 High     │ │
│  │ ...          │             │        │            │ │
│  └────────────────────────────────────────────────────┘ │
│                                                         │
│  ┌── 数据关联发现 ──────────────────────────────────┐  │
│  │ 💡 merchant_id 出现在 3 张表中 → 建议建立外键关联 │  │
│  │    payment.merchant_id → merchant.id              │  │
│  │    transaction.merchant_id → merchant.id          │  │
│  │    settlement.merchant_id → merchant.id           │  │
│  │                                                    │  │
│  │ 💡 "客户风险评分"字段未被任何下游模型使用 → 价值未释放│  │
│  └────────────────────────────────────────────────────┘  │
│                                                         │
│  ┌── 敏感数据分布 (按表) ─────────────────────────────┐ │
│  │ ┌────────────────────────────────────────────────┐  │ │
│  │ │ ████████████████████░░░░░░░░░░                 │  │ │
│  │ │ customer  ████████████████░░░░ 15 PII 字段     │  │ │
│  │ │ payment   ██████░░░░░░░░░░░░░░  5 PII 字段     │  │ │
│  │ │ kyc       ████████████████████ 22 PII 字段     │  │ │
│  │ │ risk      ██░░░░░░░░░░░░░░░░░░  2 PII 字段     │  │ │
│  │ └────────────────────────────────────────────────┘  │ │
│  └────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────┘
```

---

### 3.6 LLM 配置 (LLM Config)

```
┌── LLM 模型配置 ──────────────────────────────────────────┐
│                                                            │
│  ┌── 已注册 Provider ──────────────────────────────────┐  │
│  │                                                      │  │
│  │  ┌── Claude ─────────────────────────────────────┐  │  │
│  │  │ ● Enabled                                      │  │  │
│  │  │ API Key:    ●●●●●●●●●●  [更新]                  │  │  │
│  │  │ Base URL:   https://api.anthropic.com           │  │  │
│  │  │ 可用模型:   Opus, Sonnet, Haiku                │  │  │
│  │  │ 状态:       ✅ 连接正常 (延迟 230ms)             │  │  │
│  │  └────────────────────────────────────────────────┘  │  │
│  │                                                      │  │
│  │  ┌── GitHub Copilot ───────────────────────────────┐ │  │
│  │  │ ● Enabled                                      │  │  │
│  │  │ Token:      ●●●●●●●●●●  [更新]                 │  │  │
│  │  │ Endpoint:   https://api.githubcopilot.com        │  │  │
│  │  │ 可用模型:   GPT-4o, GPT-4o-mini, o3-mini       │  │  │
│  │  │ 状态:       ✅ 连接正常                          │  │  │
│  │  └────────────────────────────────────────────────┘  │  │
│  │                                                      │  │
│  │  [+ 添加 Provider]                                   │  │
│  └──────────────────────────────────────────────────────┘  │
│                                                            │
│  ┌── 路由策略 ──────────────────────────────────────────┐ │
│  │                                                      │ │
│  │  当前策略: [▼ balanced ────────────]                  │ │
│  │                                                      │ │
│  │ ┌─ 策略详情 ─────────────────────────────────────┐  │ │
│  │ │ 任务类型         | Provider  | 模型             │  │ │
│  │ │ Schema 分析      | Copilot   | GPT-4o-mini     │  │ │
│  │ │ 数据采样         | Copilot   | GPT-4o-mini     │  │ │
│  │ │ 标准标注         | Claude    | Sonnet          │  │ │
│  │ │ 复杂推理         | Claude    | Opus            │  │ │
│  │ └────────────────────────────────────────────────┘  │ │
│  │                                                      │ │
│  │  月度统计: Total Tokens 2.3M | 预估费用 $45.20      │ │
│  └──────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────┘
```

---

### 3.7 技能管理 (Skills Manager)

```
┌── 技能管理 ────────────────────────────── [+ 安装技能] ┐
│                                                          │
│  ┌── 系统内置 Skills ────────────────────────────────┐  │
│  │  ☑ schema_discovery    v1.0  ● 已启用  [配置]     │  │
│  │     字段: schema获取、主外键识别                     │  │
│  │  ☑ data_sampling       v1.0  ● 已启用  [配置]     │  │
│  │     字段: 数据采样、空值率统计                      │  │
│  │  ☑ pii_detection       v1.2  ● 已启用  [配置]     │  │
│  │     字段: PII/NPI 敏感数据识别                       │  │
│  │  ☑ domain_classifier   v1.0  ● 已启用  [配置]     │  │
│  │     字段: 银行业务域分类                              │  │
│  │  ☐ quality_assessment  v0.8  ⚠ 测试版 [启用]     │  │
│  │     字段: 数据质量评估                               │  │
│  └────────────────────────────────────────────────────┘  │
│                                                          │
│  ┌── 业务 Skills ────────────────────────────────────┐  │
│  │  ☑ customer_insight    v1.0  ● 已启用  [配置]     │  │
│  │  ☑ cross_sell          v1.0  ● 已启用  [配置]     │  │
│  │  ☐ churn_prediction    v0.5  ⚠ 测试版 [启用]     │  │
│  └────────────────────────────────────────────────────┘  │
│                                                          │
│  ┌── Pipeline 编排 ───────────────────────────────────┐ │
│  │  full_annotation_pipeline     [▶ 运行] [✏ 编辑]   │ │
│  │  ① schema_discovery → ② data_sampling               │ │
│  │  → ③ pii_detection + ④ domain_classifier            │ │
│  │  → ⑤ sensitive_classifier → ⑥ tag_recommendation    │ │
│  │                                                      │ │
│  │  [创建新 Pipeline]                                   │ │
│  └──────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────┘
```

---

### 3.8 记忆检索 (Memory Browser)

```
┌── 记忆检索 ──────────────────────────────────────────┐
│                                                         │
│  类型: [▼ 全部 ──────────]  [🔍 搜索记忆内容...]       │
│                                                         │
│  ┌── Pattern Memory (高频模式) ──────────────────────┐ │
│  │ 字段名含 "id_card" → [PII, 身份证号]  置信度 0.95  │ │
│  │ 匹配 12 张表, 47 次使用      [标注历史] [↻ 应用]  │ │
│  │ ───────────────────────────────────────────────── │ │
│  │ 字段名含 "amount" → [Financial, 金额]  置信度 0.92 │ │
│  │ 匹配 8 张表, 35 次使用       [标注历史] [↻ 应用]  │ │
│  │ ───────────────────────────────────────────────── │ │
│  │ 字段名含 "phone" → [PII, 电话]  置信度 0.88      │ │
│  │ 匹配 5 张表, 22 次使用       [标注历史] [↻ 应用]  │ │
│  └────────────────────────────────────────────────────┘ │
│                                                         │
│  ┌── Correction Memory (修正记录) ────────────────────┐ │
│  │ merchant.category_code  (用户修正)                   │ │
│  │ 原标签: code → 修正: mcc_code                       │ │
│  │ 时间: 2026-06-09 15:30  by admin                    │ │
│  └────────────────────────────────────────────────────┘ │
│                                                         │
│  ┌── Knowledge Memory (知识库) ──────────────────────┐ │
│  │ 📘 HKMA Supervisory Policy Manual SA-2              │ │
│  │ 数据分类规则: Customer Name → Restricted            │ │
│  │ Transaction Amount → Internal                       │ │
│  └────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────┘
```

---

### 3.9 标签体系管理

```
┌── 标签体系管理 ──────────────────────────── [+ 新建标签]┐
│                                                          │
│  ┌── 标签分类 ────────────────────────────────────────┐ │
│  │                                                      │ │
│  │  数据域 (8)        敏感度 (6)       合规 (5)         │ │
│  │  ┌───────────────┐ ┌────────────┐ ┌─────────────┐  │ │
│  │  │ ● 客户信息 12 │ │ ● PII   23│ │ ● GDPR   15 │  │ │
│  │  │ ● 交易记录 8  │ │ ● Fin.. 18│ │ ● HKMA   12 │  │ │
│  │  │ ● 风控指标 5  │ │ ● Int.. 45│ │ ● MAS    8  │  │ │
│  │  │ ● 产品信息 3  │ │ ● Pub.. 12│ │ ● PBOC   6  │  │ │
│  │  │ ● 渠道数据 2  │ └────────────┘ └─────────────┘  │ │
│  │  │ ● 参考数据 3  │                                   │ │
│  │  └───────────────┘                                   │ │
│  │                                                      │ │
│  └──────────────────────────────────────────────────────┘ │
│                                                          │
│  ┌── 待确认新标签 ───────────────────────────────────┐  │
│  │ 🔔 Agent 发现以下标签 (待管理员确认):               │  │
│  │  "跨境交易"  (出现于 tx_overseas, fx_swap)   [✓][✗]│  │
│  │  "绿色信贷"  (出现于 loan_envir, esg_report)  [✓][✗]│  │
│  └──────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────┘
```

---

## 4. Component Library

| Component | MUI v7 | Customization | States |
|-----------|--------|---------------|--------|
| Button | `<Button>` | variant + color + size className | default, hover, disabled, loading |
| Chip | `<Chip>` | color prop + custom className | default, clickable, deletable |
| Card | `<Card>` | variant="outlined" | default, hover (elevation) |
| Table | `<Table>` | stickyHeader, size="small" | row hover, selected |
| Dialog | `<Dialog>` | maxWidth | open/close, transition |
| TextField | `<TextField>` | size="small" | default, focused, error, disabled |
| Select | `<Select>` | size="small" | default, open, disabled |
| Snackbar | `<Snackbar>` | + `<Alert>` | success, error, info, warning |
| Drawer | `<Drawer>` | variant="permanent" | - |
| Chip (tag) | `<Chip>` | custom color + onDelete | - |
| Progress | `<LinearProgress>` | color="primary" | determinate, indeterminate |
| IconButton | `<IconButton>` | size="small" | default, hover |
| Tabs | `<Tabs>`+`<Tab>` | textColor="primary" | selected, hover |
| Tooltip | `<Tooltip>` | arrow | hover show |

---

## 5. Responsive Behavior

| Breakpoint | Width | Layout Changes |
|------------|-------|----------------|
| **xs** | < 768px | Sidebar → Drawer (hamburger), cards → stacked, tables → horizontal scroll |
| **sm** | 768px+ | Sidebar visible, 2-column card grid |
| **md** | 1024px+ | 3-column card grid, full table display |
| **lg** | 1440px+ | Max content width 1280px, centered |

**Responsive Patterns:**
- Dashboard stat cards: 4 columns → 2 columns → 2x2 grid
- Connection cards: 3 columns → 2 columns → 1 column
- Data tables: horizontal scroll on mobile (Table container with overflow-x: auto)
- Dialogs: full-screen on mobile (<768px)

---

## 6. Interaction & Animation

| Interaction | Duration | Easing | Implementation |
|-------------|----------|--------|----------------|
| Button hover | 150ms | ease-out | MUI default |
| Card hover elevation | 200ms | ease-out | `transition: box-shadow 200ms` |
| Dialog open | 225ms | ease-out | MUI default |
| Sidebar item | 150ms | ease-out | background-color transition |
| Row hover | 100ms | ease-out | background-color transition |
| Chip appear | 200ms | ease-out | scale(0.9)→1 |
| Loading shimmer | 1.5s loop | linear | skeleton pulse animation |
| Modal backdrop | 225ms | ease-out | opacity transition |
| Tabs indicator | 200ms | ease-in-out | MUI default |

**Reduced Motion:** All animations use CSS `transition` (not JS-driven setTimeout), so `prefers-reduced-motion` is automatically respected by the browser.

---

## 7. Accessibility Checklist

- [ ] All interactive elements have visible focus rings (2px outline)
- [ ] Icon buttons have aria-label
- [ ] Color contrast: body text 4.5:1 minimum (already verified in palette)
- [ ] Tab order matches visual order
- [ ] Data tables have proper `<th>` and scope attributes
- [ ] Form inputs have associated `<label>` elements
- [ ] Status is not conveyed by color alone (Chip text + icon)
- [ ] Skip-to-main-content link
- [ ] Heading hierarchy: h1 → h2 → h3, no skipping
- [ ] Dialog traps focus when open
- [ ] prefers-reduced-motion respected
- [ ] All touch targets ≥44×44px

---

## 8. Pre-Delivery Quality Gate

- [ ] No emoji used as icons (MUI Icons only)
- [ ] All icons in consistent Outlined style
- [ ] cursor-pointer on all clickable elements
- [ ] Hover/focus/active states defined for all interactive elements
- [ ] Loading states visible (skeleton/spinner) for async operations
- [ ] Error states with retry action for failed operations
- [ ] Empty states with guidance message (not blank pages)
- [ ] Dark mode tested (sidebar input: --bg / --surface / --border tokens)
- [ ] Test at 375px, 768px, 1440px breakpoints
- [ ] No horizontal scroll on mobile
- [ ] Material UI theme tokens used (no hardcoded hex colors in components)
- [ ] TailwindCSS used for spacing/layout, MUI for complex components

# Demo Golden Journey, Studio Sessions, and Multi-Model Design

**Date:** 2026-06-14  
**Status:** Approved for implementation planning  
**Scope:** Make Demo mode capable of demonstrating the complete AI-native bank tagging product journey, repair Chat-to-Canvas action alignment for natural tag questions, add persistent Studio conversation history in the adaptive left rail, and replace the unstable Copilot integration with supported multi-model connections including GitHub Models.

## 1. Problem

The product currently exposes a `DEMO / AI` switch, but the two modes do not yet represent complete and reliable product behaviors.

- Demo data exists across database seeds, endpoint-specific constants, frontend templates, and generated values. Objects and metrics are not guaranteed to remain consistent across pages.
- Demo data currently includes 3 connections, 29 tables, 63 columns, 35 annotations, 44 tag definitions, 1 knowledge document, 10 requirement tickets, and no audit or memory records. This is enough to populate several pages but not enough to demonstrate the full product journey.
- Some pages use database records, some tag APIs return endpoint-specific Demo constants, and some frontend views contain local mock values or random comparisons.
- The runtime Demo toggle changes only selected endpoint behavior. It does not fully control Chat planning or the complete product data source.
- The Studio assistant can answer natural language questions such as “留学标签有哪些”, but the Canvas stays unchanged.
- The Studio has one browser-local session ID and no persistent session list. Users cannot reliably find and restore prior conversations with their corresponding Canvas Runs.
- The repository contains a `CopilotProvider` that calls `https://api.githubcopilot.com/v1`, but that is not the supported public inference contract for a business application.
- The LLM configuration page is read-only and does not select an active provider or model.

## 2. Root Cause of Missing Canvas Results

Studio Chat uses two independent paths:

1. `run_react_agent()` produces the natural-language Chat response.
2. `classify_workbench_action()` decides whether to create a persisted `WorkbenchRun` for Canvas.

The current tag action pattern requires an explicit action word such as “搜索”, “查找”, “检索”, “发现”, or “推荐” before “标签”, or the phrase “标签市场”.

```text
(搜索|查找|检索|发现|推荐).{0,12}(标签|tag)|标签市场
```

“留学标签有哪些” does not match this pattern. The assistant therefore returns a useful answer, but Studio Chat returns `run: null`, so the frontend correctly leaves Canvas unchanged.

The fix must improve backend intent classification and preserve the unified Run contract. The frontend must not infer an action from Chat text.

## 3. Goals

- Provide one versioned, internally consistent Demo dataset for a complete bank business journey.
- Make Demo mode deterministic, offline-capable, repeatable, and suitable for product demonstrations.
- Make AI mode use a configured model for understanding, planning, and explanation while keeping business metrics grounded in backend tools.
- Ensure Chat, Canvas, and independent product pages show consistent objects and metrics.
- Recognize natural Chinese tag discovery questions, including “留学标签有哪些”.
- Persist and display multiple Studio sessions in an adaptive history rail.
- Restore both messages and the latest Canvas Run when switching Studio sessions.
- Support DeepSeek, GitHub Models, and generic OpenAI-compatible model connections.
- Remove dependence on the unsupported `api.githubcopilot.com/v1` application integration.

## 4. Non-Goals

- Building final production RBAC, audit immutability, or a durable distributed task queue in this phase.
- Allowing an LLM to directly generate customer counts, tag coverage, market opportunity values, or data quality metrics.
- Moving all browser-local preferences to user accounts in this phase.
- Implementing every possible bank business scenario before the first complete Demo journey works.
- Depending on free GitHub Models limits for a production bank deployment.

## 5. Evaluated Demo Approaches

### A. Unified Scenario Dataset and Business Services - Selected

Create one versioned scenario dataset and make all Demo-facing business services derive results from it.

Advantages:

- Cross-page objects and metrics remain consistent.
- Chat Actions and independent pages can share the same result contracts.
- The dataset can be tested, migrated, and exported.
- The design supports later replacement with real bank data.

Trade-off:

- Existing endpoint-specific Demo constants and frontend mock values must be consolidated.

### B. Expand Existing Endpoint Constants

Add more independent constants to each current Demo endpoint.

Advantages:

- Fastest initial implementation.

Trade-offs:

- Numbers and object identities will continue to drift.
- It cannot convincingly demonstrate an AI-native closed loop.

### C. Distribute a Pre-Filled SQLite Snapshot Only

Use a large pre-populated SQLite database as the Demo implementation.

Advantages:

- Stable and fast to deploy.

Trade-offs:

- Business rules remain hidden and dispersed.
- Version upgrades and PostgreSQL migration become difficult.

**Decision:** Implement Approach A. A generated SQLite Demo snapshot may be distributed as an artifact, but it is not the source of business logic.

## 6. Mode Semantics

### Demo Mode

- Uses the versioned `study_abroad_finance_v1` dataset.
- Uses deterministic intent classification and deterministic planning.
- Uses the same backend business tools and result contracts as AI mode.
- Works without external model access.
- Produces fixed, repeatable results for the demonstration script.

### AI Mode

- Uses the currently active model connection to understand intent, plan tool calls, and explain results.
- Uses backend business tools to retrieve and calculate all business facts.
- Never allows the model to fabricate customer totals, coverage, quality scores, market opportunity values, or data lineage.
- Returns a clear configuration error if no valid model connection exists.
- Allows the user to return to Demo mode without losing existing Studio sessions.

### Switching Modes

- A mode change affects new requests immediately.
- Existing messages, Runs, and Canvas results remain unchanged.
- Each Run records the mode, provider, model, and business tool versions used to create it.
- The switch label describes the real behavior: `演示模式` and `AI 模式`.

## 7. Golden Demo Journey

The first complete scenario is **留学金融机会发现**.

### Journey Objective

A retail banking business user wants to identify customers likely to need study-abroad financial services, understand the opportunity, and verify the supporting data value and governance status.

### Step 1: Knowledge Enters the Platform

Preloaded knowledge includes:

- 留学金融综合服务方案
- 跨境留学汇款政策
- 境外教育缴费产品说明
- 留学信用卡与外汇服务说明
- 营销授权与客户触达合规规则

The user can:

- view summaries, entities, and relationships
- inspect candidate tags extracted from knowledge
- generate and publish selected tags
- see the source knowledge for generated tags

### Step 2: Data Assets and Tag Construction

Preloaded data assets include:

- customer profile
- family relationships
- cross-border transactions
- wire transfers
- foreign currency accounts
- product holdings
- marketing consent
- customer interactions and education-related events

Core scenario tags include:

- 有留学子女
- 有留学需求
- 留学汇款
- 跨境消费
- 高净值客户
- 有外汇需求
- 营销可触达

Every scenario tag contains:

- stable identifier
- business definition and category
- source table and field lineage
- rule or extraction method
- coverage count and ratio
- confidence and data quality
- publication status
- usage scenarios

### Step 3: Chat and Canvas

The following prompts must produce structured Runs and matching Canvas results:

| Prompt | Action | Canvas Result |
|---|---|---|
| 留学标签有哪些 | tag discovery | Matching study-abroad tags |
| 圈选有留学需求且可营销触达的客户 | customer segment | Study-abroad prospect segment |
| 有哪些留学金融市场机会 | market opportunity | Products, opportunity size, and evidence |
| 分析这些数据的价值 | data value analysis | Key assets, quality gaps, and value score |

Chat explanations and Canvas results use the same backend Action result. An explanatory follow-up without a new action leaves the existing Canvas result unchanged.

### Step 4: Business and Governance Closure

- Tag Analysis creates and saves the `留学金融潜客` segment.
- Market Discovery shows relevant products such as cross-border remittance, foreign exchange, and international credit cards.
- Data Value and Governance show the tables, fields, PII, data quality issues, and lineage supporting the scenario.
- Audit history contains knowledge import, tag publication, segment execution, and export events.

## 8. Demo Dataset Design

The dataset is versioned as `study_abroad_finance_v1`.

### Stable Identity and Metrics

- Use deterministic object IDs.
- Store named scenario metrics centrally.
- Do not calculate Demo values with random functions.
- Do not define the same metric separately in multiple endpoints or frontend files.

Representative fixed metrics include:

- total addressable retail customers
- customers with study-abroad intent
- marketing-contactable study-abroad prospects
- customers with prior study-abroad remittance
- opportunity values by product
- supporting data asset value score
- quality issue counts

The exact values are defined once in the dataset and asserted across API contract tests.

### Data Categories

The scenario dataset provides:

- connections, tables, columns, and annotations
- knowledge documents and extracted graph data
- tag definitions, rules, and customer tag assignments
- customer segment definitions and aggregate outputs
- market opportunities and supporting evidence
- data value assessments and governance metrics
- requirement tickets, tasks, audit events, and selected memory records

### Seed and Snapshot

- The seed is idempotent and records the dataset version.
- Demo mode initializes the named dataset explicitly.
- A generated SQLite snapshot may be packaged for fast installation.
- The seed and snapshot must produce the same accepted API outputs.

## 9. Demo User Journey Acceptance Matrix

The demonstration is accepted only when this ordered script works:

1. Enter Studio in Demo mode and see product introduction content.
2. Ask “留学标签有哪些” and see the same matching tags in Chat and Canvas.
3. Open Tag Market and confirm the same tag definitions and coverage values.
4. Open a tag and inspect its knowledge source and data lineage.
5. Ask to circle marketing-contactable study-abroad prospects and see the expected segment.
6. Open Tag Analysis and confirm the same segment criteria and customer total.
7. Ask for study-abroad financial market opportunities and see products supported by the same segment.
8. Open Business Discovery and confirm matching opportunities.
9. Ask for supporting data value and see the same assets and quality issues.
10. Open Data Governance and confirm lineage, PII, and quality results.
11. Inspect audit events for the demonstrated actions.
12. Switch to another Studio session and back, confirming messages and Canvas restore together.
13. Switch to AI mode with a configured provider and repeat a supported prompt, confirming that tool results remain grounded in the same business services.

## 10. Natural Intent Classification

### Classification Boundary

The backend determines whether a request is explanatory or executable. The frontend does not infer actions.

### Supported Tag Discovery Expressions

Tag discovery recognition includes:

- explicit verbs: 搜索、查找、检索、查询、查看、列出、发现、推荐
- natural list questions: 有哪些标签、标签有哪些、有什么标签
- tag market references
- common English expressions using `tag` or `tags`

The classifier extracts the business keyword without retaining question words such as “有哪些”.

### Classification Tests

At minimum:

- “留学标签有哪些” creates `tag_discovery`.
- “有哪些留学标签” creates `tag_discovery`.
- “列出高净值标签” creates `tag_discovery`.
- “什么是标签” remains explanatory and creates no Run.
- A new executable question replaces the selected Canvas Run.
- An explanatory follow-up preserves the selected Canvas Run.

## 11. Studio Session History

### Layout

Use the selected adaptive history rail:

```text
Primary Navigation | Session History | Canvas | Current Chat
```

- Wide desktop: history rail remains visible.
- Medium desktop: history rail collapses to a narrow icon rail.
- Mobile: history opens as a drawer.
- Existing Canvas and current Chat interactions remain unchanged.

### Session Model

Add a persisted `StudioSession`:

```text
StudioSession
  id
  title
  scenario_type
  mode
  latest_run_id
  message_count
  created_at
  updated_at
  archived_at
```

Chat messages and Workbench Runs belong to a Studio session.

### Session Behavior

- `New conversation` creates a new session and shows the Welcome view.
- The title initially derives from the first user prompt.
- AI mode may improve the title asynchronously, but title generation never blocks Chat.
- Each history item shows title, business type, update time, and latest Run status.
- Selecting a session restores its messages and latest Run in parallel.
- Clearing history clears only the active session.
- Archiving removes a session from the default list without deleting its audit history.

### Session API

- `POST /api/studio/sessions`
- `GET /api/studio/sessions`
- `GET /api/studio/sessions/{session_id}`
- `PATCH /api/studio/sessions/{session_id}`
- `POST /api/studio/sessions/{session_id}/archive`
- Existing message and Run reads remain session-scoped.

## 12. Multi-Model Connections

### Supported Provider Types

- `deepseek`
- `github_models`
- `openai_compatible`

`openai_compatible` provides the extension point for approved OpenAI endpoints, Azure gateways, internal bank model gateways, and other compatible services.

### GitHub Models

Use the supported GitHub Models inference API:

```text
POST https://models.github.ai/inference/chat/completions
Authorization: Bearer <GitHub PAT>
Permission: models:read
```

The provider is displayed as **GitHub Models**, not GitHub Copilot.

The existing `api.githubcopilot.com/v1` provider is removed or migrated. GitHub Models free usage is intended for experimentation and is rate limited. Production use requires approved organizational paid usage or another approved provider.

Official references:

- https://docs.github.com/en/github-models/use-github-models/prototyping-with-ai-models
- https://docs.github.com/en/rest/models/inference

### Connection Model

```text
LLMConnection
  id
  name
  provider_type
  base_url
  encrypted_api_key
  default_model
  enabled
  is_default
  config
  last_test_status
  last_tested_at
  created_at
  updated_at
```

### Configuration Experience

The LLM configuration page supports:

- create, edit, enable, disable, and delete connections
- write-only secret input
- connection test
- available-model discovery where supported
- default provider and default model selection
- clear status and error messages

Secrets are encrypted at rest, are never returned by read APIs, and are never logged.

## 13. AI Planning and Grounded Business Tools

Both modes use the same business tool layer:

```text
Chat Request
  -> Mode Router
  -> Demo Deterministic Planner / AI Model Planner
  -> Shared Business Tools
  -> Structured Action Result
  -> Persisted Workbench Run
  -> Chat Explanation + Canvas Result
```

The planner may select and order tools. Business tools own facts and metrics.

Initial shared tools:

- search tags
- retrieve tag definition and lineage
- create or evaluate a segment
- discover market opportunities
- assess supporting data value
- retrieve knowledge and governance evidence

Every tool returns a typed result. The backend validates planner output before execution. Unknown tools, malformed arguments, timeouts, limits, and provider failures return safe errors and never create fabricated business results.

## 14. Data and API Consistency Rules

- The same stable tag ID appears in Chat Action results, Tag Market, Tag Analysis, knowledge lineage, and audit events.
- The same segment ID and customer total appear in Canvas, Tag Analysis, Business Discovery, and audit events.
- Market opportunities reference their supporting segment and products.
- Data value results reference supporting tables, fields, quality issues, and lineage.
- Chat text is an explanation of structured tool results, not an independent data source.
- Demo and AI modes use the same Action and Run response schemas.
- Frontend pages do not contain authoritative scenario metrics.

## 15. Error and Recovery Rules

- If intent classification is uncertain in Demo mode, return an explanatory response or ask for clarification without creating a Run.
- If AI mode has no valid connection, show a configuration error and provide a Demo-mode fallback.
- If a model call fails, do not execute unvalidated guessed actions.
- If a business tool fails, persist the Run as failed with a safe message.
- If session restoration partially fails, retain the successfully restored messages or Run and show a recoverable error.
- If Demo dataset validation fails, startup or explicit Demo initialization fails clearly instead of presenting inconsistent data.

## 16. Testing

### Dataset Contract Tests

- Dataset version and deterministic IDs are stable.
- Every required golden-journey object exists.
- Cross-page metrics and references reconcile.
- Seed is idempotent.
- Seed and distributed SQLite snapshot produce the same accepted API outputs.

### Backend Tests

- Natural tag questions create the expected Run.
- Explanatory questions create no Run.
- Demo and AI mode routing follows the selected semantics.
- Shared tools return typed, grounded results.
- Studio session create, list, select, restore, clear, and archive behavior works.
- LLM connection CRUD never returns secrets.
- DeepSeek, GitHub Models, and OpenAI-compatible requests use correct connection configuration.
- Provider failures and rate limits create safe errors.

### Frontend Tests

- Adaptive history rail follows desktop, collapsed, and mobile behavior.
- Switching sessions restores messages and Canvas together.
- New conversation shows Welcome content.
- Mode switch communicates Demo versus AI behavior.
- LLM connection management handles testing and default selection.
- Existing page layouts and result-card interactions remain unchanged.

### End-to-End Tests

- Execute the complete golden journey acceptance matrix.
- Run the natural question “留学标签有哪些” and verify the Canvas tag result.
- Switch sessions and refresh the page, verifying restoration.
- Run a Demo-mode journey without external network access.
- Run an AI-mode prompt with a configured test provider and verify grounded tool results.

## 17. Implementation Sequence

1. Fix natural intent classification and add regression tests.
2. Add Studio session model, APIs, and adaptive history rail.
3. Define the versioned golden-journey dataset and consistency assertions.
4. Consolidate tag, segment, opportunity, knowledge, and data-value Demo services around the shared dataset.
5. Add audit and supporting records required by the journey.
6. Introduce the shared business tool layer and explicit Demo/AI mode router.
7. Add persisted multi-model connection management.
8. Replace the Copilot endpoint with GitHub Models.
9. Route AI planning through the selected connection and shared tools.
10. Execute and document the complete Demo journey.

## 18. Acceptance Criteria

- Demo mode can demonstrate the full留学金融机会发现 journey without external model access.
- “留学标签有哪些” creates a tag discovery Run and renders matching Canvas content.
- Chat, Canvas, Tag Market, Tag Analysis, Business Discovery, and Data Governance show consistent objects and metrics.
- Demo and AI mode semantics are explicit and behave as designed.
- AI mode cannot fabricate authoritative business metrics.
- Studio displays the selected adaptive session history rail.
- Selecting a prior session restores both messages and its latest Canvas Run.
- DeepSeek, GitHub Models, and generic OpenAI-compatible connections can be configured and selected.
- GitHub Models uses the official inference endpoint and a PAT with `models:read`.
- Secrets are encrypted, write-only through APIs, and absent from logs and read responses.
- The golden journey is covered by an executable acceptance script and automated consistency tests.

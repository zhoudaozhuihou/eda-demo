# Unified Workbench Run Design

**Date:** 2026-06-14  
**Status:** Approved for implementation  
**Scope:** Repair the Data Agent Studio Workbench so Chat, execution progress, and Canvas results stay aligned.

## 1. Problem

The current Workbench derives its visible state from several independent frontend mechanisms:

- Chat text is mapped to a panel by keyword detection.
- Chat replies are converted into synthetic actions and result data in the frontend.
- Background task progress and outputs are simulated in the frontend.
- The Canvas may display a business page that does not correspond to the current chat or task.
- The initial welcome message makes the UI behave as if work has already started.

These mechanisms can disagree. A chat may discuss one task while the Canvas displays the tag market or a simulated result for another task.

## 2. Goals

- Make one persisted backend object the source of truth for executable Workbench activity.
- Keep Chat, progress, and Canvas tied to the same executable request.
- Keep the last Canvas result visible during explanatory chat.
- Update one Canvas result card in place while a task runs and when it completes.
- Restore the latest Workbench state for the current session after refresh or re-entry.
- Show product introduction content before the first executable action.
- Preserve the current page layout, styling, and existing result components.

## 3. Non-Goals

- Redesigning the Workbench visual language or page layout.
- Embedding full business pages inside the Canvas.
- Implementing the final production task queue, RBAC, or audit subsystem.
- Replacing SQLite in this change.
- Building complete production algorithms for all action types.

## 4. Core Model

Each executable chat request creates one persisted `WorkbenchRun`.

```text
WorkbenchRun
  id
  session_id
  request_message_id
  action_type
  title
  status
  progress
  current_step
  steps
  result_type
  result_data
  error
  created_at
  updated_at
```

Allowed statuses are:

```text
pending -> running -> succeeded
                   -> failed
                   -> canceled
```

The first implementation persists the model in SQLite through the existing SQLAlchemy setup. JSON-compatible fields are stored through SQLAlchemy JSON types so the schema remains portable to PostgreSQL.

## 5. Responsibility Boundaries

### Chat

Chat expresses user intent and explains what happened. The backend determines whether a message is explanatory or executable.

- Explanatory chat returns a reply with no Run.
- Executable chat returns a reply and the created Run.
- Chat messages may reference `run_id`, but do not own execution state.

### Workbench Run

The Run owns action type, execution status, progress, steps, result, and errors. It is the only execution state used by the frontend.

### Canvas

Canvas renders the selected or latest Run using existing result components. It never infers an action from chat text and never manufactures result data.

Completed result cards may link to the relevant business page. The business page itself is not mirrored inside Canvas.

## 6. Data Flow

1. The user sends a message with the current `session_id`.
2. `POST /api/studio/chat` stores the user and assistant messages.
3. The backend classifies the request:
   - If explanatory, the response contains `run: null`.
   - If executable, the backend creates a Run and returns it with the reply.
4. When a Run is returned, the frontend selects that Run for Canvas.
5. The frontend reads the same Run until it reaches a terminal state.
6. The Canvas updates the same result card from pending to running to succeeded or failed.
7. On reload, the frontend fetches the latest Run for the current session and restores it.

The initial implementation may use polling. The API and frontend state must not depend on polling so a later task queue or event stream can replace it.

## 7. API Contract

### Chat Response

`POST /api/studio/chat`

```json
{
  "reply": "正在为你识别高潜客户...",
  "suggestions": [],
  "mode": "execution",
  "steps": [],
  "run": {
    "id": "run-id",
    "session_id": "session-id",
    "action_type": "customer_segment",
    "title": "高潜客户圈选",
    "status": "running",
    "progress": 20,
    "current_step": "应用客户标签规则",
    "steps": [],
    "result_type": null,
    "result_data": null,
    "error": null,
    "created_at": "...",
    "updated_at": "..."
  }
}
```

For explanatory chat, `run` is `null`.

### Run Read Endpoints

- `GET /api/studio/runs/{run_id}` returns one Run.
- `GET /api/studio/runs/latest?session_id=...` returns the latest restorable Run or `null`.

Run payloads use the same schema in chat and read endpoints.

## 8. Initial Action Types

The first implementation recognizes these action types:

- `tag_discovery`
- `customer_segment`
- `market_opportunity`
- `data_value_analysis`

Unknown action types render through a generic result card. The frontend must not infer a known action type from text.

The backend may initially use deterministic intent rules and existing demo services to create results. This logic remains behind the Chat Action contract so it can later be replaced by an agent planner or production service without changing the Workbench.

## 9. Canvas Rules

Canvas display priority is:

1. A Run explicitly selected by the user.
2. The latest restorable Run for the current session.
3. A manually selected scenario preview, if that interaction remains available.
4. The existing Welcome view.

Behavior by state:

- **No Run:** show the existing introduction, core capabilities, recommended prompts, and example scenarios.
- **Pending or running:** show one result card with progress, current step, and step list.
- **Succeeded:** extend the same card with result summary, metrics, and the relevant business-page link.
- **Failed:** keep the same card, show an understandable error, and provide retry behavior where supported.
- **Explanatory chat:** append chat messages and leave Canvas unchanged.
- **New executable chat:** select the new Run and replace the current Canvas selection.

The welcome assistant message does not count as an executable action and does not suppress the Welcome view.

## 10. Frontend State Changes

The Workbench keeps:

- `latestRun`
- `selectedRun`
- chat messages
- request/loading/error state

It removes executable-state derivation from:

- `detectPanelContext`
- `detectActionFromReply`
- synthetic action/result generation
- sleep-based task progress
- chat-keyword-driven business-page rendering

Existing result components remain in use and receive backend-provided data through a single Run-to-result adapter.

## 11. Error and Recovery Rules

- If Chat fails, keep the user's input available for retry and do not change Canvas.
- If Run execution fails, persist `failed` status and a safe error message.
- If a Run result is missing or malformed, render the generic result card without fabricated values.
- If latest-Run restoration fails, show the Welcome view and allow Chat to continue.
- A refresh restores running, succeeded, and failed Runs for the current session.

## 12. Testing

### Backend

- Explanatory chat returns `run: null`.
- Each supported executable intent creates the expected action type.
- A Run can be read by ID.
- Latest Run is scoped by session and restores terminal and non-terminal states.
- Invalid or missing Run IDs return the existing API error contract.

### Frontend

- Welcome view appears before the first executable action.
- Explanatory chat leaves the last Canvas result unchanged.
- A new Run selects one result card and updates it in place.
- Refresh restores the latest Run.
- Unknown and malformed results use the generic fallback.
- Legacy keyword/action/progress synthesis is no longer used.

### End-to-End

- Verify the initial Workbench placeholder.
- Trigger each supported Action and confirm Chat and Canvas refer to the same Run.
- Ask an explanatory follow-up and confirm Canvas stays unchanged.
- Refresh and confirm the current Run is restored.
- Verify a failed Run remains visible with a useful error state.

## 13. Implementation Sequence

1. Add the persisted Workbench Run model and Run read APIs.
2. Extend the studio Chat contract to return an optional Run.
3. Move Action selection and initial execution outputs behind the backend contract.
4. Refactor the Workbench to select and render Runs.
5. Remove frontend keyword inference and simulated progress.
6. Add contract, behavior, and browser tests.

## 14. Acceptance Criteria

- Chat and Canvas cannot independently select different executable tasks.
- Explanatory chat never resets or changes Canvas.
- An executing task and its final output occupy the same Canvas card.
- The first Workbench visit shows the Welcome content.
- Refresh restores the latest Run for the current session.
- No Workbench action, progress, or result is fabricated from frontend chat text.
- Existing Workbench layout and interaction styling remain visually unchanged.

# Business Value Discovery 设计文档

> 目标：将 Data Label Agent 从数据管理工具升级为商业价值发现平台
> 行业场景：金融/银行
> 核心方向：客户360洞察

---

## 整体架构

```
Business Discovery 2.0
│
├── Phase 1: 客户数据地图 ← 本期实现
│   ├── 客户数据全景视图
│   ├── 表关系图谱
│   ├── 完整性矩阵
│   └── 质量热力图
│
├── Phase 2: 客户分群分析 ← 本期实现
│   ├── 价值分层识别
│   ├── 画像摘要生成
│   ├── 丰富度雷达图
│   └── 维度覆盖率评分
│
└── Phase 3: 交叉销售发现 ← 本期实现
    ├── 产品关系图谱
    ├── 产品渗透分析
    ├── 交叉销售机会看板
    └── 数据缺口提醒
```

**底层复用**：
- Schema Discovery → 表/字段/外键关系
- Data Sampler → sample_values（采样数据）
- Annotation Engine → domain/sensitivity/quality 标签
- Rule Tagger → 字段名模式匹配算法（扩展）

---

## Phase 1: 客户数据地图

### 后端 API

#### `GET /api/discovery/customer-data-map`

聚合所有 domain=客户信息 标注的表，计算：

- **表级统计**：每张客户表的字段数、质量、空值率、PII 字段数、完整性评分
- **表关系**：基于外键和字段名匹配的关联表列表
- **完整性矩阵**：按画像维度（基本信息/联系方式/身份认证/风险画像/产品持有）计算每张表的字段覆盖率
- **总览指标**：客户表总数、字段总数、PII 总数、平均完整度、待审核标注数

#### `GET /api/discovery/customer-table/{table_id}`

单表详情：
- 字段列表及每个字段的类型、标注、采样值
- 关联表列表
- 质量详情
- 标注统计

### 画像维度分类算法

基于字段名正则匹配，将字段归入5个画像维度：

| 维度 | 匹配模式 |
|------|---------|
| 基本信息 | name, gender, sex, age, birth, birthday, national, marital |
| 联系方式 | phone, mobile, tel, email, mail, address, addr, wechat |
| 身份认证 | id_card, passport, ssn, id_no, identity, certificate, id_type |
| 风险画像 | income, salary, credit, risk, tier, score, rating, level |
| 产品持有 | product, account, holding, balance, asset, portfolio |

没有匹配的字段归入"其他"维度。

### 完整性评分

```
completeness = 匹配到画像维度的字段数 / 总字段数
评分规则: >=0.8 高, >=0.5 中, <0.5 低
```

### 前端组件

新页面内容集成到 `BusinessDiscovery.tsx`，在现有 InsightCards 下方新增：

1. **概览指标行** — 4个 MetricCard（客户表数/字段总数/PII 字段数/平均完整度）
2. **客户表卡片网格** — 每张客户表一张增强卡片：
   - 表名 + 中文注释 + 质量徽章
   - 字段数 + PII 数 Chip
   - "关联 N 张表" Chip（可点击跳转）
   - 完整性进度条（百分比）
   - 展开查看字段详情
3. **完整性矩阵** — MUI Table，行=画像维度，列=客户表，单元格=✅/❌/—

---

## Phase 2: 客户分群分析

### 后端 API

#### `GET /api/discovery/customer-insights`

对每张客户表生成分析报告：

```python
{
  "table_name": "customer_360_profiles",
  "comment": "客户360画像",
  "field_count": 11,
  "profile_coverage": {  # 5个维度的覆盖率
    "基本信息": 0.6,
    "联系方式": 0.4,
    "身份认证": 0.3,
    "风险画像": 0.2,
    "产品持有": 0.0
  },
  "coverage_score": 0.3,  # 平均覆盖率
  "value_tier_fields": ["income_level", "risk_level", "customer_tier"],
  "value_tier_completeness": 0.6,  # 3/5 价值维度
  "pii_count": 2,
  "suggestions": [
    "缺少产品持有相关字段，限制交叉销售分析",
    "建议补充客户行为偏好数据"
  ]
}
```

### 画像摘要生成

对每张客户表生成自然语言摘要（基于模板拼接）：
- "customer_360_profiles — 客户360画像：包含11个字段，覆盖基本信息、联系方式、身份认证、风险画像4个维度，缺少产品持有维度。含2个PII字段，数据质量高。"

### 丰富度雷达计算

从 profile_coverage 中提取5个维度值，前端用简单SVG或CSS绘制雷达形状：
- 每轴 = 一个维度（0-100%）
- 填充区域表示覆盖率
- 灰色虚线表示完整覆盖（100%）参考线

---

## Phase 3: 交叉销售发现

### 后端 API

#### `GET /api/discovery/product-affinity`

分析产品相关表和客户表之间的关联：

```python
{
  "product_tables": [
    {
      "name": "product_rates",
      "comment": "产品利率表",
      "product_fields": ["rate_type", "product_type", "fee_type"]
    }
  ],
  "customer_table_relations": [
    {
      "from_table": "customer_360_profiles",
      "to_table": "product_rates",
      "via_field": "customer_id",
      "relation_type": "foreign_key",
      "confidence": "high"  # high/medium/low
    }
  ],
  "cross_sell_opportunities": [
    {
      "customer_table": "customer_360_profiles",
      "product_table": "loan_products",
      "opportunity": "客户画像表与贷款产品表存在关联字段，可分析'有存款无贷款'客户",
      "missing_link": "缺少客户_产品关联表",
      "priority": "high"
    }
  ],
  "product_field_categories": [
    {"category": "贷款产品", "fields": ["loan_type", "loan_amount"]},
    {"category": "存款产品", "fields": ["deposit_type", "interest_rate"]},
    {"category": "投资产品", "fields": ["wealth_type", "risk_level"]}
  ]
}
```

### 产品分类算法

基于字段名匹配：

| 产品大类 | 匹配模式 |
|---------|---------|
| 贷款产品 | loan, mortgage, credit, debit |
| 存款产品 | deposit, saving, current, fixed |
| 投资产品 | wealth, fund, investment, portfolio, finance |
| 保险产品 | insurance, policy, coverage, premium |
| 卡产品 | card, credit_card, debit_card |

### 关系推断

表之间关系的发现依赖两种方式：
1. **外键关系** — 已由 SchemaDiscovery 发现
2. **字段名推断** — 两个表存在同名/同义字段（如 customer_id / cust_id）推断可能存在关联

---

## 数据流

```
[数据源] → Schema Discovery → 表/字段/关系 → Annotation → 标注结果
                                 ↓                          ↓
                          Data Sampler → sample_values    domain=客户信息 标签
                                 ↓                          ↓
                     ┌───────────────────┐      ┌─────────────────────┐
                     │ 客户数据地图 API   │      │ 客户分群/交叉销售 API │
                     │ (Phase 1)         │      │ (Phase 2+3)         │
                     └────────┬──────────┘      └──────────┬──────────┘
                              │                            │
                              └──────────┬─────────────────┘
                                         ↓
                               BusinessDiscovery.tsx
                               (增强后的业务发现页面)
```

---

## 错误处理

- 如果数据库没有客户相关的表（无 domain=客户信息 标注），所有 API 返回空数据+提示信息
- 前端显示友好空状态："尚未发现客户数据表，请先运行数据源标注"
- 采样数据为空时，完整性矩阵按字段名匹配而非实际值计算
- API 失败时显示 Alert + retry 按钮

---

## 自审检查

- [x] 无占位符或 TODO
- [x] Phase 1/2/3 数据一致（profile_coverage 字段名在 Phase 2 和 Phase 3 中一致）
- [x] 聚焦在单一业务目标（客户360）内
- [x] 设计考虑到了数据为空、标注未完成等边界情况
- [x] 所有字段名和 API 路径在三个 Phase 之间保持一致
- [x] 每个 API 的返回结构清晰，前端组件职责明确

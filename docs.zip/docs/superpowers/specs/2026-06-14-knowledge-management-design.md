# 知识管理模块设计文档

## 1. 产品定位

知识管理模块是数据标签平台的**知识中枢**，遵循 DIKW 金字塔模型（Data → Information → Knowledge → Wisdom），将碎片化的业务文档、产品说明、分析报告转化为**结构化知识**，再通过实体关系图谱和标签生成 pipeline，最终驱动**客户画像**和**商业决策**。

### 核心价值
- **知识显性化**：将业务人员的隐性知识（文档/报告/经验）转化为显性的结构化数据
- **知识复用**：一次分析，多次使用 — 实体、关系、标签均可被其他模块引用
- **知识驱动标签**：从知识中提取的标签可直接发布到标签市场，成为圈选分析的基础
- **知识图谱**：实体关系网络可视化，发现隐藏的业务关联

## 2. 架构设计

### 2.1 DIKW 金字塔映射

```
Wisdom  ─── 客户圈选、交叉分析、商业决策
  ↑
Knowledge ─ 实体图谱、关系网络、衍生标签
  ↑
Information ┤ 结构化摘要、标签分类、置信度评分
  ↑
Data     ─── 原始文档、业务报告、产品说明
```

### 2.2 SECI 知识转化模型

| 转化模式 | 定义 | 平台实现 |
|----------|------|----------|
| **社会化** | 隐性→隐性（经验分享） | 知识共享、团队可见 |
| **外部化** | 隐性→显性（知识表达） | AI 分析：文本→实体/关系/标签 |
| **组合化** | 显性→显性（知识整合） | 全局实体浏览器、跨知识条目搜索 |
| **内化化** | 显性→隐性（知识吸收） | Agent 聊天搜索、标签市场引用 |

### 2.3 知识生命周期

```
创建 → 分析 → 结构化 → 发布 → 应用 → 演化
 │       │        │       │      │       │
输入    DeepSeek  实体    标签    圈选    更新
文档    提取      图谱    市场    分析    分析
```

## 3. 功能模块

### 3.1 知识输入
- **直接文本输入**：在页面输入标题 + 内容 + 分类
- **文件上传**：支持 Markdown、CSV、Excel（复用 TagDiscovery 能力）
- **分类体系**：通用、客群分析、产品说明、业务报告、市场研究、风控合规

### 3.2 AI 结构化分析
- **实体提取**：识别人物(Person)、组织(Org)、概念(Concept)、产品(Product)、事件(Event)、地点(Location) 六类实体
- **关系提取**：主体-谓词-客体 三元组（如：客户-拥有-香港账户）
- **标签生成**：基于内容语义提取可发布的业务标签，含置信度评分
- **摘要生成**：200 字以内的内容摘要

### 3.3 知识展示
- **知识列表**：表格展示，支持分类筛选、状态过滤
- **知识详情**：
  - 内容摘要
  - 实体列表（按类型着色）
  - 关系图谱（可视化三元组网络）
  - 标签列表（按置信度着色）
- **全局实体浏览器**：跨知识条目搜索实体，展示实体类型和来源

### 3.4 知识 → 标签 Pipeline

```
知识条目 → AI 提取标签 → 预览标签 → 发布到标签市场 → 标签分析圈选
                                            ↓
                                      TagDefinition
                                      (category + value + description)
```

### 3.5 知识 → Agent 集成

Agent 工具：
- `search_knowledge(query)` — 搜索知识库
- `add_knowledge(title, content)` — 直接添加知识
- `generate_tags_from_knowledge(id)` — 从知识生成标签

## 4. 数据库模型

基于 `UploadedDocument` 模型扩展：

```python
class UploadedDocument(Base):
    __tablename__ = "uploaded_documents"
    id            # UUID 主键
    filename      # 标题/文件名
    file_type     # 类型 (markdown/csv/excel/knowledge)
    category      # 分类 (通用/客群分析/产品说明/业务报告/市场研究/风控合规)
    status        # 状态 (uploaded/analyzing/completed/failed)
    content_text  # 提取的文本内容
    extracted_tags     # JSON: [{name, category, confidence, reason}]
    extracted_entities # JSON: [{name, type, mentions}]
    extracted_triples  # JSON: [{subject, predicate, object}]
    summary       # 摘要
```

## 5. API 设计

| 方法 | 路径 | 说明 |
|------|------|------|
| POST | `/api/knowledge/analyze` | 添加并分析知识 |
| GET | `/api/knowledge` | 知识列表（分页+分类筛选） |
| GET | `/api/knowledge/{id}` | 知识详情 |
| DELETE | `/api/knowledge/{id}` | 删除知识 |
| POST | `/api/knowledge/{id}/generate-tags` | 生成标签到市场 |
| GET | `/api/knowledge/categories` | 获取全部分类 |
| GET | `/api/knowledge/entities/search` | 全局实体搜索 |
| GET | `/api/knowledge/stats` | 知识统计 |

## 6. 用户旅程

### 完整流程：业务文档 → 客群圈选

```
Step 1: [知识管理] 添加业务报告（分类：客群分析）
Step 2: [知识管理] AI 自动分析 → 提取实体/关系/标签
Step 3: [知识管理] 查看知识图谱 → 确认提取结果
Step 4: [知识管理] 生成标签 → 发布到标签市场
Step 5: [标签市场]  查看新发布的标签
Step 6: [标签分析]   使用标签进行人群圈选
Step 7: [Agent 助手] 通过对话搜索知识库
```

### 快捷操作
- 知识详情 → "查看标签市场" 按钮
- 知识详情 → "使用标签分析" 按钮
- 知识列表 → "生成标签到市场" 按钮
- 实体浏览器 → 点击实体跳转来源知识

## 7. 技术实现

### 后端
- **框架**: FastAPI + SQLAlchemy async
- **LLM**: DeepSeek (langchain-openai ChatOpenAI)
- **分析流程**: 单 LLM 调用，一次提取全部结构化信息
- **模型**: `UploadedDocument` (已存在，扩展 `category` 字段)

### 前端
- **页面**: `/knowledge` 路由，`KnowledgeManagement.tsx`
- **组件**: Table、Dialog、实体卡片、关系图谱卡片
- **状态管理**: React useState + useEffect 本地状态
- **交互**: 两 Tab 设计（知识列表 + 实体浏览器）

## 8. Agent 工具

注册在 `langgraph_agent.py` 和 `plan_agent.py`：

```python
@tool
async def search_knowledge(query: str) -> str
@tool
async def add_knowledge(title: str, content: str) -> str
@tool
async def generate_tags_from_knowledge(knowledge_id: str) -> str
```

## 9. 未来规划

- [ ] **RAG 检索增强**：接入向量数据库，支持语义相似度搜索
- [ ] **知识版本管理**：同一知识的多次分析版本对比
- [ ] **知识关联推荐**：基于实体重叠推荐相关知识点
- [ ] **知识质量评分**：基于引用率、标签使用率评估知识价值
- [ ] **批量导入**：支持批量文档上传和分析
- [ ] **知识分享**：团队协作、评论和批注

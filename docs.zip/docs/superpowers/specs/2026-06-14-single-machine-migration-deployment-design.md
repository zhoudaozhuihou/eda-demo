# Single-Machine Migration and Deployment Design

**Date:** 2026-06-14  
**Status:** Approved direction, ready for implementation planning  
**Scope:** Move the current Data Label platform to another Linux or Windows Server environment without containers or Nginx, migrate demo and business data, retain a PostgreSQL path, and allow the existing functional pages to be embedded into another frontend foundation without changing their layout or interactions.

## 1. Current State and Risks

The project can currently run as a FastAPI backend and Vite frontend, but it is not yet a repeatable deployment artifact.

- The backend creates tables with `Base.metadata.create_all()` at startup. It has no applied Alembic migration history.
- `backend/sql/init.sql` targets PostgreSQL but no longer matches the complete ORM model set.
- SQLite uses the working-directory-relative path `backend/data_label.db`.
- Uploaded knowledge files are stored in the operating-system temporary directory and may disappear or be omitted during migration.
- Demo data is seeded automatically when the database appears empty, but the seed version is not recorded.
- The frontend development server proxies `/api` to the backend; production static hosting is not configured.
- Browser-local state such as Studio session ID, tag favorites, and saved segments is not server migration data.
- Secrets are loaded from `.env`; `.env` must not be included in migration bundles or source control.
- Audit, RBAC, durable task execution, and production-grade schema migration are incomplete.

## 2. Evaluated Deployment Approaches

### A. One Service, One Port - Recommended

Build the React frontend once, copy `frontend/dist` into the release, and let FastAPI serve both `/api/*` and the single-page application on one port.

Advantages:

- No Nginx, container, CORS, or multi-port browser configuration.
- Same artifact and URL structure on Linux and Windows.
- The target foundation template can later embed the route module without changing backend deployment.
- Health checks, startup, shutdown, logging, and rollback are managed as one service.

Trade-off:

- FastAPI serves static files. This is appropriate for the current single-machine scale but is not intended to replace a CDN at large scale.

### B. Separate Frontend and Backend Processes

Run a static frontend server and FastAPI as separate services and ports.

Advantages:

- Frontend and backend can restart independently.

Trade-offs:

- Requires two services, CORS rules, API URL management, and more Windows/Linux operational steps.
- Adds complexity without solving a current product requirement.

### C. Build Directly Inside the Target Foundation Template

Move the feature routes and pages into the target template and deploy only that combined frontend.

Advantages:

- Best final integration with the target shell.

Trade-offs:

- Cannot be safely completed before the target template source and route conventions are available.
- Creates migration risk if deployment and shell integration happen in the same release.

**Decision:** Use Approach A for deployment. Prepare the frontend as an embeddable route module so Approach C can be performed later without altering the functional page layouts or interactions.

## 3. Target Runtime Architecture

```text
Browser
  |
  | http://host:8000
  v
FastAPI / Uvicorn service
  |-- /api/*       API routers
  |-- /health      health check
  |-- /*           built React SPA and route fallback
  |
  +-- data/
      |-- data_label.db
      |-- uploads/
      |-- backups/
      |-- logs/
      +-- manifests/
```

Service managers:

- Linux: `systemd`
- Windows Server: WinSW

The program release directory is immutable. Runtime data, configuration, logs, and backups live outside the release directory.

## 4. Directory Layout

### Linux

```text
/opt/data-label/releases/<version>/   immutable release
/opt/data-label/current -> releases/<version>
/etc/data-label/data-label.env        secrets and runtime config
/var/lib/data-label/                  SQLite database and uploads
/var/log/data-label/                  logs
/var/backups/data-label/              backup bundles
```

### Windows Server

```text
C:\DataLabel\releases\<version>\       immutable release
C:\DataLabel\current\                  current release
C:\ProgramData\DataLabel\config\       secrets and runtime config
C:\ProgramData\DataLabel\data\         SQLite database and uploads
C:\ProgramData\DataLabel\logs\         logs
C:\ProgramData\DataLabel\backups\      backup bundles
```

## 5. Runtime Configuration Contract

The application must accept absolute paths and deployment behavior through environment variables:

```text
DATA_LABEL_ENV=production
DATA_LABEL_DATA_DIR=/var/lib/data-label
DATA_LABEL_DATABASE_URL=sqlite+aiosqlite:////var/lib/data-label/data_label.db
DATA_LABEL_UPLOAD_DIR=/var/lib/data-label/uploads
DATA_LABEL_STATIC_DIR=/opt/data-label/current/frontend/dist
DATA_LABEL_DEMO_MODE=false
DATA_LABEL_SEED_MODE=none
DATA_LABEL_HOST=0.0.0.0
DATA_LABEL_PORT=8000
DATA_LABEL_LOG_DIR=/var/log/data-label
```

Supported seed modes:

- `none`: never add demo data.
- `demo`: initialize an empty database with a named, versioned demo dataset.
- `migrate`: require an imported database or import bundle and never auto-seed.

Secrets such as LLM API keys, database credentials, and the encryption key remain in the environment file. Migration packages must contain an environment template only. Existing secrets must be rotated when moving to a new environment.

## 6. Release Artifact

Each release bundle contains:

```text
data-label-<version>/
  backend/
  frontend/dist/
  deploy/linux/
  deploy/windows/
  scripts/
  requirements.lock
  RELEASE_MANIFEST.json
```

`RELEASE_MANIFEST.json` records:

- application version and Git commit
- supported Python and Node build versions
- Alembic schema revision
- demo dataset version
- artifact checksums
- build timestamp

The target server does not need Node.js. Frontend assets are built before packaging. Python dependencies may be installed from an approved internal package source or a pre-built offline wheelhouse.

## 7. Data Classification for Migration

### Migrated Runtime Data

- SQLite database
- uploaded knowledge files
- generated persistent artifacts added later
- required encryption key when encrypted source connection credentials must remain readable

### Re-created Data

- frontend build output
- Python virtual environment
- caches
- temporary files
- logs, unless explicitly retained for compliance

### Demo Data

Demo definitions are versioned in source and seeded only by explicit seed mode. Demo data must not be mixed into a production migration by automatic startup behavior.

### Browser-Local Data

`tag_favorites`, `saved_segments`, and Studio session IDs are currently stored in browser local storage. They are not included in a server migration. Before production rollout, favorites and saved segments should move into backend user preference tables. Studio session IDs may remain browser-scoped.

## 8. SQLite Migration Procedure

1. Put the source environment into maintenance mode and stop the service.
2. Create a backup bundle with the Python SQLite backup API.
3. Copy the database, uploads, and migration manifest into one bundle.
4. Record SHA-256 checksums for every file.
5. Run `PRAGMA integrity_check` against the backup database.
6. Transfer the bundle through the approved channel.
7. Verify checksums on the target server.
8. Restore into the target data directory.
9. Run Alembic upgrades against the restored database.
10. Start the service and run smoke checks.

The backup manifest records:

```json
{
  "format_version": 1,
  "application_version": "0.1.0",
  "schema_revision": "<alembic revision>",
  "demo_dataset_version": "<version or null>",
  "database": "data_label.db",
  "uploads": "uploads/",
  "created_at": "<UTC timestamp>",
  "checksums": {}
}
```

Rollback keeps the previous release and previous data backup. A schema migration that cannot be safely downgraded requires restoring the prior backup rather than attempting a destructive downgrade.

## 9. PostgreSQL Migration Path

SQLite remains the initial production store, but schema changes must become database-portable immediately.

Required preparation:

- Establish Alembic as the only schema evolution mechanism.
- Create a baseline revision from the current ORM models.
- Remove startup-time production reliance on `create_all()`.
- Use SQLAlchemy portable types for JSON, timestamps, booleans, and identifiers.
- Treat `backend/sql/init.sql` as obsolete after the Alembic baseline.
- Add PostgreSQL integration tests for migrations and core repositories before cutover.

Future SQLite-to-PostgreSQL cutover:

1. Provision PostgreSQL and apply Alembic to an empty database.
2. Stop writes to SQLite.
3. Export logical domain records in foreign-key order.
4. Import through a controlled ETL command that validates counts and references.
5. Validate row counts, critical aggregates, and sample records.
6. Switch `DATA_LABEL_DATABASE_URL`.
7. Run smoke and reconciliation checks.

The SQLite file is never copied directly into PostgreSQL. Vector search or `pgvector` is enabled only when the memory/knowledge retrieval implementation actually requires it.

## 10. Frontend Foundation Template Integration

The current feature page layouts and interactions remain unchanged. Integration changes only the outer shell and route mounting.

Target frontend boundaries:

```text
DataLabelProviders
  ThemeProvider
  shared API configuration
  feature contexts

DataLabelRoutes
  /studio
  /knowledge
  /tags/development
  /tags/market
  /tags/analysis
  /discovery
  /governance
  ...

StandaloneShell
  current AppLayout and Sidebar
```

Standalone deployment renders `StandaloneShell + DataLabelRoutes`. The target foundation template renders its own shell around `DataLabelProviders + DataLabelRoutes`.

Rules:

- Do not rewrite page components during shell integration.
- Preserve existing route page width, spacing, result cards, and interaction behavior.
- Replace only navigation ownership, top-level layout ownership, route prefix, theme bridge, and API base configuration.
- Support `VITE_APP_BASE` and `VITE_API_BASE` so the module can mount below a target path.
- Run visual regression checks for the Workbench and all primary feature pages before acceptance.

## 11. Startup, Health, Logging, and Operations

The service starts with a platform-neutral Python entrypoint that:

1. validates required configuration and writable directories
2. applies Alembic upgrades
3. validates the SQLite database
4. starts Uvicorn

Operational endpoints:

- `/health`: process is running
- `/api/health/ready`: database and required storage are writable and schema revision is current

Logs are written to stdout/stderr for service-manager capture and optionally to the configured log directory with rotation. Secrets, prompts containing bank data, and raw customer records must not be logged.

## 12. Security and Compliance Requirements

- Do not include `.env` or secrets in release or migration bundles.
- Rotate any existing LLM keys before target-environment deployment.
- Preserve or deliberately rotate the application encryption key; encrypted connection credentials otherwise become unreadable.
- Restrict data, config, and backup directory permissions to the service account and administrators.
- Encrypt migration bundles at rest and in transfer according to bank policy.
- Record backup, restore, schema migration, login, permission, tag publication, customer segmentation, and data export operations in the audit subsystem.

## 13. Delivery Sequence

The migration design fits the broader product implementation order:

1. Stabilize build and API contracts, including the unified Workbench Run contract.
2. Implement real customer tags, customer segmentation, and backend Chat Action outputs.
3. Add audit coverage and RBAC.
4. Add Alembic, repeatable migration bundles, single-machine services, and PostgreSQL readiness.
5. Replace in-process background execution with a durable task queue.
6. Integrate the feature route module into the target foundation template.

Migration foundations that prevent data loss, especially persistent uploads and Alembic baseline, should be implemented before any production data is introduced.

## 14. Acceptance Criteria

- A release can be installed on Linux and Windows Server without containers or Nginx.
- The target server needs no Node.js runtime.
- One service and one port serve both frontend and API.
- SQLite database and uploaded files can be backed up, verified, transferred, restored, and rolled back.
- Demo initialization is explicit and versioned.
- Production startup never silently mixes demo data into migrated data.
- Schema revisions are managed by Alembic and remain compatible with a future PostgreSQL migration.
- The existing feature page layouts and interactions remain unchanged when mounted in another frontend shell.
- Secrets are excluded from bundles and migration logs.
- Health, readiness, backup, restore, and smoke-check procedures are documented and repeatable.

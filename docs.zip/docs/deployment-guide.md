# Deployment Guide — Data Label Agent

> 适用于新开发环境部署，使用 PostgreSQL 16+，无需 LLM API Key，仅初始化数据库表结构

---

## 环境要求

| 组件 | 版本 | 说明 |
|------|------|------|
| Python | 3.12+ | 后端运行环境 |
| Node.js | 20+ | 前端构建和运行环境 |
| PostgreSQL | 16+ | 生产数据库 |
| pgvector | 0.5+ | 向量检索扩展（用于记忆系统） |

---

## 部署步骤

### Step 1: 克隆代码

```bash
git clone git@github.com:zhoudaozhuihou/label-demo.git
cd label-demo
```

### Step 2: 启动 PostgreSQL

**Docker 方式（推荐）：**

```bash
docker run -d \
  --name label-postgres \
  -e POSTGRES_USER=user \
  -e POSTGRES_PASSWORD=pass \
  -e POSTGRES_DB=data_label \
  -p 5432:5432 \
  pgvector/pgvector:pg16
```

**系统自带的 PostgreSQL：**

```bash
# macOS
brew install postgresql@16
brew services start postgresql@16

# Ubuntu
sudo apt install postgresql-16
sudo systemctl start postgresql

# 创建数据库并启用 pgvector 扩展
createdb data_label
psql -d data_label -c "CREATE EXTENSION IF NOT EXISTS vector;"
```

### Step 3: 初始化数据库表结构

```bash
# 执行建表脚本，创建全部 10 张表
psql -U user -d data_label -f backend/sql/init.sql

# 执行种子数据脚本，插入预设标签
psql -U user -d data_label -f backend/sql/seed.sql
```

### Step 4: 配置并启动后端

```bash
cd backend

# 创建虚拟环境
python3 -m venv venv
source venv/bin/activate

# 安装依赖
pip install -r requirements.txt

# 创建环境变量文件
cat > .env << 'EOF'
DATABASE_URL=postgresql+asyncpg://user:pass@localhost:5432/data_label
DATABASE_URL_SYNC=postgresql+psycopg2://user:pass@localhost:5432/data_label
ENCRYPTION_KEY=dev-key-change-in-production
EOF

# 启动后端（开发模式）
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

验证后端运行：`curl http://localhost:8000/health` → `{"status":"ok"}`

> **注意**：不配置 `LLM_PROVIDERS` 时，系统自动使用规则标注引擎（`rule_tagger.py`），覆盖 PII 检测、金融数据检测、业务域分类、数据质量评估，无需任何 LLM API Key。

### Step 5: 启动前端

```bash
cd frontend

# 安装依赖
npm install

# 启动开发服务器
npm run dev
```

打开浏览器访问 `http://localhost:5173`。

---

## 数据库表结构

执行 `init.sql` 后创建以下 10 张表：

| # | 表名 | 用途 |
|---|------|------|
| 1 | `connections` | 数据源连接配置（PostgreSQL/MySQL/BigQuery 等） |
| 2 | `discovered_tables` | Agent 扫描发现的数据库表 |
| 3 | `discovered_columns` | Agent 扫描发现的表字段 |
| 4 | `annotations` | 标注记录 — Human-in-the-Loop 核心表 |
| 5 | `tag_categories` | 标签分类（预设 + 用户自定义） |
| 6 | `tag_definitions` | 标签值定义 |
| 7 | `memory_entries` | Agent 记忆系统（含 pgvector 向量嵌入） |
| 8 | `audit_logs` | 审计日志 — 所有操作不可篡改记录 |
| 9 | `execution_logs` | Agent 执行轨迹 — 记录每一步推理和工具调用 |
| 10 | `agent_config` | Agent 角色、人格与行为配置 |

### 种子数据

执行 `seed.sql` 后插入：

**5 个标签分类：**
- `sensitivity`（敏感度）
- `domain`（业务域）
- `quality`（数据质量）
- `compliance`（合规）
- `business`（业务）

**17 个标签值：**
- 敏感度：PII、Financial、Internal、Public
- 业务域：客户信息、交易记录、账户信息、风控指标、产品信息、合同协议
- 数据质量：高、中、低
- 合规：GDPR、Basel、AML

---

## 关于 `create_all` 的说明

`backend/app/main.py` 中有一段自动建表逻辑：

```python
async with engine.begin() as conn:
    await conn.run_sync(Base.metadata.create_all)
```

每次后端启动时，SQLAlchemy 会检查所有 ORM 模型对应的表是否存在，不存在则创建。该操作是**幂等的**：

- 已经通过 `init.sql` 创建的表不会被重复创建或修改
- 开发阶段新增表（如后续添加新模型）时，`create_all` 会自动补建，无需手动执行 DDL
- 生产环境建议保留此逻辑，以便后续升级时自动补齐新表

---

## 无 LLM 时的功能矩阵

| 功能模块 | 状态 | 说明 |
|---------|------|------|
| 数据源管理（CRUD + 测试连接） | ✅ 完全可用 | |
| 运行标注（Schema 发现 + 数据采样 + 标注） | ✅ 完全可用 | 规则标注自动生效 |
| 标注审核（通过/驳回/修改） | ✅ 完全可用 | 审核结果写入记忆 |
| Agent 推理轨迹（Thinking Trace） | ✅ 完全可用 | 规则标注的执行轨迹同样记录 |
| 业务发现（客户数据地图 / 画像分析 / 交叉销售） | ✅ 完全可用 | |
| 数据资产（概览 / 质量报告 / 发现列表） | ✅ 完全可用 | |
| 标签体系（分类 / 值管理） | ✅ 完全可用 | |
| Agent 配置（角色 / 人格 / 行为） | ✅ 完全可用 | |
| 记忆检索（模式 / 修正 / 经验 / 知识） | ✅ 完全可用 | |
| 审计日志 | ✅ 完全可用 | |
| 技能管理 | ✅ 完全可用 | |
| LLM 配置 | ⚠️ 可访问 | 无 Provider，切换策略无效 |

---

## 环境变量参考

| 变量 | 必填 | 默认值 | 说明 |
|------|------|--------|------|
| `DATABASE_URL` | 否 | SQLite | 异步数据库连接串 |
| `DATABASE_URL_SYNC` | 否 | SQLite | 同步数据库连接串 |
| `ENCRYPTION_KEY` | 是 | — | AES 加密密钥 |
| `LLM_PROVIDERS` | 否 | `{}` | LLM 供应商配置 JSON |
| `LLM_STRATEGY` | 否 | `balanced` | 路由策略 |

---

## 常见问题

### 端口冲突

```bash
# 查看端口占用
lsof -i :8000
lsof -i :5432

# 修改后端端口
uvicorn app.main:app --reload --host 0.0.0.0 --port 8001
# 同时修改前端 vite.config.ts 中的 proxy target
```

### PostgreSQL 连接失败

```bash
# 确认 PostgreSQL 正在运行
pg_isready

# 确认可通过密码登录
psql -U user -d data_label -h localhost -W

# 确认 pgvector 扩展已安装
psql -d data_label -c "SELECT * FROM pg_extension WHERE extname='vector';"
```

### 前端无法连接后端 API

- 开发环境：Vite 自动代理 `/api` 请求到 `http://localhost:8000`，配置在 `vite.config.ts`
- 如果后端端口改了，同步修改 `vite.config.ts` 中的 `server.proxy.target`
- 生产环境：通过 nginx 反向代理，配置在 `frontend/nginx.conf`

### 数据迁移

从已有 PostgreSQL 环境迁移到新环境，仅迁移表结构无需数据：

```bash
# 旧环境导出 DDL（不含数据）
pg_dump -U user -d data_label --schema-only > schema.sql

# 新环境导入
psql -U user -d data_label < schema.sql
```

如需迁移数据：

```bash
# 旧环境导出全量
pg_dump -U user -d data_label > full_backup.sql

# 新环境导入
psql -U user -d data_label < full_backup.sql
```

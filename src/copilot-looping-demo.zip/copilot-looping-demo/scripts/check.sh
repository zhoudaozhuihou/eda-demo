#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"

echo "[check] backend import check"
cd "$ROOT_DIR/backend"
source .venv/bin/activate || true
python -m py_compile main.py loop_engine.py

echo "[check] frontend build"
cd "$ROOT_DIR/frontend"
npm run build

echo "[check] done"

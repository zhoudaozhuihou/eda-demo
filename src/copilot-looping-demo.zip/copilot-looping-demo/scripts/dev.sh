#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"

if [ ! -d "$ROOT_DIR/backend/.venv" ]; then
  echo "[init] backend virtualenv not found, running init..."
  "$ROOT_DIR/scripts/init.sh"
fi

if [ ! -d "$ROOT_DIR/frontend/node_modules" ]; then
  echo "[init] frontend node_modules not found, running init..."
  "$ROOT_DIR/scripts/init.sh"
fi

cleanup() {
  echo "\n[stop] shutting down services..."
  kill ${BACKEND_PID:-0} ${FRONTEND_PID:-0} 2>/dev/null || true
}
trap cleanup EXIT INT TERM

cd "$ROOT_DIR/backend"
source .venv/bin/activate
uvicorn main:app --host 0.0.0.0 --port 8000 &
BACKEND_PID=$!

cd "$ROOT_DIR/frontend"
npm run dev -- --host 0.0.0.0 --port 5173 &
FRONTEND_PID=$!

wait $BACKEND_PID $FRONTEND_PID

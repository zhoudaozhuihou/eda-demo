# Copilot Looping Demo

A minimal runnable starter repo for **VS Code Copilot looping / vibe coding** workflows.

## What this repo includes

- **Frontend:** React + Vite + TypeScript
- **Backend:** FastAPI
- **Loop engine:** simple task queue + iterative run logs
- **Copilot rules:** `.github/copilot-instructions.md`
- **One-command start:** `./scripts/dev.sh`
- **One-command validation:** `./scripts/check.sh`
- **Docker option:** `docker compose up --build`

---

## Project structure

```text
copilot-looping-demo/
├── .ai/tasks/queue.json
├── .github/copilot-instructions.md
├── backend/
│   ├── main.py
│   ├── loop_engine.py
│   └── requirements.txt
├── frontend/
│   ├── package.json
│   ├── tsconfig.json
│   ├── vite.config.ts
│   ├── index.html
│   └── src/
│       ├── App.tsx
│       ├── api.ts
│       ├── main.tsx
│       └── types.ts
├── scripts/
│   ├── check.sh
│   ├── dev.sh
│   └── init.sh
├── docker-compose.yml
└── Makefile
```

---

## Quick start (local)

### Prerequisites

- Node.js 20+
- Python 3.11+

### Start

```bash
chmod +x scripts/*.sh
./scripts/dev.sh
```

### URLs

- Frontend: http://localhost:5173
- Backend API: http://localhost:8000
- API docs: http://localhost:8000/docs

---

## Quick start (Docker)

```bash
docker compose up --build
```

---

## How the loop works

This demo models looping as:

```text
Task Queue -> Pick next task -> Simulate implementation -> Validate -> Mark done -> Continue
```

The backend exposes:

- `GET /api/tasks`
- `POST /api/tasks`
- `POST /api/loop/run-once`
- `POST /api/loop/run-all`
- `POST /api/tasks/reset`
- `GET /api/logs`

In a real enterprise setup, `run-once` / `run-all` would call:

- lint
- unit tests
- build
- contract checks
- security scans
- deployment validation

---

## Suggested Copilot usage

Use Agent mode with a prompt like:

```text
Work in looping mode.
For each task:
1. inspect impacted files
2. implement the smallest working change
3. run validation
4. if validation fails, fix and rerun
5. stop only when all checks pass
```

---

## Notes

This is intentionally small and easy to extend into:

- bank-grade AI engineering workflow
- queue-driven agent execution
- PRD -> dev -> test -> review loop
- data platform / API platform automation

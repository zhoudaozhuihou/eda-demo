export type Task = {
  id: number
  title: string
  status: 'todo' | 'done'
}

export type LoopLog = {
  timestamp: string
  task_id: number
  task_title: string
  step: string
  message: string
  success: boolean
}

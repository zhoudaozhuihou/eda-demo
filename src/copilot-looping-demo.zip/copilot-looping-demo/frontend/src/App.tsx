import { useEffect, useMemo, useState } from 'react'
import { createTask, fetchLogs, fetchTasks, resetTasks, runAll, runOnce } from './api'
import type { LoopLog, Task } from './types'

const containerStyle: React.CSSProperties = {
  fontFamily: 'Inter, Arial, sans-serif',
  maxWidth: 1100,
  margin: '0 auto',
  padding: '24px'
}

const cardStyle: React.CSSProperties = {
  border: '1px solid #e5e7eb',
  borderRadius: 16,
  padding: 16,
  marginBottom: 16,
  background: '#fff'
}

export default function App() {
  const [tasks, setTasks] = useState<Task[]>([])
  const [logs, setLogs] = useState<LoopLog[]>([])
  const [title, setTitle] = useState('')
  const [busy, setBusy] = useState(false)

  async function refresh() {
    const [taskData, logData] = await Promise.all([fetchTasks(), fetchLogs()])
    setTasks(taskData)
    setLogs(logData.slice().reverse())
  }

  useEffect(() => {
    void refresh()
  }, [])

  const stats = useMemo(() => {
    const total = tasks.length
    const done = tasks.filter((t) => t.status === 'done').length
    const todo = total - done
    return { total, done, todo }
  }, [tasks])

  async function handleCreateTask() {
    if (!title.trim()) return
    setBusy(true)
    try {
      await createTask(title.trim())
      setTitle('')
      await refresh()
    } finally {
      setBusy(false)
    }
  }

  async function handleRunOnce() {
    setBusy(true)
    try {
      await runOnce()
      await refresh()
    } finally {
      setBusy(false)
    }
  }

  async function handleRunAll() {
    setBusy(true)
    try {
      await runAll()
      await refresh()
    } finally {
      setBusy(false)
    }
  }

  async function handleReset() {
    setBusy(true)
    try {
      await resetTasks()
      await refresh()
    } finally {
      setBusy(false)
    }
  }

  return (
    <div style={{ background: '#f8fafc', minHeight: '100vh' }}>
      <div style={containerStyle}>
        <h1 style={{ marginBottom: 8 }}>VS Code Copilot Looping Demo</h1>
        <p style={{ color: '#475569', marginTop: 0 }}>
          A minimal runnable repo showing task queue → implementation loop → validation logs.
        </p>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12, marginBottom: 16 }}>
          <div style={cardStyle}><strong>Total</strong><div style={{ fontSize: 28 }}>{stats.total}</div></div>
          <div style={cardStyle}><strong>Done</strong><div style={{ fontSize: 28 }}>{stats.done}</div></div>
          <div style={cardStyle}><strong>Todo</strong><div style={{ fontSize: 28 }}>{stats.todo}</div></div>
        </div>

        <div style={cardStyle}>
          <h2 style={{ marginTop: 0 }}>Controls</h2>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 12 }}>
            <input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Add a new task"
              style={{ flex: 1, minWidth: 260, padding: '10px 12px', borderRadius: 10, border: '1px solid #cbd5e1' }}
            />
            <button disabled={busy} onClick={handleCreateTask}>Add Task</button>
            <button disabled={busy} onClick={handleRunOnce}>Run Once</button>
            <button disabled={busy} onClick={handleRunAll}>Run All</button>
            <button disabled={busy} onClick={handleReset}>Reset</button>
            <button disabled={busy} onClick={() => void refresh()}>Refresh</button>
          </div>
          <p style={{ color: '#64748b', marginBottom: 0 }}>
            In a real setup, “Run Once” would call lint, tests, build, review, and then continue only if checks pass.
          </p>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
          <div style={cardStyle}>
            <h2 style={{ marginTop: 0 }}>Task Queue</h2>
            {tasks.length === 0 ? <p>No tasks yet.</p> : (
              <ul style={{ paddingLeft: 20 }}>
                {tasks.map((task) => (
                  <li key={task.id} style={{ marginBottom: 8 }}>
                    <strong>#{task.id}</strong> {task.title} —{' '}
                    <span style={{ color: task.status === 'done' ? '#15803d' : '#b45309' }}>{task.status}</span>
                  </li>
                ))}
              </ul>
            )}
          </div>

          <div style={cardStyle}>
            <h2 style={{ marginTop: 0 }}>Loop Logs</h2>
            {logs.length === 0 ? <p>No logs yet.</p> : (
              <div style={{ maxHeight: 420, overflow: 'auto' }}>
                {logs.map((log, idx) => (
                  <div key={`${log.timestamp}-${idx}`} style={{ borderBottom: '1px solid #e2e8f0', padding: '8px 0' }}>
                    <div><strong>{log.task_title}</strong> · {log.step}</div>
                    <div style={{ color: '#475569' }}>{log.message}</div>
                    <div style={{ fontSize: 12, color: '#64748b' }}>{log.timestamp}</div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

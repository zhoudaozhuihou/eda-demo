import type { LoopLog, Task } from './types'

const API_BASE = 'http://localhost:8000'

export async function fetchTasks(): Promise<Task[]> {
  const res = await fetch(`${API_BASE}/api/tasks`)
  return res.json()
}

export async function fetchLogs(): Promise<LoopLog[]> {
  const res = await fetch(`${API_BASE}/api/logs`)
  return res.json()
}

export async function createTask(title: string): Promise<Task> {
  const res = await fetch(`${API_BASE}/api/tasks`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ title })
  })
  return res.json()
}

export async function runOnce(): Promise<unknown> {
  const res = await fetch(`${API_BASE}/api/loop/run-once`, { method: 'POST' })
  return res.json()
}

export async function runAll(): Promise<unknown> {
  const res = await fetch(`${API_BASE}/api/loop/run-all`, { method: 'POST' })
  return res.json()
}

export async function resetTasks(): Promise<Task[]> {
  const res = await fetch(`${API_BASE}/api/tasks/reset`, { method: 'POST' })
  return res.json()
}

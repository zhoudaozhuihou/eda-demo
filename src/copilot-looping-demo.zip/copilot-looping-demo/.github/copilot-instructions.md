---
applyTo: "**"
---

# Copilot Looping Rules

You are working in iterative delivery mode.
Never stop after only editing code.
Always validate before claiming completion.

## Required workflow
1. Understand the requirement.
2. Inspect impacted files.
3. Implement the smallest useful change.
4. Run validation.
5. If validation fails, fix root cause and rerun.
6. Repeat until the acceptance criteria are met.

## Exit criteria
Stop only when all are true:
- relevant checks pass
- requirement is satisfied
- no obvious TODO remains in changed code
- diff stays minimal and scoped

## Constraints
- prefer minimal diffs
- do not rewrite unrelated modules
- keep functions focused
- document residual risk clearly

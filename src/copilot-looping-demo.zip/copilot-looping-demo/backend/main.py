from __future__ import annotations

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from loop_engine import LoopEngine

app = FastAPI(title="Copilot Looping Demo API", version="0.1.0")
engine = LoopEngine()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class TaskCreate(BaseModel):
    title: str = Field(min_length=1, max_length=200)


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@app.get("/api/tasks")
def get_tasks() -> list[dict]:
    return engine.get_tasks()


@app.post("/api/tasks")
def create_task(payload: TaskCreate) -> dict:
    return engine.add_task(payload.title)


@app.post("/api/tasks/reset")
def reset_tasks() -> list[dict]:
    return engine.reset()


@app.get("/api/logs")
def get_logs() -> list[dict]:
    return engine.get_logs()


@app.post("/api/loop/run-once")
def run_once() -> dict:
    return engine.run_once()


@app.post("/api/loop/run-all")
def run_all() -> dict:
    return engine.run_all()

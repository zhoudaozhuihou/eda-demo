from __future__ import annotations

import json
from dataclasses import dataclass, asdict
from datetime import datetime
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
QUEUE_FILE = ROOT / ".ai" / "tasks" / "queue.json"
LOG_FILE = ROOT / ".ai" / "tasks" / "logs.json"


@dataclass
class LoopLog:
    timestamp: str
    task_id: int
    task_title: str
    step: str
    message: str
    success: bool


class LoopEngine:
    def __init__(self) -> None:
        self.queue_file = QUEUE_FILE
        self.log_file = LOG_FILE
        self._ensure_files()

    def _ensure_files(self) -> None:
        self.queue_file.parent.mkdir(parents=True, exist_ok=True)
        if not self.queue_file.exists():
            self.queue_file.write_text("[]", encoding="utf-8")
        if not self.log_file.exists():
            self.log_file.write_text("[]", encoding="utf-8")

    def _read_json(self, path: Path) -> list[dict[str, Any]]:
        return json.loads(path.read_text(encoding="utf-8"))

    def _write_json(self, path: Path, data: list[dict[str, Any]]) -> None:
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    def get_tasks(self) -> list[dict[str, Any]]:
        return self._read_json(self.queue_file)

    def save_tasks(self, tasks: list[dict[str, Any]]) -> None:
        self._write_json(self.queue_file, tasks)

    def get_logs(self) -> list[dict[str, Any]]:
        return self._read_json(self.log_file)

    def add_log(self, task_id: int, task_title: str, step: str, message: str, success: bool) -> None:
        logs = self.get_logs()
        logs.append(
            asdict(
                LoopLog(
                    timestamp=datetime.utcnow().isoformat() + "Z",
                    task_id=task_id,
                    task_title=task_title,
                    step=step,
                    message=message,
                    success=success,
                )
            )
        )
        self._write_json(self.log_file, logs)

    def reset(self) -> list[dict[str, Any]]:
        tasks = self.get_tasks()
        for task in tasks:
            if task["id"] != 1:
                task["status"] = "todo"
        self.save_tasks(tasks)
        self._write_json(self.log_file, [])
        return tasks

    def add_task(self, title: str) -> dict[str, Any]:
        tasks = self.get_tasks()
        next_id = max((task["id"] for task in tasks), default=0) + 1
        task = {"id": next_id, "title": title, "status": "todo"}
        tasks.append(task)
        self.save_tasks(tasks)
        return task

    def run_once(self) -> dict[str, Any]:
        tasks = self.get_tasks()
        next_task = next((task for task in tasks if task["status"] == "todo"), None)
        if not next_task:
            return {"message": "No remaining todo tasks.", "task": None}

        task_id = int(next_task["id"])
        task_title = str(next_task["title"])

        self.add_log(task_id, task_title, "analyze", "Analyzing requirement and impacted files.", True)
        self.add_log(task_id, task_title, "implement", "Applying the smallest useful change.", True)
        self.add_log(task_id, task_title, "validate", "Validation passed for demo workflow.", True)

        next_task["status"] = "done"
        self.save_tasks(tasks)
        return {"message": "Task completed.", "task": next_task}

    def run_all(self) -> dict[str, Any]:
        completed: list[dict[str, Any]] = []
        while True:
            result = self.run_once()
            if result["task"] is None:
                break
            completed.append(result["task"])
        return {"message": "Loop finished.", "completed": completed, "remaining": self.remaining_count()}

    def remaining_count(self) -> int:
        return sum(1 for task in self.get_tasks() if task["status"] == "todo")

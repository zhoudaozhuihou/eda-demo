---
name: Feature request
about: Request a new feature or enhancement for the looping demo
labels: enhancement
---

## Problem
What problem are we solving?

## Desired outcome
What should be true when this is complete?

## Acceptance criteria
- [ ]
- [ ]
- [ ]

## Scope notes
What should stay out of scope?

## Validation
How should we verify the feature works?

---
name: Bug report
about: Report a defect in the looping demo
labels: bug
---

## Current behavior
What is happening now?

## Expected behavior
What should happen instead?

## Reproduction steps
1.
2.
3.

## Impact
Who or what is affected?

## Acceptance criteria for fix
- [ ] Root cause identified
- [ ] Fix implemented
- [ ] Regression check added or documented

# Task Queue Execution Prompt

Read `.ai/tasks/queue.json` and process tasks in order.

## Rules
- Pick only the first task that is not done.
- Implement the smallest viable change for that task.
- Run validation after the change.
- Mark the task done only if validation passes.
- Continue until the queue is empty or a blocker requires human input.

## On blocker
Stop and return:
- blocked task
- reason
- smallest decision needed from a human

# Loop Implement Prompt

Task: ${input:task}

Work in iterative delivery mode.

## Process
1. Convert the task into explicit acceptance criteria.
2. Inspect impacted files.
3. Implement the smallest working change.
4. Run repository validation:
   - ./scripts/check.sh
   - and any relevant local checks for the changed area
5. If validation fails:
   - identify the root cause
   - fix it
   - rerun validation
6. Repeat until all acceptance criteria are satisfied.

## Output format
Return:
- acceptance criteria
- changed files
- commands run
- failures encountered and fixes applied
- final status
- residual risk

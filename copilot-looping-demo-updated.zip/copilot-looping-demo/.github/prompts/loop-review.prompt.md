# Loop Review Prompt

Review the current change set in this repository.

## Focus areas
- requirement coverage
- scope control
- regression risk
- API compatibility
- validation completeness

## Output format
Return:
- what looks correct
- what is risky or incomplete
- what should be fixed before merge
- whether another implementation loop is needed

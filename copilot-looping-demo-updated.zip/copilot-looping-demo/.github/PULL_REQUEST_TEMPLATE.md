## Summary
- What changed?
- Why was it needed?

## Acceptance criteria
- [ ] Criteria are clearly stated
- [ ] Requested behavior is implemented

## Validation
- [ ] `./scripts/check.sh`
- [ ] Additional frontend/backend checks if applicable

Commands run:
```text
paste commands here
```

## Scope control
- [ ] Diff is minimal
- [ ] No unrelated refactors included

## Risk / follow-up
- Known risks:
- Follow-up tasks:

---
applyTo: "**"
---

# Review Instructions

When reviewing or summarizing a change, always check:
- Does the diff stay within scope?
- Is there a simpler change that would satisfy the same requirement?
- Were validation steps actually executed?
- Were assumptions, risks, or skipped checks made explicit?
- Were user-facing and API-facing regressions considered?

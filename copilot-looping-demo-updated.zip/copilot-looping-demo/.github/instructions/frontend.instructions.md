---
applyTo: "frontend/**/*.{ts,tsx,css,html}"
---

# Frontend Instructions

## Stack
- React
- Vite
- TypeScript

## Rules
- Prefer functional components.
- Keep components presentational unless state is necessary.
- Extract duplicated fetch or transformation logic into helpers.
- Avoid oversized components; split when responsibilities diverge.
- Keep types explicit at boundaries.
- Preserve UI clarity over clever abstractions.

## Validation
When frontend behavior changes, run at minimum:
- `cd frontend && npm run build`

If lint or test scripts exist, run them too.

## UI change expectations
For meaningful UI changes, summarize:
- what changed visually
- impacted user flow
- edge cases handled

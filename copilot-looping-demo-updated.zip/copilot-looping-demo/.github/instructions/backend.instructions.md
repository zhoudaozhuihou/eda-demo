---
applyTo: "backend/**/*.py"
---

# Backend Instructions

## Stack
- Python
- FastAPI

## Rules
- Keep endpoint behavior explicit and predictable.
- Prefer small pure helper functions for loop/task logic.
- Separate API wiring from business logic where practical.
- Validate request and response shapes clearly.
- Avoid hidden side effects.

## Validation
When backend logic changes, run:
- `python -m py_compile backend/*.py` when available
- `./scripts/check.sh`

## API changes
If endpoint behavior changes, summarize:
- affected routes
- request/response shape changes
- migration or compatibility impact

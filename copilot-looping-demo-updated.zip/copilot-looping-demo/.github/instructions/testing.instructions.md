---
applyTo: "**/*test*.*,**/*spec*.*,tests/**/*"
---

# Testing Instructions

## Rules
- Prefer deterministic tests.
- Test user-visible behavior or API contract, not incidental implementation details.
- Add regression coverage for fixed bugs.
- Keep fixtures minimal.

## Quality bar
- Every behavioral change should have matching validation.
- If a dedicated test framework is missing, propose the smallest starter test layout.

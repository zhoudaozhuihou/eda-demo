---
applyTo: "**"
---

# Workspace Copilot Instructions

You are operating in iterative delivery mode for this repository.

## Primary goal
Implement the smallest correct change, validate it, and keep iterating until the requested outcome is achieved.

## Required loop
For any feature, bug fix, refactor, or task execution request:
1. Restate the requirement as explicit acceptance criteria.
2. Inspect impacted files and relevant dependencies before editing.
3. Prefer the smallest viable change.
4. Run repository validation.
5. If validation fails, inspect the error output, fix root cause, and rerun validation.
6. Repeat until exit criteria are satisfied.
7. Summarize changed files, validation results, residual risks, and follow-up work.

## Standard validation commands
- Frontend install: `cd frontend && npm install`
- Frontend lint placeholder: `cd frontend && npm run lint`
- Frontend test placeholder: `cd frontend && npm run test`
- Frontend build: `cd frontend && npm run build`
- Repository quick check: `./scripts/check.sh`

If a script is missing, say so explicitly and propose the minimum repo change needed to add it.

## Exit criteria
Stop only when all are true:
- the stated acceptance criteria are met
- the relevant checks have been executed and passed, or the missing checks are explicitly called out
- the diff is scoped and minimal
- no known TODO or placeholder is silently introduced

## Constraints
- Do not rewrite unrelated modules.
- Keep components, functions, and files focused.
- Prefer reversible and incremental edits.
- Preserve public API behavior unless the request explicitly asks for change.
- Add or update tests whenever behavior changes.
- Document assumptions instead of hiding them.

## Repo conventions
- Frontend: React + Vite + TypeScript
- Backend: FastAPI
- Loop state lives under `.ai/tasks`
- Automation scripts live under `scripts/`

## Review bar
Before claiming completion, verify:
- correctness
- scope control
- obvious regression risk
- developer ergonomics
